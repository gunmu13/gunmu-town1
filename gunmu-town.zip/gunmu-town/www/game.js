/* =========================================================
   棍母小镇 v6.0 · 完整逻辑
   ========================================================= */

/* 全局错误捕获 - 保证界面不消失 */
window.addEventListener('error', function(e){
  console.error('Global error:', e.message);
});
window.addEventListener('unhandledrejection', function(e){
  console.error('Promise rejection:', e.reason);
});

/* ========== 数据层 ========== */
const LOOT_NAMES = {
  1:['锈铁钉','破布条','空塑料瓶','旧电池','铜线圈','断扳手','黄胶带','油气打火机','短铅笔','碎橡皮','铁螺丝','小弹簧','麻绳头','汽水瓶盖','湿纸板','塑料袋','瘪铝罐','脏纱布','木楔子','橡皮筋','订书钉','弯回形针','半截牙签'],
  2:['医用绷带','压缩能量棒','打火机油','黄铜管','废电缆','铁皮工具箱','防水帆布','旧手电','五号电池组','军用水壶','硬饼干','止血带','铁口哨','指南针','裂镜放大镜','温度计','听诊器','手术刀片','注射器','氧气罐','滤毒罐芯'],
  3:['军用口粮','红外滤镜','加密U盘','SIM卡组','夜视仪镜片','消音器零件','四倍瞄准镜','防弹插板','战术手套','军靴','头盔衬垫','水袋','GPS模块','短波电台','双筒望远镜','红色信号弹','灰烟幕弹','闪光雷','破片手雷','燃烧瓶','C4塑胶炸药'],
  4:['金壳手表','金手镯','镀金手机','碎钻戒指','银质胸针','老式摄影机','矿卡显卡','钯金线材','除颤器','宫廷银器','激光指示模块','液压扳手','掌上游戏机','黑胶唱片机','古董打字机','维修手册','金豹小雕像','青花茶壶','宝石项链','胰岛素泵','精密水平仪','鎏金酒杯','纯金小块'],
  5:['热成像模块','目标定位模块','碎纹花瓶','金狮雕像','盛宴雕塑','金魔方','军用加密硬盘','卫星电话','夜视仪','防弹公文包','钛合金板','碳纤维布','军用无人机','高级工具组','稀有化学品'],
  6:['理想国芯片','军用主控芯片','核废料样本','古代金币','陨石碎片','生物样本容器','量子处理器'],
  7:['机密文件']
};
const LEVEL_PRICE = {1:[500,3000],2:[3000,8000],3:[8000,20000],4:[20000,60000],5:[60000,150000],6:[150000,400000],7:[800000,900000]};
const LEVEL_STYLE = {1:{icon:'🔩',cls:'lv1'},2:{icon:'🧰',cls:'lv2'},3:{icon:'📦',cls:'lv3'},4:{icon:'💎',cls:'lv4'},5:{icon:'🏆',cls:'lv5'},6:{icon:'👑',cls:'lv6'},7:{icon:'🗂️',cls:'lv7'}};

const ALL_LOOT = [];
(function(){
  let u = 1;
  for (let lv = 1; lv <= 7; lv++) {
    const [lo, hi] = LEVEL_PRICE[lv];
    LOOT_NAMES[lv].forEach(function(name, i){
      const r = LOOT_NAMES[lv].length === 1 ? 1 : i / (LOOT_NAMES[lv].length - 1);
      const base = lo + (hi - lo) * r;
      const j = base * (Math.random() * 0.3 - 0.15);
      const price = Math.round((base + j) / 100) * 100;
      ALL_LOOT.push({id:'L'+u++, name:name, level:lv, price:price, icon:LEVEL_STYLE[lv].icon, cls:LEVEL_STYLE[lv].cls, type:'loot'});
    });
  }
})();

const WEAPONS = [
  {id:'W01',name:'锈蜂 PDW-9',price:1000,dmg:15,rate:900,mag:30,range:600,bs:14},
  {id:'W02',name:'矿工 M870',price:3000,dmg:45,rate:60,mag:6,range:280,bs:9},
  {id:'W03',name:'夜莺 MP5',price:8000,dmg:20,rate:800,mag:30,range:650,bs:14},
  {id:'W04',name:'红壤 AK74N',price:15000,dmg:32,rate:650,mag:30,range:900,bs:16},
  {id:'W05',name:'铁砧 SKS',price:22000,dmg:38,rate:300,mag:10,range:1000,bs:17},
  {id:'W06',name:'峡谷 BM59',price:26000,dmg:42,rate:350,mag:20,range:1000,bs:17},
  {id:'W07',name:'远钟 M14',price:35000,dmg:55,rate:250,mag:20,range:1100,bs:18},
  {id:'W08',name:'白桦 Mosin',price:39000,dmg:85,rate:40,mag:5,range:1300,bs:22},
  {id:'W09',name:'沙狐 MDR',price:45000,dmg:40,rate:700,mag:30,range:900,bs:15},
  {id:'W10',name:'长枪管 M4A1',price:75000,dmg:35,rate:800,mag:30,range:950,bs:16},
  {id:'W11',name:'赤铁 AK-102',price:93000,dmg:38,rate:650,mag:30,range:950,bs:16},
  {id:'W12',name:'鹰眼 AUG',price:120000,dmg:40,rate:750,mag:30,range:1000,bs:16},
  {id:'W13',name:'大西洋 FAL',price:180000,dmg:52,rate:630,mag:20,range:1050,bs:17},
  {id:'W14',name:'幽灵 H416',price:280000,dmg:45,rate:850,mag:30,range:1000,bs:17},
  {id:'W15',name:'审判 MK14',price:450000,dmg:70,rate:400,mag:20,range:1200,bs:19},
  {id:'W16',name:'军刀 RPK',price:65000,dmg:36,rate:600,mag:60,range:900,bs:16},
  {id:'W17',name:'堡垒 SA58',price:220000,dmg:58,rate:500,mag:20,range:1000,bs:17},
  {id:'W18',name:'暗影 SR-25',price:380000,dmg:65,rate:350,mag:20,range:1150,bs:18},
  {id:'W19',name:'雷神 P90',price:160000,dmg:28,rate:1000,mag:50,range:700,bs:15},
  {id:'W20',name:'天罚 AWM',price:600000,dmg:120,rate:30,mag:5,range:1500,bs:25}
];

const MELEES = [
  {id:'K01',name:'生锈小刀',price:0,dmg:20,rate:180,range:50},
  {id:'K02',name:'矿工匕首',price:500,dmg:35,rate:200,range:55},
  {id:'K03',name:'军用战术刀',price:2500,dmg:55,rate:220,range:60},
  {id:'K04',name:'猎刀',price:8000,dmg:80,rate:200,range:65},
  {id:'K05',name:'消防斧',price:20000,dmg:120,rate:150,range:70},
  {id:'K06',name:'碳纤维砍刀',price:60000,dmg:180,rate:180,range:75},
  {id:'K07',name:'武士刀',price:200000,dmg:300,rate:200,range:85}
];

const ARMORS = [
  {id:'A1',name:'特勤防弹衣',price:2000,dur:35,red:0.20,tier:1},
  {id:'A2',name:'H-Tac 特勤甲',price:4500,dur:45,red:0.30,tier:2},
  {id:'A3',name:'KN 制式甲',price:30000,dur:55,red:0.45,tier:3},
  {id:'A4',name:'SEK 壁垒甲',price:100000,dur:65,red:0.55,tier:4},
  {id:'A5',name:'926 复合甲',price:200000,dur:75,red:0.65,tier:5},
  {id:'A6',name:'IMTV 武士甲',price:450000,dur:90,red:0.75,tier:6}
];

const HELMETS = [
  {id:'H1',name:'工地安全帽',price:800,dur:20,red:0.15,tier:1},
  {id:'H2',name:'战术软帽',price:2500,dur:28,red:0.25,tier:2},
  {id:'H3',name:'KN 防弹盔',price:18000,dur:38,red:0.40,tier:3},
  {id:'H4',name:'SEK 重型盔',price:60000,dur:50,red:0.52,tier:4},
  {id:'H5',name:'926 复合盔',price:130000,dur:62,red:0.62,tier:5},
  {id:'H6',name:'IMTV 武士盔',price:280000,dur:78,red:0.72,tier:6}
];

const MEDS = [
  {id:'M1',name:'简易急救包',price:800,heal:0.33,icon:'🩹'},
  {id:'M2',name:'军用急救包',price:2500,heal:0.50,icon:'💉'},
  {id:'M3',name:'白色医疗箱',price:8000,heal:1.00,icon:'🧰'}
];

const AMMO_TYPES = [
  {id:'AM1',name:'手枪弹',price:2,dmgMul:1.0,icon:'🔸'},
  {id:'AM2',name:'步枪弹',price:4,dmgMul:1.1,icon:'🔶'},
  {id:'AM3',name:'穿甲弹',price:12,dmgMul:1.4,icon:'💥'}
];

const PARTS = [
  {id:'P01',name:'红点瞄准镜',price:5000,slot:'scope',eff:'+15%命中'},
  {id:'P02',name:'四倍镜',price:20000,slot:'scope',eff:'+30%命中'},
  {id:'P03',name:'消音器',price:15000,slot:'muzzle',eff:'-敌人警戒'},
  {id:'P04',name:'补偿器',price:8000,slot:'muzzle',eff:'+10%伤害'},
  {id:'P05',name:'扩容弹匣',price:12000,slot:'mag',eff:'+10发弹匣'},
  {id:'P06',name:'快拔枪托',price:6000,slot:'stock',eff:'-20%后坐力'},
  {id:'P07',name:'垂直握把',price:4000,slot:'grip',eff:'+15%稳定性'},
  {id:'P08',name:'激光指示器',price:9000,slot:'grip',eff:'+10%腰射'}
];

const ENEMIES = [
  {id:'E01',name:'流浪拾荒者',hp:60,dmg:8,dropTier:'low',icon:'🧟',exp:5},
  {id:'E02',name:'武装匪徒',hp:90,dmg:15,dropTier:'low',icon:'🥷',exp:10},
  {id:'E03',name:'巡逻哨兵',hp:80,dmg:12,dropTier:'low',icon:'💂',exp:8},
  {id:'E04',name:'精英斥候',hp:110,dmg:20,dropTier:'mid',icon:'🕵️',exp:20},
  {id:'E05',name:'重装守卫',hp:150,dmg:18,dropTier:'mid',icon:'🛡️',exp:25},
  {id:'E06',name:'屋顶狙击手',hp:70,dmg:35,dropTier:'mid',icon:'🎯',exp:22},
  {id:'E07',name:'废墟突击兵',hp:100,dmg:22,dropTier:'mid',icon:'🔫',exp:18},
  {id:'E08',name:'爆破专家',hp:95,dmg:28,dropTier:'high',icon:'💣',exp:35},
  {id:'E09',name:'随队医疗兵',hp:85,dmg:10,dropTier:'high',icon:'⛑️',exp:30},
  {id:'E10',name:'精英指挥官',hp:130,dmg:25,dropTier:'high',icon:'🎖️',exp:45},
  {id:'E11',name:'暗影刺客',hp:80,dmg:30,dropTier:'high',icon:'🥷',exp:40},
  {id:'E12',name:'钢铁重装',hp:200,dmg:22,dropTier:'high',icon:'🦾',exp:55},
  {id:'E13',name:'火焰兵',hp:120,dmg:26,dropTier:'high',icon:'🔥',exp:50},
  {id:'E14',name:'电磁技师',hp:100,dmg:24,dropTier:'mid',icon:'⚡',exp:35},
  {id:'E15',name:'战场指挥官',hp:180,dmg:30,dropTier:'high',icon:'⭐',exp:70}
];

const BOSS = {
  id:'BOSS', name:'“棍母”镇长', hp:500, dmg:40, dropTier:'boss', icon:'👺', exp:200,
  specialDrop:{id:'L-SP1', name:'镇长的金印章', level:6, price:520000, icon:'🔱', cls:'lv6', type:'loot'}
};

const CONTAINERS = [
  {id:'C01',name:'军用保险箱',tier:'low',icon:'🗄️'},
  {id:'C02',name:'加密集装箱',tier:'low',icon:'📦'},
  {id:'C03',name:'医疗空投',tier:'low',icon:'🚁'},
  {id:'C04',name:'武器箱',tier:'low',icon:'🔫'},
  {id:'C05',name:'电子保险箱',tier:'low',icon:'💻'},
  {id:'C06',name:'军用背包',tier:'mid',icon:'🎒'},
  {id:'C07',name:'弹药箱',tier:'mid',icon:'📦'},
  {id:'C08',name:'工具箱',tier:'mid',icon:'🧰'},
  {id:'C09',name:'旅行箱',tier:'mid',icon:'🧳'},
  {id:'C10',name:'抽屉',tier:'mid',icon:'🗃️'},
  {id:'C11',name:'普通补给箱',tier:'high',icon:'📮'},
  {id:'C12',name:'散落物资点',tier:'high',icon:'🧷'},
  {id:'C13',name:'衣柜',tier:'high',icon:'🚪'},
  {id:'C14',name:'废弃车辆',tier:'high',icon:'🚗'}
];

const DROP_RATE = {
  low:{1:0.05,2:0.10,3:0.20,4:0.35,5:0.20,6:0.08,7:0.02},
  mid:{1:0.15,2:0.25,3:0.30,4:0.20,5:0.08,6:0.02,7:0.00},
  high:{1:0.40,2:0.35,3:0.20,4:0.05,5:0.00,6:0.00,7:0.00},
  boss:{1:0.00,2:0.05,3:0.10,4:0.25,5:0.35,6:0.20,7:0.05}
};

const MAPS = {
  town:{id:'town',name:'棍母小镇',desc:'废弃矿区旁的居民点',lootMul:1.0,enMul:1.0},
  mine:{id:'mine',name:'废弃矿洞',desc:'塌方频发，矿脉里全是宝',lootMul:1.4,enMul:1.3},
  facility:{id:'facility',name:'旧军事设施',desc:'危险最高，机密出没',lootMul:1.9,enMul:1.6}
};

const DIFFICULTY = {
  normal:{name:'普通',ec:[5,8],luck:1.0,boss:false,minValue:0},
  hard:{name:'困难',ec:[8,12],luck:1.5,boss:false,minValue:50000},
  lockdown:{name:'封锁',ec:[12,15],luck:2.5,boss:true,minValue:150000}
};

const RANKS = [
  {name:'青铜III',min:0,icon:'🥉'},{name:'青铜II',min:50,icon:'🥉'},{name:'青铜I',min:100,icon:'🥉'},
  {name:'白银III',min:200,icon:'🥈'},{name:'白银II',min:300,icon:'🥈'},{name:'白银I',min:450,icon:'🥈'},
  {name:'黄金III',min:600,icon:'🥇'},{name:'黄金II',min:800,icon:'🥇'},{name:'黄金I',min:1000,icon:'🥇'},
  {name:'铂金III',min:1300,icon:'💠'},{name:'铂金II',min:1600,icon:'💠'},{name:'铂金I',min:2000,icon:'💠'},
  {name:'钻石III',min:2500,icon:'💎'},{name:'钻石II',min:3000,icon:'💎'},{name:'钻石I',min:4000,icon:'💎'},
  {name:'传奇',min:5000,icon:'👑'}
];

const ACHIEVEMENTS = [
  {id:'a01',name:'初次行动',desc:'完成第一次突袭',target:1,type:'raid',reward:5000},
  {id:'a02',name:'首战告捷',desc:'首次成功撤离',target:1,type:'extract',reward:10000},
  {id:'a03',name:'小有积蓄',desc:'存款达到10万',target:100000,type:'money',reward:5000},
  {id:'a04',name:'富甲一方',desc:'存款达到100万',target:1000000,type:'money',reward:50000},
  {id:'a05',name:'大富翁',desc:'存款达到500万',target:5000000,type:'money',reward:200000},
  {id:'a06',name:'猎人',desc:'累计击杀10人',target:10,type:'kill',reward:5000},
  {id:'a07',name:'屠夫',desc:'累计击杀50人',target:50,type:'kill',reward:20000},
  {id:'a08',name:'战神',desc:'累计击杀200人',target:200,type:'kill',reward:100000},
  {id:'a09',name:'常客',desc:'完成10次突袭',target:10,type:'raid',reward:10000},
  {id:'a10',name:'老手',desc:'完成50次突袭',target:50,type:'raid',reward:50000},
  {id:'a11',name:'生存大师',desc:'成功撤离20次',target:20,type:'extract',reward:30000},
  {id:'a12',name:'不死鸟',desc:'成功撤离100次',target:100,type:'extract',reward:200000},
  {id:'a13',name:'掘金者',desc:'累计带出50万物资',target:500000,type:'loot',reward:20000},
  {id:'a14',name:'宝藏猎人',desc:'累计带出500万物资',target:5000000,type:'loot',reward:300000},
  {id:'a15',name:'镇长终结者',desc:'击败镇长',target:1,type:'boss',reward:100000},
  {id:'a16',name:'跑刀专家',desc:'近战击杀10人',target:10,type:'melee',reward:20000},
  {id:'a17',name:'神枪手',desc:'枪械击杀50人',target:50,type:'gun',reward:30000},
  {id:'a18',name:'爆破大师',desc:'手雷击杀5人',target:5,type:'grenade',reward:25000},
  {id:'a19',name:'孤胆英雄',desc:'单人击杀Boss',target:1,type:'boss',reward:150000},
  {id:'a20',name:'装备齐全',desc:'装备所有槽位',target:1,type:'fullEquip',reward:10000},
  {id:'a21',name:'军火商',desc:'仓库10把枪',target:10,type:'haveGuns',reward:30000},
  {id:'a22',name:'收藏家',desc:'5件5级以上物品',target:5,type:'haveHigh',reward:50000},
  {id:'a23',name:'传说猎人',desc:'获得机密文件',target:1,type:'haveLegendary',reward:500000},
  {id:'a24',name:'资深指挥官',desc:'达到Lv10',target:10,type:'level',reward:50000},
  {id:'a25',name:'精英指挥官',desc:'达到Lv30',target:30,type:'level',reward:300000},
  {id:'a26',name:'连续签到3天',desc:'签到3天',target:3,type:'checkin',reward:15000},
  {id:'a27',name:'连续签到7天',desc:'签到7天',target:7,type:'checkin',reward:80000},
  {id:'a28',name:'改装大师',desc:'改装10把枪',target:10,type:'modGun',reward:50000},
  {id:'a29',name:'百战老兵',desc:'完成100次突袭',target:100,type:'raid',reward:300000},
  {id:'a30',name:'棍母传奇',desc:'达成所有成就',target:29,type:'allAch',reward:1000000}
];

const DAILY_REWARDS = [
  {day:1,money:10000},
  {day:2,money:20000},
  {day:3,money:30000,item:{id:'M1',name:'简易急救包',price:800,heal:0.33,icon:'🩹',type:'med'}},
  {day:4,money:50000},
  {day:5,money:80000,item:{id:'K03',name:'军用战术刀',price:2500,dmg:55,rate:220,range:60,type:'melee'}},
  {day:6,money:120000},
  {day:7,money:300000,item:{id:'A3',name:'KN 制式甲',price:30000,dur:55,red:0.45,tier:3,type:'armor'}}
];

/* ========== 状态 ========== */
const SAVE_KEY = 'gunmu_town_save_v6';
let G = null;

function newGame() {
  return {
    money: 500000,
    warehouse: [],
    equipment: {weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1'},
    parts: {},
    stats: {raids:0, extracts:0, deaths:0, kills:0, bestLoot:0, totalKills:0, totalLoot:0, meleeKills:0, gunKills:0, grenadeKills:0, bossKills:0, mods:0},
    level: 1, exp: 0, rankPoints: 0,
    quests: [
      {id:'q1', name:'首次撤离', desc:'完成1次成功撤离', target:1, progress:0, reward:20000, done:false},
      {id:'q2', name:'消灭5个敌人', desc:'累计击杀5名敌人', target:5, progress:0, reward:30000, done:false},
      {id:'q3', name:'带走3级物品', desc:'带出任意3级变卖物', target:1, progress:0, reward:15000, done:false},
      {id:'q4', name:'击杀镇长', desc:'在封锁难度击杀Boss', target:1, progress:0, reward:100000, done:false}
    ],
    achievements: {}, mails: [],
    lastCheckin: '', checkinStreak: 0, checkinDays: [],
    questLog: [], unlockedMaps: ['town'],
    settings: {sfx:true, autoMed:true, aimAssist:true}
  };
}

function save() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(G)); } catch(e){} }

function load() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (raw) { try { G = JSON.parse(raw); } catch(e){ G = newGame(); } }
  else G = newGame();
  const def = newGame();
  for (const k in def) if (G[k] === undefined) G[k] = def[k];
  if (!G.equipment) G.equipment = {weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1'};
  if (!G.equipment.meds) G.equipment.meds = [];
  if (!G.stats) G.stats = def.stats;
  if (!G.achievements) G.achievements = {};
  if (!G.mails) G.mails = [];
  if (!G.parts) G.parts = {};
  if (!G.questLog) G.questLog = [];
  if (!G.quests) G.quests = def.quests;
  if (!G.settings) G.settings = {sfx:true, autoMed:true, aimAssist:true};
  if (!G.checkinDays) G.checkinDays = [];
}

/* ========== 工具 ========== */
function $(s) { return document.querySelector(s); }
function $$(s) { return document.querySelectorAll(s); }
function fmt(n) { return (n||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
function rand(a,b) { return Math.floor(Math.random()*(b-a+1))+a; }
function randPick(a) { return a[Math.floor(Math.random()*a.length)]; }
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function uid() { return 'U' + Date.now() + Math.random().toString(36).slice(2,6); }
function expToNext(lv) { return 100 + (lv-1) * 80; }

function toast(msg, type) {
  const box = document.getElementById('toast-box');
  if (!box) return;
  const d = document.createElement('div');
  d.className = 'toast ' + (type || '');
  d.textContent = msg;
  box.appendChild(d);
  setTimeout(function(){ d.remove(); }, 2500);
}

function rollLevel(tier) {
  const t = DROP_RATE[tier]; if (!t) return 1;
  const r = Math.random(); let acc = 0;
  for (let lv = 1; lv <= 7; lv++) { acc += t[lv]; if (r < acc) return lv; }
  return 1;
}
function rollLoot(tier) {
  const lv = rollLevel(tier);
  const pool = ALL_LOOT.filter(function(x){ return x.level === lv; });
  return clone(randPick(pool));
}
function addToWarehouse(item) {
  if (!item) return;
  if (!item.uid) item.uid = uid();
  if (!item.type) item.type = inferType(item);
  if (item.type === 'ammo') {
    const ex = G.warehouse.find(function(x){ return x.type === 'ammo' && x.ammoId === item.ammoId; });
    if (ex) { ex.count = (ex.count||1) + (item.count||1); return; }
  }
  G.warehouse.push(item);
}
function removeFromWarehouse(u) {
  const i = G.warehouse.findIndex(function(x){ return x.uid === u; });
  if (i >= 0) G.warehouse.splice(i, 1);
}
function inferType(item) {
  if (!item) return 'loot';
  if (item.type) return item.type;
  if (WEAPONS.find(function(w){return w.id === item.id;})) return 'weapon';
  if (MELEES.find(function(m){return m.id === item.id;})) return 'melee';
  if (ARMORS.find(function(a){return a.id === item.id;})) return 'armor';
  if (HELMETS.find(function(h){return h.id === item.id;})) return 'helmet';
  if (MEDS.find(function(m){return m.id === item.id;})) return 'med';
  if (AMMO_TYPES.find(function(a){return a.id === item.id;})) return 'ammo';
  if (PARTS.find(function(p){return p.id === item.id;})) return 'part';
  return 'loot';
}
function getTypeIcon(t) {
  const icons = {weapon:'🔫', melee:'🔪', armor:'🛡️', helmet:'⛑️', med:'🩹', ammo:'🔸', part:'🔧', loot:'❔'};
  return icons[t] || '❔';
}
function typeName(t) {
  const names = {loot:'变卖物', weapon:'枪械', melee:'刀具', armor:'护甲', helmet:'头盔', med:'药品', ammo:'弹药', part:'配件'};
  return names[t] || '未知';
}

/* ========== 路由 ========== */
function go(name) {
  try {
    $$('.screen').forEach(function(s){ s.style.display = 'none'; s.classList.add('hidden'); });
    const el = document.getElementById('scr-' + name);
    if (!el) return;
    el.style.display = 'block';
    el.classList.remove('hidden');
    setTimeout(function(){
      try {
        if (name === 'lobby') renderLobby();
        else if (name === 'warehouse') renderWarehouse();
        else if (name === 'market') renderMarket('buy-weapon');
        else if (name === 'loadout') renderLoadout();
        else if (name === 'map') renderMap();
        else if (name === 'quest') renderQuest();
        else if (name === 'workbench') renderWorkbench();
        else if (name === 'quest-log') renderQuestLog();
        else if (name === 'achieve') renderAchieve();
        else if (name === 'mail') renderMail();
        else if (name === 'checkin') renderCheckin();
        else if (name === 'rank') renderRank();
        else if (name === 'settings') renderSettings();
      } catch(e) { console.error(e); toast('渲染错误：' + e.message, 'error'); }
    }, 10);
  } catch(e) { console.error(e); }
}

function renderTopbar() {
  if (!G) return;
  const set = function(id, v) { const e = document.getElementById(id); if (e) e.textContent = v; };
  set('money', fmt(G.money));
  set('wh-count', G.warehouse.length);
  set('player-level', G.level || 1);
  set('player-exp', Math.floor(G.exp || 0));
  set('player-exp-max', expToNext(G.level || 1));
  set('player-kills', G.stats.totalKills || 0);
  set('player-rank', getRankName());
}
function getRankName() {
  const p = G.rankPoints || 0;
  let r = RANKS[0];
  for (let i = 0; i < RANKS.length; i++) if (p >= RANKS[i].min) r = RANKS[i];
  return r.icon + ' ' + r.name;
}

/* ========== 大厅 ========== */
function renderLobby() {
  try {
    renderTopbar();
    const eq = G.equipment;
    const set = function(id, v) { const e = document.getElementById(id); if (e) e.textContent = v; };
    set('prev-weapon', eq.weapon ? eq.weapon.name : '—');
    set('prev-armor', eq.armor ? eq.armor.name : '—');
    set('prev-helmet', eq.helmet ? eq.helmet.name : '—');
    const lastMap = G.unlockedMaps[G.unlockedMaps.length-1] || 'town';
    const mapInfo = MAPS[lastMap] || MAPS.town;
    set('lobby-map-name', mapInfo.name);
    set('lobby-map-desc', mapInfo.desc);
    const log = document.getElementById('lobby-sys-log');
    if (log) log.innerHTML =
      '<p>▸ 携带价值：' + fmt(equipValue()) + ' 币</p>' +
      '<p>▸ 累计撤离：' + (G.stats.extracts||0) + ' 次</p>' +
      '<p>▸ 最佳战利：' + fmt(G.stats.bestLoot||0) + ' 币</p>' +
      '<p>▸ 未读邮件：' + G.mails.filter(function(m){return !m.read;}).length + ' 封</p>';
    checkAchievements();
  } catch(e) { console.error(e); }
}

/* ========== 仓库 ========== */
let warehouseFilter = 'all';

function setFilter(btn, f) {
  warehouseFilter = f;
  $$('.filter-tabs button').forEach(function(b){ b.classList.toggle('active', b === btn); });
  renderWarehouse();
}

function renderWarehouse() {
  renderTopbar();
  const grid = document.getElementById('warehouse-grid');
  if (!grid) return;
  grid.innerHTML = '';
  const list = G.warehouse.filter(function(it){
    return warehouseFilter === 'all' || inferType(it) === warehouseFilter;
  });
  if (list.length === 0) {
    grid.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">这个分类下没有物品。</p>';
    return;
  }
  list.sort(function(a,b){ return (b.level||0)-(a.level||0); }).forEach(function(item){
    const card = document.createElement('div');
    const t = inferType(item);
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = '<span class="lvl">' + (item.level ? 'Lv'+item.level : '') + '</span>' +
      '<span class="emoji">' + (item.icon || getTypeIcon(t)) + '</span>' +
      '<span class="name-mini">' + item.name + '</span>' +
      (item.count > 1 ? '<span class="count-badge">×' + item.count + '</span>' : '');
    card.onclick = function(){ showItemDetail(item); };
    card.oncontextmenu = function(e){ e.preventDefault(); quickSell(item, 1); };
    grid.appendChild(card);
  });
}

function showItemDetail(item) {
  const panel = document.getElementById('item-detail');
  if (!panel) return;
  panel.style.display = 'block';
  panel.classList.remove('hidden');
  const t = inferType(item);
  let extra = '';
  if (t === 'weapon') extra = '<p>伤害：' + item.dmg + ' · 射速：' + item.rate + ' · 弹匣：' + item.mag + '</p>';
  if (t === 'melee') extra = '<p>伤害：' + item.dmg + ' · 攻速：' + item.rate + '</p>';
  if (t === 'armor' || t === 'helmet') extra = '<p>减伤：' + Math.round(item.red*100) + '% · 耐久：' + item.dur + '</p>';
  if (t === 'med') extra = '<p>恢复：' + Math.round(item.heal*100) + '%</p>';
  if (t === 'ammo') extra = '<p>数量：' + (item.count||1) + '</p>';
  if (t === 'part') extra = '<p>效果：' + item.eff + '</p>';
  const canEquip = ['weapon','melee','armor','helmet','med','ammo'].indexOf(t) >= 0;
  const sellPrice = Math.floor((item.price||0) * 0.8);
  panel.innerHTML = '<h3>' + item.name + '</h3>' +
    '<p>类型：' + typeName(t) + '</p>' +
    '<p>等级：' + (item.level || '—') + '</p>' + extra +
    '<p>估价：' + fmt(item.price||0) + '</p>' +
    '<p>出售可得：' + fmt(sellPrice) + '</p>' +
    (canEquip ? '<button class="alt" id="btn-equip-one">装备</button>' : '') +
    '<button id="btn-sell-one">出售 1 个</button>' +
    (item.count > 1 ? '<button id="btn-sell-all">出售全部 (' + item.count + ')</button>' : '') +
    '<button class="gray" id="btn-close-detail">关闭</button>';
  const cd = document.getElementById('btn-close-detail'); if (cd) cd.onclick = function(){ panel.style.display = 'none'; };
  const s1 = document.getElementById('btn-sell-one'); if (s1) s1.onclick = function(){ quickSell(item, 1); panel.style.display = 'none'; };
  const sa = document.getElementById('btn-sell-all'); if (sa) sa.onclick = function(){ quickSell(item, item.count); panel.style.display = 'none'; };
  const e1 = document.getElementById('btn-equip-one'); if (e1) e1.onclick = function(){ equipFromWarehouse(item); panel.style.display = 'none'; renderWarehouse(); };
}

function quickSell(item, count) {
  const c = count || 1;
  if (item.count && item.count > 1) {
    const take = Math.min(c, item.count);
    G.money += Math.floor(item.price * 0.8) * take;
    item.count -= take;
    if (item.count <= 0) removeFromWarehouse(item.uid);
  } else {
    G.money += Math.floor(item.price * 0.8);
    removeFromWarehouse(item.uid);
  }
  save();
  renderTopbar();
  renderWarehouse();
}

/* ========== 市场 ========== */
function switchMarket(btn, tab) {
  $$('#scr-market .tabs button').forEach(function(b){ b.classList.toggle('active', b === btn); });
  renderMarket(tab);
}

function renderMarket(tab) {
  renderTopbar();
  const body = document.getElementById('market-body');
  if (!body) return;
  body.innerHTML = '';

  if (tab === 'buy-weapon') {
    WEAPONS.forEach(function(w){ body.appendChild(mkCard({icon:'🔫', name:w.name, price:w.price, sub:'伤害'+w.dmg+' 射速'+w.rate+' 弹匣'+w.mag, buy:function(){buyEq('weapon', w);}})); });
  } else if (tab === 'buy-melee') {
    MELEES.forEach(function(m){ body.appendChild(mkCard({icon:'🔪', name:m.name, price:m.price, sub:'伤害'+m.dmg+' 攻速'+m.rate, buy:function(){buyEq('melee', m);}})); });
  } else if (tab === 'buy-armor') {
    ARMORS.forEach(function(a){ body.appendChild(mkCard({icon:'🛡️', name:a.name, price:a.price, sub:a.tier+'级甲 耐久'+a.dur+' 减伤'+Math.round(a.red*100)+'%', buy:function(){buyEq('armor', a);}})); });
    HELMETS.forEach(function(h){ body.appendChild(mkCard({icon:'⛑️', name:h.name, price:h.price, sub:h.tier+'级盔 耐久'+h.dur+' 减伤'+Math.round(h.red*100)+'%', buy:function(){buyEq('helmet', h);}})); });
  } else if (tab === 'buy-med') {
    MEDS.forEach(function(m){ body.appendChild(mkCard({icon:m.icon, name:m.name, price:m.price, sub:'恢复'+Math.round(m.heal*100)+'%', buy:function(){buyEq('med', m);}})); });
  } else if (tab === 'buy-ammo') {
    AMMO_TYPES.forEach(function(a){ body.appendChild(mkCard({icon:a.icon, name:a.name+' ×30', price:a.price*30, sub:'伤害×'+a.dmgMul, buy:function(){buyAmmo(a, 30);}})); });
  } else if (tab === 'buy-part') {
    PARTS.forEach(function(p){ body.appendChild(mkCard({icon:'🔧', name:p.name, price:p.price, sub:p.eff+' · '+p.slot, buy:function(){buyEq('part', p);}})); });
  } else if (tab === 'sell') {
    const sellable = G.warehouse.filter(function(it){ return inferType(it) === 'loot'; });
    if (sellable.length === 0) { body.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">没有可卖出的变卖物。</p>'; return; }
    sellable.sort(function(a,b){ return (b.level||0)-(a.level||0); }).forEach(function(item){
      body.appendChild(mkCard({
        icon: item.icon || '❔', name: item.name,
        price: Math.floor((item.price||0)*0.8),
        sub: 'Lv' + (item.level||'—') + ' 原价' + fmt(item.price||0),
        buy: function(){ G.money += Math.floor(item.price*0.8); removeFromWarehouse(item.uid); save(); renderMarket('sell'); renderTopbar(); },
        buyLabel: '出售'
      }));
    });
  }
}

function mkCard(o) {
  const c = document.createElement('div');
  c.className = 'market-card';
  c.innerHTML = '<div class="mk-icon">' + o.icon + '</div>' +
    '<div class="mk-name">' + o.name + '</div>' +
    '<div class="mk-sub">' + (o.sub||'') + '</div>' +
    '<div class="mk-price">' + fmt(o.price) + ' 币</div>' +
    '<button class="mk-btn">' + (o.buyLabel||'购买') + '</button>';
  const btn = c.querySelector('.mk-btn');
  btn.onclick = function(e){ e.stopPropagation(); o.buy(); };
  return c;
}

function buyEq(slot, data) {
  if (G.money < data.price) { toast('柯恩币不足', 'error'); return; }
  G.money -= data.price;
  const item = clone(data);
  item.type = slot;
  item.uid = uid();
  if (slot === 'med') item.icon = item.icon || '🩹';
  addToWarehouse(item);
  save();
  renderTopbar();
  toast(item.name + ' 已放入仓库', 'success');
}

function buyAmmo(data, count) {
  const total = data.price * count;
  if (G.money < total) { toast('柯恩币不足', 'error'); return; }
  G.money -= total;
  const item = clone(data);
  item.type = 'ammo';
  item.ammoId = data.id;
  item.icon = data.icon;
  item.count = count;
  item.uid = uid();
  item.price = data.price;
  addToWarehouse(item);
  save();
  renderTopbar();
  toast('购买 ' + data.name + ' ×' + count, 'success');
}

/* ========== 装备 ========== */
function onSlotClick(k) {
  const eq = G.equipment;
  if (k === 'meds') { if (eq.meds.length) { unequip('meds'); renderLoadout(); } }
  else if (eq[k]) { unequip(k); renderLoadout(); }
}

function equipFromWarehouse(item) {
  const t = inferType(item);
  if (t === 'loot') { toast('变卖物不能装备', 'error'); return; }
  if (t === 'part') { toast('配件请在改枪台安装', 'error'); return; }
  if (t === 'ammo') {
    G.equipment.ammo = (G.equipment.ammo||0) + (item.count||0);
    G.equipment.ammoType = item.ammoId || 'AM1';
    removeFromWarehouse(item.uid); save();
    toast('装填 ' + item.name + ' ×' + item.count, 'success');
    return;
  }
  if (t === 'med') {
    if (G.equipment.meds.length >= 3) { toast('药品已满', 'error'); return; }
    removeFromWarehouse(item.uid);
    G.equipment.meds.push(item);
    save();
    return;
  }
  const slotMap = {weapon:'weapon', melee:'melee', armor:'armor', helmet:'helmet'};
  const slot = slotMap[t];
  if (!slot) return;
  if (G.equipment[slot]) {
    const old = G.equipment[slot];
    old.type = slot;
    addToWarehouse(old);
  }
  G.equipment[slot] = item;
  removeFromWarehouse(item.uid);
  save();
}

function unequip(slot) {
  if (slot === 'meds') {
    G.equipment.meds.forEach(function(m){ addToWarehouse(m); });
    G.equipment.meds = [];
    save();
    return;
  }
  const item = G.equipment[slot];
  if (!item) return;
  item.type = slot;
  addToWarehouse(item);
  G.equipment[slot] = null;
  save();
}

function renderLoadout() {
  renderTopbar();
  const eq = G.equipment;
  setSlot('slot-weapon', eq.weapon);
  setSlot('slot-melee', eq.melee);
  setSlot('slot-armor', eq.armor);
  setSlot('slot-helmet', eq.helmet);
  const ms = document.getElementById('slot-meds');
  if (ms) {
    ms.querySelector('.slot-value').textContent = eq.meds.length ? eq.meds.map(function(m){return m.name;}).join('/') : '空';
    ms.classList.toggle('filled', eq.meds.length > 0);
  }
  const lv = document.getElementById('loadout-value'); if (lv) lv.textContent = fmt(equipValue());
  const la = document.getElementById('loadout-ammo'); if (la) la.textContent = eq.ammo || 0;
  const picker = document.getElementById('loadout-picker');
  if (!picker) return;
  picker.innerHTML = '';
  const cand = G.warehouse.filter(function(it){
    return ['weapon','melee','armor','helmet','med','ammo'].indexOf(inferType(it)) >= 0;
  });
  if (cand.length === 0) {
    picker.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:20px">仓库没有可装备物品。</p>';
    return;
  }
  cand.forEach(function(item){
    const t = inferType(item);
    const card = document.createElement('div');
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = '<span class="emoji">' + (item.icon||getTypeIcon(t)) + '</span>' +
      '<span class="name-mini">' + item.name + '</span>' +
      (item.count > 1 ? '<span class="count-badge">×' + item.count + '</span>' : '');
    card.onclick = function(){ equipFromWarehouse(item); renderLoadout(); };
    picker.appendChild(card);
  });
}

function setSlot(id, item) {
  const el = document.getElementById(id);
  if (!el) return;
  const v = el.querySelector('.slot-value');
  if (item) { v.textContent = item.name; el.classList.add('filled'); }
  else { v.textContent = '空'; el.classList.remove('filled'); }
}

function equipValue() {
  const e = G.equipment;
  let v = 0;
  if (e.weapon) v += e.weapon.price||0;
  if (e.melee) v += e.melee.price||0;
  if (e.armor) v += e.armor.price||0;
  if (e.helmet) v += e.helmet.price||0;
  e.meds.forEach(function(m){ v += m.price||0; });
  v += (e.ammo||0) * 3;
  return v;
}

/* ========== 改枪台 ========== */
let wbCurrentGun = null;

function renderWorkbench() {
  renderTopbar();
  const list = document.getElementById('wb-gun-select');
  if (!list) return;
  list.innerHTML = '';
  const guns = G.warehouse.filter(function(it){ return inferType(it) === 'weapon'; });
  if (guns.length === 0) {
    list.innerHTML = '<p style="color:#666;font-size:12px">仓库中没有枪械。</p>';
    const p = document.getElementById('wb-panel'); if (p) p.innerHTML = '';
    return;
  }
  guns.forEach(function(g){
    const el = document.createElement('div');
    el.className = 'wb-gun-item' + (wbCurrentGun && wbCurrentGun.uid === g.uid ? ' active' : '');
    el.innerHTML = '<span class="emoji">🔫</span>' + g.name;
    el.onclick = function(){ wbCurrentGun = g; renderWorkbench(); };
    list.appendChild(el);
  });
  if (!wbCurrentGun || !guns.find(function(g){return g.uid === wbCurrentGun.uid;})) wbCurrentGun = guns[0];
  renderWbPanel();
}

function renderWbPanel() {
  const panel = document.getElementById('wb-panel');
  if (!panel || !wbCurrentGun) return;
  const parts = G.parts[wbCurrentGun.uid] || {};
  const slotLabels = {scope:'瞄准镜', muzzle:'枪口', mag:'弹匣', stock:'枪托', grip:'握把'};
  const slotsHtml = Object.keys(slotLabels).map(function(slot){
    const p = parts[slot];
    return '<div class="wb-slot ' + (p?'filled':'') + '"><div class="wb-slot-label">' + slotLabels[slot] + '</div><div class="wb-slot-val">' + (p ? p.name : '空') + '</div></div>';
  }).join('');
  panel.innerHTML = '<div class="wb-gun-info"><div class="big-icon">🔫</div><div class="wb-stats"><div><b>' + wbCurrentGun.name + '</b></div><div>基础伤害：' + wbCurrentGun.dmg + '</div><div>射速：' + wbCurrentGun.rate + ' · 弹匣：' + wbCurrentGun.mag + '</div></div></div>' +
    '<h3 class="sub-title">配件槽位</h3><div class="wb-slots">' + slotsHtml + '</div>' +
    '<h3 class="sub-title">仓库可用配件</h3><div id="wb-part-list" class="grid"></div>';
  const partList = document.getElementById('wb-part-list');
  const pw = G.warehouse.filter(function(it){ return inferType(it) === 'part'; });
  if (pw.length === 0) {
    partList.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:20px">仓库中没有配件。</p>';
    return;
  }
  pw.forEach(function(p){
    const card = document.createElement('div');
    card.className = 'item lv3';
    card.innerHTML = '<span class="emoji">🔧</span><span class="name-mini">' + p.name + '</span>';
    card.onclick = function(){
      G.parts[wbCurrentGun.uid] = G.parts[wbCurrentGun.uid] || {};
      if (G.parts[wbCurrentGun.uid][p.slot]) addToWarehouse(G.parts[wbCurrentGun.uid][p.slot]);
      G.parts[wbCurrentGun.uid][p.slot] = p;
      removeFromWarehouse(p.uid);
      G.stats.mods = (G.stats.mods||0) + 1;
      save();
      renderWorkbench();
      checkAchievements();
      toast('安装 ' + p.name, 'success');
    };
    partList.appendChild(card);
  });
}

/* ========== 任务 ========== */
function renderQuest() {
  renderTopbar();
  const el = document.getElementById('quest-list');
  if (!el) return;
  el.innerHTML = G.quests.map(function(q){
    return '<div class="map-card" style="padding:14px;margin-bottom:10px">' +
      '<div style="font-size:16px;color:#c8742a;font-weight:bold">' + q.name + '</div>' +
      '<div style="font-size:12px;color:#8a8578;margin:6px 0">' + q.desc + '</div>' +
      '<div style="font-size:12px;color:#c8742a">进度 ' + q.progress + '/' + q.target + '</div>' +
      '<div style="font-size:12px;color:#4caf50">奖励 ' + fmt(q.reward) + ' 币</div>' +
      (q.done ? '<div style="color:#4caf50;margin-top:6px">✅ 已完成</div>' : '') +
    '</div>';
  }).join('');
}

function updateQuests(evt, val) {
  G.quests.forEach(function(q){
    if (q.done) return;
    if (q.id === 'q1' && evt === 'extract') q.progress = Math.min(q.target, q.progress + 1);
    if (q.id === 'q2' && evt === 'kill') q.progress = Math.min(q.target, q.progress + (val||1));
    if (q.id === 'q3' && evt === 'loot3') q.progress = Math.min(q.target, q.progress + 1);
    if (q.id === 'q4' && evt === 'boss') q.progress = Math.min(q.target, q.progress + 1);
    if (q.progress >= q.target) {
      q.done = true;
      G.money += q.reward;
      setTimeout(function(){ toast('任务完成：' + q.name + ' +' + fmt(q.reward) + '币', 'success'); }, 200);
      if (q.id === 'q1' && G.unlockedMaps.indexOf('mine') < 0) G.unlockedMaps.push('mine');
      if (q.id === 'q4' && G.unlockedMaps.indexOf('facility') < 0) G.unlockedMaps.push('facility');
    }
  });
}

/* ========== 成就 ========== */
function checkAchievements() {
  let changed = false;
  ACHIEVEMENTS.forEach(function(a){
    if (G.achievements[a.id]) return;
    let cur = 0;
    if (a.type === 'raid') cur = G.stats.raids;
    else if (a.type === 'extract') cur = G.stats.extracts;
    else if (a.type === 'money') cur = G.money;
    else if (a.type === 'kill') cur = G.stats.totalKills;
    else if (a.type === 'loot') cur = G.stats.totalLoot;
    else if (a.type === 'boss') cur = G.stats.bossKills;
    else if (a.type === 'melee') cur = G.stats.meleeKills;
    else if (a.type === 'gun') cur = G.stats.gunKills;
    else if (a.type === 'grenade') cur = G.stats.grenadeKills;
    else if (a.type === 'fullEquip') cur = (G.equipment.weapon && G.equipment.armor && G.equipment.helmet && G.equipment.meds.length) ? 1 : 0;
    else if (a.type === 'haveGuns') cur = G.warehouse.filter(function(it){return inferType(it) === 'weapon';}).length;
    else if (a.type === 'haveHigh') cur = G.warehouse.filter(function(it){return (it.level||0) >= 5;}).length;
    else if (a.type === 'haveLegendary') cur = G.warehouse.find(function(it){return it.level === 7;}) ? 1 : 0;
    else if (a.type === 'level') cur = G.level;
    else if (a.type === 'checkin') cur = G.checkinStreak;
    else if (a.type === 'modGun') cur = G.stats.mods;
    else if (a.type === 'allAch') cur = Object.keys(G.achievements).length;
    if (cur >= a.target) {
      G.achievements[a.id] = true;
      G.money += a.reward;
      changed = true;
      setTimeout(function(){ toast('🏅 成就解锁：' + a.name + ' +' + fmt(a.reward), 'success'); }, 300);
    }
  });
  if (changed) save();
}

function renderAchieve() {
  renderTopbar();
  const el = document.getElementById('ach-list');
  if (!el) return;
  let done = 0;
  el.innerHTML = ACHIEVEMENTS.map(function(a){
    const ok = !!G.achievements[a.id];
    if (ok) done++;
    return '<div class="card-row ' + (ok?'done':'') + '"><div class="ico">' + (ok?'✅':'⭕') + '</div><div class="info"><div class="ttl">' + a.name + '</div><div class="sub">' + a.desc + '</div></div><div class="rw">' + fmt(a.reward) + '</div></div>';
  }).join('');
  const c = document.getElementById('ach-count'); if (c) c.textContent = done + '/' + ACHIEVEMENTS.length;
}

/* ========== 邮件 ========== */
function renderMail() {
  renderTopbar();
  const el = document.getElementById('mail-list');
  if (!el) return;
  if (G.mails.length === 0) { el.innerHTML = '<p style="color:#666;text-align:center;padding:40px">暂无邮件。</p>'; return; }
  el.innerHTML = G.mails.map(function(m, i){
    return '<div class="card-row ' + (m.read?'done':'') + '" onclick="readMail(' + i + ')"><div class="ico">📧</div><div class="info"><div class="ttl">' + m.title + '</div><div class="sub">' + m.time + '</div></div>' + (m.read?'':'<div class="rw">领取</div>') + '</div>';
  }).join('');
}

function readMail(i) {
  const m = G.mails[i];
  if (!m || m.read) return;
  if (m.money) G.money += m.money;
  if (m.items) m.items.forEach(function(it){ addToWarehouse(it); });
  m.read = true;
  save();
  renderMail();
  renderTopbar();
  checkAchievements();
  toast('领取：' + (m.money ? fmt(m.money) + '币 ' : '') + (m.items ? m.items.length + '件物品' : ''), 'success');
}

/* ========== 签到 ========== */
function renderCheckin() {
  renderTopbar();
  const el = document.getElementById('checkin-grid');
  if (!el) return;
  const today = new Date().toDateString();
  const checkedToday = G.lastCheckin === today;
  el.innerHTML = DAILY_REWARDS.map(function(r){
    const done = G.checkinDays.indexOf(r.day) >= 0;
    const isToday = !done && !checkedToday && (G.checkinStreak === r.day-1 || (G.checkinStreak >= 7 && r.day === 1));
    return '<div class="checkin-cell ' + (done?'done':'') + ' ' + (isToday?'today':'') + '" onclick="doCheckin(' + r.day + ')"><div class="day">第' + r.day + '天</div><div style="font-size:22px;margin:4px 0">' + (r.item ? r.item.icon : '💰') + '</div><div class="rw">' + fmt(r.money) + '</div>' + (done?'<div style="color:#4caf50;font-size:10px">已领</div>':'') + '</div>';
  }).join('');
}

function doCheckin(day) {
  const today = new Date().toDateString();
  if (G.lastCheckin === today) { toast('今天已签到', 'error'); return; }
  const r = DAILY_REWARDS[day-1]; if (!r) return;
  if (G.checkinDays.indexOf(day) >= 0) { toast('该奖励已领取', 'error'); return; }
  const expectDay = (G.checkinStreak % 7) + 1;
  if (day !== expectDay) { toast('请按顺序签到，下一个第' + expectDay + '天', 'error'); return; }
  G.money += r.money;
  if (r.item) addToWarehouse(clone(r.item));
  G.checkinDays.push(day);
  G.checkinStreak++;
  G.lastCheckin = today;
  save();
  renderCheckin();
  renderTopbar();
  checkAchievements();
  toast('签到成功 +' + fmt(r.money) + '币' + (r.item ? ' 和 ' + r.item.name : ''), 'success');
}

/* ========== 段位 ========== */
function renderRank() {
  renderTopbar();
  const el = document.getElementById('rank-body');
  if (!el) return;
  const p = G.rankPoints || 0;
  el.innerHTML = '<div class="map-card"><div style="font-size:32px">' + getRankName() + '</div><div style="color:#8a8578;margin:8px 0">段位积分：' + fmt(p) + '</div><div style="color:#c8742a;font-size:12px">撤离+10 · 击杀+2 · 死亡-5</div></div><h3 class="sub-title">段位阶梯</h3>' +
    RANKS.map(function(r){
      return '<div class="card-row ' + (p >= r.min ? 'done' : '') + '"><div class="ico">' + r.icon + '</div><div class="info"><div class="ttl">' + r.name + '</div><div class="sub">' + fmt(r.min) + ' 分</div></div></div>';
    }).join('');
}

/* ========== 战报 ========== */
function renderQuestLog() {
  renderTopbar();
  const el = document.getElementById('quest-log-list');
  if (!el) return;
  if (!G.questLog || G.questLog.length === 0) { el.innerHTML = '<p style="color:#666;text-align:center;padding:40px">暂无战报。</p>'; return; }
  el.innerHTML = G.questLog.slice(-30).reverse().map(function(r){
    return '<div class="map-card" style="padding:10px;text-align:left;font-size:12px"><div style="color:' + (r.success ? '#4caf50' : '#c62828') + ';font-weight:bold">' + (r.success ? '✅ 撤离成功' : '❌ 任务失败') + '</div><div style="color:#8a8578;margin-top:4px">' + r.map + ' · 击杀 ' + r.kills + ' · 战利 ' + fmt(r.loot) + '</div></div>';
  }).join('');
}

/* ========== 设置 ========== */
function renderSettings() {
  renderTopbar();
  const el = document.getElementById('settings-body');
  if (!el) return;
  el.innerHTML = '<div class="map-card" style="text-align:left">' +
    '<h3 style="color:#c8742a;margin-bottom:10px">游戏设置</h3>' +
    '<div style="display:flex;justify-content:space-between;padding:8px 0;cursor:pointer" onclick="toggleSetting(\'sfx\')"><span>音效</span><span>' + (G.settings.sfx ? '开' : '关') + '</span></div>' +
    '<div style="display:flex;justify-content:space-between;padding:8px 0;cursor:pointer" onclick="toggleSetting(\'autoMed\')"><span>自动用药</span><span>' + (G.settings.autoMed ? '开' : '关') + '</span></div>' +
    '<div style="display:flex;justify-content:space-between;padding:8px 0;cursor:pointer" onclick="toggleSetting(\'aimAssist\')"><span>辅助瞄准</span><span>' + (G.settings.aimAssist ? '开' : '关') + '</span></div>' +
    '</div>' +
    '<div class="map-card" style="text-align:left;margin-top:10px">' +
    '<h3 style="color:#c8742a;margin-bottom:10px">存档</h3>' +
    '<button style="width:100%;padding:10px;background:#c8742a;color:#0a0d08;border-radius:4px;margin-bottom:8px;font-family:inherit" onclick="exportSave()">导出存档</button>' +
    '<button style="width:100%;padding:10px;background:#4caf50;color:#0a0d08;border-radius:4px;margin-bottom:8px;font-family:inherit" onclick="importSave()">导入存档</button>' +
    '<button style="width:100%;padding:10px;background:#c62828;color:#fff;border-radius:4px;font-family:inherit" onclick="resetSave()">重置存档</button>' +
    '</div>' +
    '<div class="map-card" style="text-align:left;margin-top:10px;font-size:11px;color:#8a8578">' +
    '<p>棍母小镇 v6.0 终极版</p>' +
    '<p style="margin-top:4px">撤离 ' + (G.stats.extracts||0) + ' · 击杀 ' + (G.stats.totalKills||0) + ' · 阵亡 ' + (G.stats.deaths||0) + '</p>' +
    '</div>';
}

function toggleSetting(k) { G.settings[k] = !G.settings[k]; save(); renderSettings(); }
function exportSave() {
  try {
    const str = btoa(unescape(encodeURIComponent(JSON.stringify(G))));
    prompt('复制存档码：', str);
  } catch(e) { toast('导出失败', 'error'); }
}
function importSave() {
  const str = prompt('粘贴存档码：');
  if (!str) return;
  try {
    G = JSON.parse(decodeURIComponent(escape(atob(str))));
    save();
    renderTopbar();
    go('lobby');
    toast('导入成功', 'success');
  } catch(e) { toast('导入失败', 'error'); }
}
function resetSave() {
  if (!confirm('确定重置所有进度？')) return;
  localStorage.removeItem(SAVE_KEY);
  location.reload();
}

/* ========== 地图 ========== */
function renderMap() {
  renderTopbar();
  const body = document.getElementById('map-list');
  if (!body) return;
  const ev = document.getElementById('map-equip-value');
  if (ev) ev.textContent = fmt(equipValue());
  body.innerHTML = Object.keys(MAPS).map(function(k){
    const m = MAPS[k];
    const locked = G.unlockedMaps.indexOf(m.id) < 0;
    const btns = locked ? '' :
      '<div class="difficulty-row">' +
      '<button onclick="startRaid(\'' + m.id + '\',\'normal\')">普通 ×1.0</button>' +
      '<button onclick="startRaid(\'' + m.id + '\',\'hard\')" class="' + (equipValue() < 50000 ? 'locked' : '') + '">困难 ×1.5</button>' +
      '<button onclick="startRaid(\'' + m.id + '\',\'lockdown\')" class="' + (equipValue() < 150000 ? 'locked' : '') + '">封锁 ×2.5</button>' +
      '</div>';
    return '<div class="map-card" style="' + (locked?'opacity:.4':'') + '"><div class="map-name">' + m.name + '</div><div class="map-desc">' + m.desc + (locked?' · 未解锁':'') + '</div>' + btns + '</div>';
  }).join('');
}

/* ========== 局内 ========== */
let raid = null;
let raidTimer = null;
let gameLoopTimer = null;
let bulletsTimer = null;
let fireInterval = null;
let zoneTimer = null;
let playerPos = {x:2000, y:2000};
let moveDir = {x:0, y:0};
let aimDir = {x:1, y:0};
let firing = false;
let extractCountdown = null;

function startRaid(mapId, diffKey) {
  try {
    const diff = DIFFICULTY[diffKey];
    const map = MAPS[mapId];
    if (equipValue() < diff.minValue) { toast(diff.name + '难度需携带价值 ≥ ' + fmt(diff.minValue), 'error'); return; }
    if (!G.equipment.weapon && !G.equipment.melee) {
      G.equipment.melee = clone(MELEES[0]);
      G.equipment.melee.uid = uid();
      G.equipment.melee.type = 'melee';
    }
    go('raid');
    setTimeout(function(){ initRaid(mapId, diffKey, diff, map); }, 80);
  } catch(e) { toast('启动失败：' + e.message, 'error'); }
}

function initRaid(mapId, diffKey, diff, map) {
  try {
    const field = document.getElementById('raid-field');
    if (!field) { toast('局内界面加载失败', 'error'); return; }
    field.innerHTML = '';
    playerPos = {x:2000, y:2000};
    moveDir = {x:0, y:0};
    aimDir = {x:1, y:0};
    firing = false;

    const gun = G.equipment.weapon ? clone(G.equipment.weapon) : null;
    if (gun) {
      const parts = G.parts[gun.uid] || {};
      if (parts.muzzle && parts.muzzle.name === '补偿器') gun.dmg = Math.round(gun.dmg * 1.1);
      if (parts.mag && parts.mag.name === '扩容弹匣') gun.mag += 10;
      if (parts.scope && parts.scope.name === '四倍镜') gun.range += 200;
    }

    raid = {
      mapId: mapId, diff: diffKey, luck: diff.luck * map.lootMul,
      hp: 100, maxHp: 100, timeLeft: 300,
      lootValue: 0, backpack: [],
      enemies: [], boxes: [], extract: null,
      armor: G.equipment.armor ? clone(G.equipment.armor) : null,
      helmet: G.equipment.helmet ? clone(G.equipment.helmet) : null,
      log: [], over: false, kills: 0,
      ammo: G.equipment.ammo || 0,
      magSize: gun ? gun.mag : 0,
      magAmmo: gun ? gun.mag : 0,
      weapon: gun,
      melee: G.equipment.melee ? clone(G.equipment.melee) : clone(MELEES[0]),
      bullets: [],
      isKnifeRun: !G.equipment.weapon,
      zoneActive: false, zoneCenter: {x:2000, y:2000}, zoneRadius: 2400, zoneTimer: 180
    };

    const pEl = document.createElement('div');
    pEl.id = 'player'; pEl.textContent = '🧍';
    pEl.style.left = '2000px'; pEl.style.top = '2000px';
    field.appendChild(pEl);

    for (let i = 0; i < 80; i++) {
      const t = randPick(['house','rock','tree','crate','car','']);
      if (!t) continue;
      const d = document.createElement('div');
      d.className = 'deco ' + t;
      d.textContent = t === 'house' ? '🏚️' : t === 'rock' ? '🪨' : t === 'tree' ? '🌲' : t === 'crate' ? '📦' : '🚗';
      d.style.left = rand(100, 3900) + 'px';
      d.style.top = rand(100, 3900) + 'px';
      field.appendChild(d);
    }

    const count = Math.round(rand(diff.ec[0], diff.ec[1]) * map.enMul);
    for (let i = 0; i < count; i++) spawnEnemy(randPick(ENEMIES), field);
    if (diff.boss) spawnEnemy(BOSS, field);

    const boxCount = Math.round(20 * map.lootMul);
    for (let i = 0; i < boxCount; i++) spawnBox(randPick(CONTAINERS), field);

    spawnExtract(field);
    bindRaidControls();
    updateCamera();
    renderRaidHUD();
    updateMedSlots();

    const fb = document.getElementById('btn-fire');
    const mb = document.getElementById('btn-melee');
    if (fb && mb) {
      if (raid.weapon) { fb.style.display = 'flex'; mb.style.display = 'none'; }
      else { fb.style.display = 'none'; mb.style.display = 'flex'; }
    }

    clearInterval(raidTimer);
    raidTimer = setInterval(function(){
      if (!raid || raid.over) return;
      raid.timeLeft--;
      if (raid.timeLeft <= 0) { endRaid(false); return; }
      renderRaidHUD();
      drawMinimap();
    }, 1000);

    clearInterval(gameLoopTimer);
    gameLoopTimer = setInterval(gameLoop, 50);
    clearInterval(bulletsTimer);
    bulletsTimer = setInterval(updateBullets, 30);

    clearInterval(zoneTimer);
    zoneTimer = setInterval(function(){
      if (!raid || raid.over) return;
      raid.zoneTimer--;
      if (raid.zoneTimer <= 0) {
        raid.zoneActive = true;
        raid.zoneRadius = Math.max(400, raid.zoneRadius - 80);
        raid.zoneTimer = 15;
        if (raid.zoneRadius <= 400) raid.zoneTimer = 99999;
      }
      renderRaidHUD();
    }, 1000);

    setTimeout(function(){ if (raid && !raid.over) spawnAirdrop(); }, 30000);
    setTimeout(function(){ if (raid && !raid.over) spawnAirdrop(); }, 90000);
  } catch(err) { toast('进入地图失败：' + err.message, 'error'); }
}

function spawnEnemy(tpl, field) {
  const el = document.createElement('div');
  let cls = 'enemy';
  if (tpl.id === 'BOSS') cls += ' boss';
  else if (tpl.hp >= 200) cls += ' tank';
  else if (tpl.hp >= 120) cls += ' elite';
  el.className = cls;
  const x = rand(200, 3800), y = rand(200, 3800);
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  el.innerHTML = '<div class="hp-mini"><div style="width:100%"></div></div>' + tpl.icon;
  const obj = {el:el, tpl:clone(tpl), hp:tpl.hp, x:x, y:y, alive:true, cd:0, alert:false};
  raid.enemies.push(obj);
  field.appendChild(el);
}

function spawnBox(tpl, field) {
  const el = document.createElement('div');
  el.className = 'loot-box';
  el.textContent = tpl.icon;
  const x = rand(200, 3800), y = rand(200, 3800);
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  const obj = {el:el, tpl:tpl, x:x, y:y, searched:false};
  el.onclick = function(e){ e.stopPropagation(); searchBox(obj); };
  raid.boxes.push(obj);
  field.appendChild(el);
}

function spawnExtract(field) {
  const el = document.createElement('div');
  el.className = 'extract-zone';
  el.textContent = '撤离';
  const x = rand(300, 3700), y = rand(300, 3700);
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  const obj = {el:el, x:x, y:y};
  el.onclick = function(e){ e.stopPropagation(); tryExtract(); };
  raid.extract = obj;
  field.appendChild(el);
}

function spawnAirdrop() {
  if (!raid || raid.over) return;
  const field = document.getElementById('raid-field');
  const el = document.createElement('div');
  el.className = 'loot-box airdrop';
  el.textContent = '🎁';
  const x = rand(300, 3700), y = rand(300, 3700);
  el.style.left = x + 'px';
  el.style.top = y + 'px';
  el.style.opacity = '0';
  el.style.transition = 'opacity .5s';
  const obj = {el:el, tpl:{tier:'boss', icon:'🎁'}, x:x, y:y, searched:false, airdrop:true};
  el.onclick = function(e){ e.stopPropagation(); searchBox(obj); };
  raid.boxes.push(obj);
  field.appendChild(el);
  setTimeout(function(){ el.style.opacity = '1'; }, 100);
  raid.log.push('📦 空投已降落');
  renderRaidHUD();
}

function bindRaidControls() {
  const jz = document.getElementById('joystick-zone');
  const js = document.getElementById('joystick-stick');
  const jb = document.getElementById('joystick-base');
  if (jz && js && jb) {
    let jActive = false;
    const jStart = function(e){ e.preventDefault(); jActive = true; };
    const jMove = function(e){
      if (!jActive) return;
      e.preventDefault();
      const t = e.touches ? e.touches[0] : e;
      const r = jb.getBoundingClientRect();
      const cx = r.left + r.width/2, cy = r.top + r.height/2;
      let dx = t.clientX - cx, dy = t.clientY - cy;
      const len = Math.hypot(dx, dy), max = r.width/2 - 20;
      if (len > max) { dx = dx/len*max; dy = dy/len*max; }
      js.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      if (Math.hypot(dx, dy) > 10) moveDir = {x:dx/max, y:dy/max};
      else moveDir = {x:0, y:0};
    };
    const jEnd = function(){ jActive = false; moveDir = {x:0, y:0}; js.style.transform = ''; };
    jz.addEventListener('touchstart', jStart, {passive:false});
    jz.addEventListener('touchmove', jMove, {passive:false});
    jz.addEventListener('touchend', jEnd);
  }
  const az = document.getElementById('aim-zone');
  const as = document.getElementById('aim-stick');
  const ab = document.getElementById('aim-base');
  if (az && as && ab) {
    let aActive = false;
    const aStart = function(e){ e.preventDefault(); aActive = true; };
    const aMove = function(e){
      if (!aActive) return;
      e.preventDefault();
      const t = e.touches ? e.touches[0] : e;
      const r = ab.getBoundingClientRect();
      const cx = r.left + r.width/2, cy = r.top + r.height/2;
      let dx = t.clientX - cx, dy = t.clientY - cy;
      const len = Math.hypot(dx, dy), max = r.width/2 - 18;
      if (len > max) { dx = dx/len*max; dy = dy/len*max; }
      as.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      const nlen = Math.hypot(dx, dy);
      if (nlen > 8) { aimDir = {x:dx/nlen, y:dy/nlen}; updateCrosshair(); }
    };
    const aEnd = function(){ aActive = false; as.style.transform = ''; };
    az.addEventListener('touchstart', aStart, {passive:false});
    az.addEventListener('touchmove', aMove, {passive:false});
    az.addEventListener('touchend', aEnd);
  }
  const fb = document.getElementById('btn-fire');
  if (fb) {
    fb.addEventListener('touchstart', function(e){ e.preventDefault(); startFire(); });
    fb.addEventListener('touchend', function(e){ e.preventDefault(); stopFire(); });
  }
  const mb = document.getElementById('btn-melee');
  if (mb) {
    mb.addEventListener('touchstart', function(e){ e.preventDefault(); meleeAttack(); });
  }
}

function updateCrosshair() {
  const ch = document.getElementById('crosshair');
  if (!ch) return;
  const dist = 80;
  const vw = window.innerWidth/2, vh = window.innerHeight/2;
  ch.style.left = (vw + aimDir.x * dist) + 'px';
  ch.style.top = (vh + aimDir.y * dist) + 'px';
}

function updateCamera() {
  if (!raid) return;
  const cam = document.getElementById('raid-camera');
  if (!cam) return;
  const cx = playerPos.x - window.innerWidth/2;
  const cy = playerPos.y - window.innerHeight/2;
  cam.style.transform = 'translate(' + (-cx) + 'px,' + (-cy) + 'px)';
}

function startFire() {
  if (!raid || raid.over || !raid.weapon) return;
  firing = true;
  const fb = document.getElementById('btn-fire');
  if (fb) fb.classList.add('firing');
  const interval = Math.max(60, 60000/raid.weapon.rate);
  doFire();
  fireInterval = setInterval(doFire, interval);
}

function stopFire() {
  firing = false;
  const fb = document.getElementById('btn-fire');
  if (fb) fb.classList.remove('firing');
  clearInterval(fireInterval);
}

function doFire() {
  if (!raid || raid.over || !firing || !raid.weapon) return;
  if (raid.magAmmo <= 0) { autoReload(); return; }
  if (raid.ammo <= 0) { raid.log.push('没子弹了！'); renderRaidHUD(); stopFire(); return; }
  raid.magAmmo--;
  raid.ammo--;
  const bx = playerPos.x + aimDir.x * 30;
  const by = playerPos.y + aimDir.y * 30;
  const el = document.createElement('div');
  el.className = 'bullet';
  el.style.left = bx + 'px';
  el.style.top = by + 'px';
  const angle = Math.atan2(aimDir.y, aimDir.x) * 180/Math.PI;
  el.style.transform = 'translate(-50%,-50%) rotate(' + angle + 'deg)';
  document.getElementById('raid-field').appendChild(el);
  const speed = raid.weapon.bs;
  raid.bullets.push({el:el, x:bx, y:by, vx:aimDir.x*speed, vy:aimDir.y*speed, dmg:raid.weapon.dmg, range:raid.weapon.range, dist:0, owner:'player'});
  const m = document.createElement('div');
  m.className = 'muzzle';
  m.style.left = bx + 'px';
  m.style.top = by + 'px';
  document.getElementById('raid-field').appendChild(m);
  setTimeout(function(){ m.remove(); }, 120);
  renderRaidHUD();
}

function autoReload() {
  if (!raid || !raid.weapon) return;
  if (raid.ammo <= 0) { raid.log.push('无弹药可换'); renderRaidHUD(); return; }
  const need = raid.magSize - raid.magAmmo;
  const take = Math.min(need, raid.ammo);
  raid.magAmmo += take;
  raid.ammo -= take;
  raid.log.push('换弹 +' + take);
  renderRaidHUD();
}
function reload() { autoReload(); }

function meleeAttack() {
  if (!raid || raid.over) return;
  const m = raid.melee || MELEES[0];
  const now = Date.now();
  if (raid._lastMelee && now - raid._lastMelee < 60000/m.rate) return;
  raid._lastMelee = now;
  const checkRange = m.range + 20;
  const targets = raid.enemies.filter(function(e){
    return e.alive && Math.hypot(e.x - playerPos.x, e.y - playerPos.y) <= checkRange;
  });
  if (targets.length === 0) { raid.log.push('挥空了'); renderRaidHUD(); return; }
  const target = targets[0];
  hitEnemy(target, m.dmg, 'melee');
  raid.log.push('⚔️ ' + m.name + ' 命中 ' + target.tpl.name);
  renderRaidHUD();
  const slash = document.createElement('div');
  slash.className = 'slash';
  slash.style.left = target.x + 'px';
  slash.style.top = target.y + 'px';
  document.getElementById('raid-field').appendChild(slash);
  setTimeout(function(){ slash.remove(); }, 280);
}

function throwGrenade() {
  if (!raid || raid.over) return;
  if (raid._grenadeCd && Date.now() - raid._grenadeCd < 5000) { raid.log.push('手雷冷却中'); renderRaidHUD(); return; }
  raid._grenadeCd = Date.now();
  const tx = playerPos.x + aimDir.x * 240;
  const ty = playerPos.y + aimDir.y * 240;
  const el = document.createElement('div');
  el.className = 'explosion';
  el.style.left = tx + 'px';
  el.style.top = ty + 'px';
  document.getElementById('raid-field').appendChild(el);
  setTimeout(function(){ el.remove(); }, 700);
  raid.enemies.forEach(function(e){
    if (!e.alive) return;
    const d = Math.hypot(e.x - tx, e.y - ty);
    if (d < 140) hitEnemy(e, Math.round(140 * (1 - d/140)), 'grenade');
  });
  raid.log.push('💣 手雷爆炸');
  renderRaidHUD();
}

function updateBullets() {
  if (!raid || raid.over) return;
  for (let i = raid.bullets.length - 1; i >= 0; i--) {
    const b = raid.bullets[i];
    b.x += b.vx; b.y += b.vy;
    b.dist += Math.hypot(b.vx, b.vy);
    b.el.style.left = b.x + 'px';
    b.el.style.top = b.y + 'px';
    if (b.dist > b.range) { b.el.remove(); raid.bullets.splice(i, 1); continue; }
    if (b.owner === 'player') {
      for (let j = 0; j < raid.enemies.length; j++) {
        const e = raid.enemies[j];
        if (!e.alive) continue;
        if (Math.hypot(e.x - b.x, e.y - b.y) < 28) {
          hitEnemy(e, b.dmg, 'gun');
          b.el.remove();
          raid.bullets.splice(i, 1);
          break;
        }
      }
    }
  }
}

function hitEnemy(enemy, dmg, src) {
  enemy.hp -= dmg;
  enemy.el.classList.add('hurt');
  setTimeout(function(){ enemy.el.classList.remove('hurt'); }, 200);
  const hpBar = enemy.el.querySelector('.hp-mini>div');
  if (hpBar) hpBar.style.width = Math.max(0, enemy.hp/enemy.tpl.hp*100) + '%';
  const bl = document.createElement('div');
  bl.className = 'blood';
  bl.style.left = enemy.x + 'px';
  bl.style.top = enemy.y + 'px';
  document.getElementById('raid-field').appendChild(bl);
  setTimeout(function(){ bl.remove(); }, 450);
  if (enemy.hp <= 0) {
    enemy.alive = false;
    enemy.el.classList.add('dead');
    raid.kills++;
    G.stats.kills++;
    G.stats.totalKills++;
    if (src === 'melee') G.stats.meleeKills = (G.stats.meleeKills||0) + 1;
    else if (src === 'gun') G.stats.gunKills = (G.stats.gunKills||0) + 1;
    else if (src === 'grenade') G.stats.grenadeKills = (G.stats.grenadeKills||0) + 1;
    if (enemy.tpl.id === 'BOSS') G.stats.bossKills = (G.stats.bossKills||0) + 1;
    raid.log.push('击杀 ' + enemy.tpl.name);
    addKillFeed(enemy.tpl.name);
    const exp = enemy.tpl.exp || 10;
    addExp(exp);
    G.money += Math.round(exp * 20);
    updateQuests('kill', 1);
    const drop = rollLoot(enemy.tpl.dropTier);
    if (drop) {
      raid.backpack.push(drop);
      raid.lootValue += drop.price;
      raid.log.push('拾取 ' + drop.name + '（' + fmt(drop.price) + '）');
      if (drop.level === 3) updateQuests('loot3');
    }
    if (enemy.tpl.id === 'BOSS' && Math.random() < 0.7) {
      const sp = clone(BOSS.specialDrop);
      sp.uid = uid();
      raid.backpack.push(sp);
      raid.lootValue += sp.price;
      raid.log.push('★ 掉落 ' + sp.name);
      updateQuests('boss');
    }
    renderRaidHUD();
  }
}

function addKillFeed(name) {
  const kf = document.getElementById('kill-feed');
  if (!kf) return;
  const d = document.createElement('div');
  d.textContent = '💀 ' + name;
  kf.appendChild(d);
  setTimeout(function(){ d.remove(); }, 3000);
}

function addExp(n) {
  G.exp = (G.exp||0) + n;
  while (G.exp >= expToNext(G.level)) {
    G.exp -= expToNext(G.level);
    G.level++;
    setTimeout(function(){ toast('⭐ 升级到 Lv' + G.level, 'success'); }, 100);
  }
}

function gameLoop() {
  if (!raid || raid.over) return;
  if (moveDir.x !== 0 || moveDir.y !== 0) {
    const speed = raid.isKnifeRun ? 7 : 5.5;
    playerPos.x = Math.max(40, Math.min(3960, playerPos.x + moveDir.x * speed));
    playerPos.y = Math.max(40, Math.min(3960, playerPos.y + moveDir.y * speed));
    const p = document.getElementById('player');
    if (p) { p.style.left = playerPos.x + 'px'; p.style.top = playerPos.y + 'px'; }
    updateCamera();
  }
  if (raid.zoneActive) {
    const d = Math.hypot(playerPos.x - raid.zoneCenter.x, playerPos.y - raid.zoneCenter.y);
    if (d > raid.zoneRadius) { raid.hp -= 2; if (raid.hp <= 0) { raid.hp = 0; endRaid(false); return; } }
  }
  const now = Date.now();
  raid.enemies.forEach(function(e){
    if (!e.alive) return;
    const dx = playerPos.x - e.x, dy = playerPos.y - e.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 700) {
      if (!e.alert) { e.alert = true; e.el.classList.add('alert'); }
      if (dist > 90) {
        const sp = 1.4;
        e.x += (dx/dist) * sp;
        e.y += (dy/dist) * sp;
        e.el.style.left = e.x + 'px';
        e.el.style.top = e.y + 'px';
      }
      if (dist < 500 && now - e.cd > 1400) { e.cd = now; enemyShoot(e); }
    } else {
      e.alert = false;
      e.el.classList.remove('alert');
    }
  });
}

function enemyShoot(e) {
  let dmg = e.tpl.dmg;
  let red = 0;
  if (raid.armor && raid.armor.dur > 0) { red += raid.armor.red; raid.armor.dur -= rand(1,3); if (raid.armor.dur < 0) raid.armor.dur = 0; }
  if (raid.helmet && raid.helmet.dur > 0) { red += raid.helmet.red * 0.5; raid.helmet.dur -= rand(1,2); if (raid.helmet.dur < 0) raid.helmet.dur = 0; }
  dmg = dmg * (1 - Math.min(red, 0.85));
  raid.hp -= dmg;
  const flash = document.getElementById('damage-flash');
  if (flash) { flash.classList.add('on'); setTimeout(function(){ flash.classList.remove('on'); }, 80); }
  const p = document.getElementById('player');
  if (p) { p.style.transform = 'translate(-56%,-50%)'; setTimeout(function(){ p.style.transform = ''; }, 120); }
  if (raid.hp <= 0) { raid.hp = 0; endRaid(false); return; }
  if (G.settings.autoMed && raid.hp < raid.maxHp * 0.3 && G.equipment.meds.length > 0) useMed(0);
  renderRaidHUD();
}

function searchBox(obj) {
  if (!obj || obj.searched || !raid || raid.over) return;
  const dist = Math.hypot(obj.x - playerPos.x, obj.y - playerPos.y);
  if (dist > 90) { raid.log.push('太远了，走近点'); renderRaidHUD(); return; }
  obj.searched = true;
  obj.el.classList.add('searched');
  const drop = rollLoot(obj.tpl.tier);
  if (drop) {
    raid.backpack.push(drop);
    raid.lootValue += drop.price;
    raid.log.push('获得 ' + drop.name + '（' + fmt(drop.price) + '）');
    if (drop.level === 3) updateQuests('loot3');
  } else raid.log.push('空空如也');
  renderRaidHUD();
}

function useMed(i) {
  if (!raid || raid.over) return;
  const item = G.equipment.meds[i];
  if (!item) return;
  const heal = item.heal * raid.maxHp;
  raid.hp = Math.min(raid.maxHp, raid.hp + heal);
  G.equipment.meds.splice(i, 1);
  save();
  updateMedSlots();
  renderRaidHUD();
  raid.log.push('使用 ' + item.name + '，恢复 ' + Math.round(heal));
  renderRaidHUD();
}

function updateMedSlots() {
  const slots = document.querySelectorAll('#med-slots .med-slot');
  for (let i = 0; i < slots.length; i++) {
    const med = G.equipment.meds[i];
    slots[i].textContent = med ? med.icon : '➕';
    slots[i].classList.toggle('filled', !!med);
  }
}

function tryExtract() {
  if (!raid || raid.over) return;
  const d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
  if (d > 110) { raid.log.push('离撤离点太远'); renderRaidHUD(); return; }
  startExtractCountdown();
}

function startExtractCountdown() {
  if (extractCountdown) return;
  let count = 5;
  const ec = document.getElementById('extract-count'); if (ec) ec.textContent = count;
  const ep = document.getElementById('extract-progress'); if (ep) ep.classList.remove('hidden');
  extractCountdown = setInterval(function(){
    if (!raid || raid.over) { clearInterval(extractCountdown); extractCountdown = null; if (ep) ep.classList.add('hidden'); return; }
    const d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
    if (d > 140) { clearInterval(extractCountdown); extractCountdown = null; if (ep) ep.classList.add('hidden'); raid.log.push('离开撤离点，撤离中断'); renderRaidHUD(); return; }
    count--;
    if (ec) ec.textContent = count;
    if (count <= 0) { clearInterval(extractCountdown); extractCountdown = null; if (ep) ep.classList.add('hidden'); endRaid(true); }
  }, 1000);
}

function endRaid(success) {
  if (raid.over) return;
  raid.over = true;
  clearInterval(raidTimer);
  clearInterval(gameLoopTimer);
  clearInterval(bulletsTimer);
  clearInterval(fireInterval);
  clearInterval(zoneTimer);
  if (extractCountdown) { clearInterval(extractCountdown); extractCountdown = null; }
  G.stats.raids++;
  G.stats.totalLoot = (G.stats.totalLoot||0) + raid.lootValue;
  const record = {success:success, map:MAPS[raid.mapId].name, kills:raid.kills, loot:raid.lootValue};
  if (success) {
    G.stats.extracts++;
    G.rankPoints = (G.rankPoints||0) + 10;
    raid.backpack.forEach(function(it){ addToWarehouse(it); });
    if (raid.lootValue > G.stats.bestLoot) G.stats.bestLoot = raid.lootValue;
    updateQuests('extract');
  } else {
    G.stats.deaths++;
    G.rankPoints = Math.max(0, (G.rankPoints||0) - 5);
    G.equipment = {weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1'};
  }
  G.questLog.push(record);
  if (G.questLog.length > 50) G.questLog.shift();
  save();
  showResult(success);
}

function showResult(success) {
  const overlay = document.getElementById('result-overlay');
  if (!overlay) { go('lobby'); return; }
  overlay.classList.remove('hidden');
  document.getElementById('result-title').textContent = success ? '撤离成功' : '任务失败 · 装备丢失';
  const body = document.getElementById('result-body');
  if (success) {
    body.innerHTML = '<p>带回 ' + raid.backpack.length + ' 件物资</p><p>总价值：' + fmt(raid.lootValue) + ' 柯恩币</p><p>击杀：' + raid.kills + '</p><p>段位积分 +10</p>';
  } else {
    body.innerHTML = '<p>你在 ' + MAPS[raid.mapId].name + ' 倒下了</p><p>装备全部丢失，仓库物资安全</p><p>本次击杀：' + raid.kills + '</p><p>段位积分 -5</p>';
  }
  renderTopbar();
}

function renderRaidHUD() {
  if (!raid) return;
  const rl = document.getElementById('raid-loot'); if (rl) rl.textContent = fmt(raid.lootValue);
  const rk = document.getElementById('raid-kills'); if (rk) rk.textContent = raid.kills;
  const m = String(Math.floor(raid.timeLeft/60)).padStart(2, '0');
  const s = String(raid.timeLeft % 60).padStart(2, '0');
  const timer = document.getElementById('raid-timer');
  if (raid.weapon) {
    if (timer) timer.textContent = m + ':' + s;
    const ap = document.getElementById('ammo-pill'); if (ap) ap.style.display = 'block';
    const ra = document.getElementById('raid-ammo');
    if (ra) ra.textContent = raid.magAmmo + '/' + raid.magSize + ' (剩' + raid.ammo + ')';
    if (ap) ap.classList.toggle('low', raid.magAmmo <= raid.magSize * 0.3);
  } else {
    if (timer) timer.textContent = m + ':' + s + ' 🔪';
    const ap = document.getElementById('ammo-pill'); if (ap) ap.style.display = 'none';
  }
  const zp = document.getElementById('zone-pill');
  const zt = document.getElementById('zone-timer');
  if (zp && zt) {
    if (raid.zoneActive) { zp.style.display = 'block'; zt.textContent = raid.zoneRadius <= 400 ? '收缩完成' : '收缩中'; }
    else { zp.style.display = 'block'; zt.textContent = raid.zoneTimer + 's'; }
  }
  const hpPct = raid.hp / raid.maxHp * 100;
  const fill = document.getElementById('hp-fill');
  if (fill) { fill.style.width = hpPct + '%'; fill.classList.toggle('low', hpPct < 30); }
  const ht = document.getElementById('hp-text');
  if (ht) ht.textContent = Math.round(raid.hp) + ' / ' + raid.maxHp;
  const log = document.getElementById('raid-log');
  if (log) log.innerHTML = raid.log.slice(-5).map(function(l){ return '· ' + l; }).join('<br>');
  const si = document.getElementById('status-icons');
  if (si) {
    let html = '';
    if (raid.armor && raid.armor.dur > 0) html += '<div class="status-icon">🛡️ ' + raid.armor.dur + '</div>';
    if (raid.helmet && raid.helmet.dur > 0) html += '<div class="status-icon">⛑️ ' + raid.helmet.dur + '</div>';
    if (raid.isKnifeRun) html += '<div class="status-icon">🔪 跑刀</div>';
    si.innerHTML = html;
  }
}

function drawMinimap() {
  const c = document.getElementById('minimap');
  if (!c || !raid) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(10,13,8,0.9)';
  ctx.fillRect(0, 0, W, H);
  const scale = W / 4000;
  raid.enemies.forEach(function(e){
    if (!e.alive) return;
    ctx.fillStyle = e.tpl.id === 'BOSS' ? '#ffd700' : '#ff3b3b';
    ctx.beginPath();
    ctx.arc(e.x*scale, e.y*scale, 3, 0, Math.PI*2);
    ctx.fill();
  });
  ctx.fillStyle = '#c8742a';
  raid.boxes.forEach(function(b){
    if (b.searched) return;
    ctx.fillRect(b.x*scale-2, b.y*scale-2, 3, 3);
  });
  if (raid.extract) {
    ctx.fillStyle = '#4caf50';
    ctx.beginPath();
    ctx.arc(raid.extract.x*scale, raid.extract.y*scale, 5, 0, Math.PI*2);
    ctx.fill();
  }
  if (raid.zoneActive) {
    ctx.strokeStyle = 'rgba(255,59,59,.6)';
    ctx.beginPath();
    ctx.arc(raid.zoneCenter.x*scale, raid.zoneCenter.y*scale, raid.zoneRadius*scale, 0, Math.PI*2);
    ctx.stroke();
  }
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(playerPos.x*scale, playerPos.y*scale, 4, 0, Math.PI*2);
  ctx.fill();
}

/* ========== 键盘 ========== */
window.addEventListener('keydown', function(e){
  if (!raid || raid.over) return;
  if (e.key === 'r' || e.key === 'R') reload();
  if (e.key === 'e' || e.key === 'E') {
    const b = raid.boxes.filter(function(b){return !b.searched;}).sort(function(a,c){
      return Math.hypot(a.x-playerPos.x, a.y-playerPos.y) - Math.hypot(c.x-playerPos.x, c.y-playerPos.y);
    })[0];
    if (b) searchBox(b);
  }
});

/* ========== 屏幕方向 ========== */
function checkOrientation() {
  const tip = document.getElementById('rotate-tip');
  if (!tip) return;
  tip.style.display = (window.innerHeight > window.innerWidth) ? 'flex' : 'none';
}
window.addEventListener('resize', checkOrientation);
window.addEventListener('orientationchange', checkOrientation);

/* ========== 首次启动 ========== */
function initMails() {
  if (!G.mails || G.mails.length === 0) {
    G.mails = [
      {title:'欢迎来到棍母小镇', time:new Date().toLocaleString(), money:100000, read:false},
      {title:'新手礼包', time:new Date().toLocaleString(), items:[clone(MEDS[1]), clone(MELEES[1])], read:false},
      {title:'开服补偿', time:new Date().toLocaleString(), money:50000, read:false}
    ];
    save();
  }
}

/* ========== 启动 ========== */
function boot() {
  try {
    load();
    initMails();
    checkOrientation();
    renderTopbar();
    go('lobby');
    console.log('棍母小镇 v6.0 启动完成');
  } catch(e) {
    console.error('Boot error:', e);
    document.body.innerHTML = '<div style="padding:40px;color:#fff;font-family:monospace;background:#0a0d08;height:100vh"><h1 style="color:#c8742a">棍母小镇</h1><p style="color:#ff3b3b;margin-top:20px">启动错误：' + e.message + '</p><pre style="color:#888;font-size:12px;margin-top:10px">' + (e.stack||'') + '</pre><button onclick="location.reload()" style="margin-top:20px;padding:10px 20px;background:#c8742a;color:#000;border:none;border-radius:4px">重新加载</button></div>';
  }
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();