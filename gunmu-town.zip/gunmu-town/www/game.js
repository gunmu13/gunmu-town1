/* =========================================================
   棍母小镇 · game.js · 完整版（修复黑屏 + 全部功能）
   ========================================================= */

/* ================= 1. 数据层 ================= */
const LOOT_NAMES = {
  1: ['锈铁钉','破布条','空塑料瓶','旧电池','铜线圈','断扳手','黄胶带','油气打火机',
      '短铅笔','碎橡皮','铁螺丝','小弹簧','麻绳头','汽水瓶盖','湿纸板','塑料袋',
      '瘪铝罐','脏纱布','木楔子','橡皮筋','订书钉','弯回形针','半截牙签'],
  2: ['医用绷带','压缩能量棒','打火机油','黄铜管','废电缆','铁皮工具箱','防水帆布',
      '旧手电','五号电池组','军用水壶','硬饼干','止血带','铁口哨','指南针',
      '裂镜放大镜','温度计','听诊器','手术刀片','注射器','氧气罐','滤毒罐芯'],
  3: ['军用口粮','红外滤镜','加密U盘','SIM卡组','夜视仪镜片','消音器零件','四倍瞄准镜',
      '防弹插板','战术手套','军靴','头盔衬垫','水袋','GPS模块','短波电台','双筒望远镜',
      '红色信号弹','灰烟幕弹','闪光雷','破片手雷','燃烧瓶','C4塑胶炸药'],
  4: ['金壳手表','金手镯','镀金手机','碎钻戒指','银质胸针','老式摄影机','矿卡显卡',
      '钯金线材','除颤器','宫廷银器','激光指示模块','液压扳手','掌上游戏机','黑胶唱片机',
      '古董打字机','维修手册','金豹小雕像','青花茶壶','宝石项链','胰岛素泵',
      '精密水平仪','鎏金酒杯','纯金小块'],
  5: ['热成像模块','目标定位模块','碎纹花瓶','金狮雕像','盛宴雕塑','金魔方',
      '军用加密硬盘','卫星电话','夜视仪','防弹公文包','钛合金板','碳纤维布',
      '军用无人机','高级工具组','稀有化学品'],
  6: ['理想国芯片','军用主控芯片','核废料样本','古代金币','陨石碎片','生物样本容器','量子处理器'],
  7: ['机密文件']
};
const LEVEL_PRICE = {1:[500,3000],2:[3000,8000],3:[8000,20000],4:[20000,60000],5:[60000,150000],6:[150000,400000],7:[800000,900000]};
const LEVEL_STYLE = {1:{icon:'🔩',cls:'lv1'},2:{icon:'🧰',cls:'lv2'},3:{icon:'📦',cls:'lv3'},4:{icon:'💎',cls:'lv4'},5:{icon:'🏆',cls:'lv5'},6:{icon:'👑',cls:'lv6'},7:{icon:'🗂️',cls:'lv7'}};

const ALL_LOOT = [];
(function(){
  let uid = 1;
  for (let lv = 1; lv <= 7; lv++) {
    const [lo, hi] = LEVEL_PRICE[lv];
    LOOT_NAMES[lv].forEach((name, i) => {
      const ratio = LOOT_NAMES[lv].length === 1 ? 1 : i / (LOOT_NAMES[lv].length - 1);
      const base = lo + (hi - lo) * ratio;
      const jitter = base * (Math.random() * 0.3 - 0.15);
      const price = Math.round((base + jitter) / 100) * 100;
      ALL_LOOT.push({ id:'L'+uid++, name, level:lv, price, icon:LEVEL_STYLE[lv].icon, cls:LEVEL_STYLE[lv].cls, type:'loot' });
    });
  }
})();

const WEAPONS = [
  { id:'W01', name:'锈蜂 PDW-9',  price:1000,   dmg:15, rate:900, mag:30, range:600,  bulletSpeed:14 },
  { id:'W02', name:'矿工 M870',   price:3000,   dmg:45, rate:60,  mag:6,  range:280,  bulletSpeed:9 },
  { id:'W03', name:'夜莺 MP5',    price:8000,   dmg:20, rate:800, mag:30, range:650,  bulletSpeed:14 },
  { id:'W04', name:'红壤 AK74N',  price:15000,  dmg:32, rate:650, mag:30, range:900,  bulletSpeed:16 },
  { id:'W05', name:'铁砧 SKS',    price:22000,  dmg:38, rate:300, mag:10, range:1000, bulletSpeed:17 },
  { id:'W06', name:'峡谷 BM59',   price:26000,  dmg:42, rate:350, mag:20, range:1000, bulletSpeed:17 },
  { id:'W07', name:'远钟 M14',    price:35000,  dmg:55, rate:250, mag:20, range:1100, bulletSpeed:18 },
  { id:'W08', name:'白桦 Mosin',  price:39000,  dmg:85, rate:40,  mag:5,  range:1300, bulletSpeed:22 },
  { id:'W09', name:'沙狐 MDR',    price:45000,  dmg:40, rate:700, mag:30, range:900,  bulletSpeed:15 },
  { id:'W10', name:'长枪管 M4A1', price:75000,  dmg:35, rate:800, mag:30, range:950,  bulletSpeed:16 },
  { id:'W11', name:'赤铁 AK-102', price:93000,  dmg:38, rate:650, mag:30, range:950,  bulletSpeed:16 },
  { id:'W12', name:'鹰眼 AUG',    price:120000, dmg:40, rate:750, mag:30, range:1000, bulletSpeed:16 },
  { id:'W13', name:'大西洋 FAL',  price:180000, dmg:52, rate:630, mag:20, range:1050, bulletSpeed:17 },
  { id:'W14', name:'幽灵 H416',   price:280000, dmg:45, rate:850, mag:30, range:1000, bulletSpeed:17 },
  { id:'W15', name:'审判 MK14',   price:450000, dmg:70, rate:400, mag:20, range:1200, bulletSpeed:19 }
];

const MELEES = [
  { id:'K01', name:'生锈小刀',   price:0,     dmg:20,  rate:180, range:50 },
  { id:'K02', name:'矿工匕首',   price:500,   dmg:35,  rate:200, range:55 },
  { id:'K03', name:'军用战术刀', price:2500,  dmg:55,  rate:220, range:60 },
  { id:'K04', name:'猎刀',       price:8000,  dmg:80,  rate:200, range:65 },
  { id:'K05', name:'消防斧',     price:20000, dmg:120, rate:150, range:70 },
  { id:'K06', name:'碳纤维砍刀', price:60000, dmg:180, rate:180, range:75 },
  { id:'K07', name:'武士刀',     price:200000,dmg:300, rate:200, range:85 }
];

const ARMORS = [
  { id:'A1', name:'特勤防弹衣',   price:2000,   dur:35, red:0.20, tier:1 },
  { id:'A2', name:'H-Tac 特勤甲', price:4500,   dur:45, red:0.30, tier:2 },
  { id:'A3', name:'KN 制式甲',    price:30000,  dur:55, red:0.45, tier:3 },
  { id:'A4', name:'SEK 壁垒甲',   price:100000, dur:65, red:0.55, tier:4 },
  { id:'A5', name:'926 复合甲',   price:200000, dur:75, red:0.65, tier:5 },
  { id:'A6', name:'IMTV 武士甲',  price:450000, dur:90, red:0.75, tier:6 }
];

const HELMETS = [
  { id:'H1', name:'工地安全帽',   price:800,    dur:20, red:0.15, tier:1 },
  { id:'H2', name:'战术软帽',     price:2500,   dur:28, red:0.25, tier:2 },
  { id:'H3', name:'KN 防弹盔',    price:18000,  dur:38, red:0.40, tier:3 },
  { id:'H4', name:'SEK 重型盔',   price:60000,  dur:50, red:0.52, tier:4 },
  { id:'H5', name:'926 复合盔',   price:130000, dur:62, red:0.62, tier:5 },
  { id:'H6', name:'IMTV 武士盔',  price:280000, dur:78, red:0.72, tier:6 }
];

const MEDS = [
  { id:'M1', name:'简易急救包', price:800,  heal:0.33, icon:'🩹' },
  { id:'M2', name:'军用急救包', price:2500, heal:0.50, icon:'💉' },
  { id:'M3', name:'白色医疗箱', price:8000, heal:1.00, icon:'🧰' }
];

const AMMO_TYPES = [
  { id:'AM1', name:'手枪弹',  price:2,  dmgMul:1.0, icon:'🔸' },
  { id:'AM2', name:'步枪弹',  price:4,  dmgMul:1.1, icon:'🔶' },
  { id:'AM3', name:'穿甲弹',  price:12, dmgMul:1.4, icon:'💥' }
];

const PARTS = [
  { id:'P01', name:'红点瞄准镜', price:5000,  slot:'scope',  eff:'+15%命中' },
  { id:'P02', name:'四倍镜',     price:20000, slot:'scope',  eff:'+30%命中' },
  { id:'P03', name:'消音器',     price:15000, slot:'muzzle', eff:'-敌人警戒' },
  { id:'P04', name:'补偿器',     price:8000,  slot:'muzzle', eff:'+10%伤害' },
  { id:'P05', name:'扩容弹匣',   price:12000, slot:'mag',    eff:'+10发弹匣' },
  { id:'P06', name:'快拔枪托',   price:6000,  slot:'stock',  eff:'-20%后坐力' },
  { id:'P07', name:'垂直握把',   price:4000,  slot:'grip',   eff:'+15%稳定性' },
  { id:'P08', name:'激光指示器', price:9000,  slot:'grip',   eff:'+10%腰射' }
];

const ENEMIES = [
  { id:'E01', name:'流浪拾荒者', hp:60,  dmg:8,  dropTier:'low',  icon:'🧟', exp:5 },
  { id:'E02', name:'武装匪徒',   hp:90,  dmg:15, dropTier:'low',  icon:'🥷', exp:10 },
  { id:'E03', name:'巡逻哨兵',   hp:80,  dmg:12, dropTier:'low',  icon:'💂', exp:8 },
  { id:'E04', name:'精英斥候',   hp:110, dmg:20, dropTier:'mid',  icon:'🕵️', exp:20 },
  { id:'E05', name:'重装守卫',   hp:150, dmg:18, dropTier:'mid',  icon:'🛡️', exp:25 },
  { id:'E06', name:'屋顶狙击手', hp:70,  dmg:35, dropTier:'mid',  icon:'🎯', exp:22 },
  { id:'E07', name:'废墟突击兵', hp:100, dmg:22, dropTier:'mid',  icon:'🔫', exp:18 },
  { id:'E08', name:'爆破专家',   hp:95,  dmg:28, dropTier:'high', icon:'💣', exp:35 },
  { id:'E09', name:'随队医疗兵', hp:85,  dmg:10, dropTier:'high', icon:'⛑️', exp:30 },
  { id:'E10', name:'精英指挥官', hp:130, dmg:25, dropTier:'high', icon:'🎖️', exp:45 }
];

const BOSS = {
  id:'BOSS', name:'“棍母”镇长', hp:500, dmg:40, dropTier:'boss', icon:'👺', exp:200,
  specialDrop: { id:'L-SP1', name:'镇长的金印章', level:6, price:520000, icon:'🔱', cls:'lv6', type:'loot' }
};

const CONTAINERS = [
  { id:'C01', name:'军用保险箱', tier:'low',  icon:'🗄️' },
  { id:'C02', name:'加密集装箱', tier:'low',  icon:'📦' },
  { id:'C03', name:'医疗空投',   tier:'low',  icon:'🚁' },
  { id:'C04', name:'武器箱',     tier:'low',  icon:'🔫' },
  { id:'C05', name:'电子保险箱', tier:'low',  icon:'💻' },
  { id:'C06', name:'军用背包',   tier:'mid',  icon:'🎒' },
  { id:'C07', name:'弹药箱',     tier:'mid',  icon:'📦' },
  { id:'C08', name:'工具箱',     tier:'mid',  icon:'🧰' },
  { id:'C09', name:'旅行箱',     tier:'mid',  icon:'🧳' },
  { id:'C10', name:'抽屉',       tier:'mid',  icon:'🗃️' },
  { id:'C11', name:'普通补给箱', tier:'high', icon:'📮' },
  { id:'C12', name:'散落物资点', tier:'high', icon:'🧷' },
  { id:'C13', name:'衣柜',       tier:'high', icon:'🚪' },
  { id:'C14', name:'废弃车辆',   tier:'high', icon:'🚗' }
];

const DROP_RATE = {
  low:  { 1:0.05, 2:0.10, 3:0.20, 4:0.35, 5:0.20, 6:0.08, 7:0.02 },
  mid:  { 1:0.15, 2:0.25, 3:0.30, 4:0.20, 5:0.08, 6:0.02, 7:0.00 },
  high: { 1:0.40, 2:0.35, 3:0.20, 4:0.05, 5:0.00, 6:0.00, 7:0.00 },
  boss: { 1:0.00, 2:0.05, 3:0.10, 4:0.25, 5:0.35, 6:0.20, 7:0.05 }
};

const MAPS = {
  town:     { id:'town',     name:'棍母小镇', desc:'废弃矿区旁的居民点',     lootMul:1.0, enMul:1.0 },
  mine:     { id:'mine',     name:'废弃矿洞', desc:'塌方频发，矿脉里全是宝', lootMul:1.4, enMul:1.3 },
  facility: { id:'facility', name:'旧军事设施', desc:'危险最高，机密出没',   lootMul:1.9, enMul:1.6 }
};

const DIFFICULTY = {
  normal:   { name:'普通', ec:[5,8],   luck:1.0, boss:false, minValue:0 },
  hard:     { name:'困难', ec:[8,12],  luck:1.5, boss:false, minValue:50000 },
  lockdown: { name:'封锁', ec:[12,15], luck:2.5, boss:true,  minValue:150000 }
};

/* ================= 2. 状态层 ================= */
const SAVE_KEY = 'gunmu_town_save_v4';
let G = null;

function newGame() {
  return {
    money: 500000,
    warehouse: [],
    equipment: { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' },
    parts: {},
    stats: { raids:0, extracts:0, deaths:0, kills:0, bestLoot:0, totalKills:0 },
    quest: { id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离', target:1, progress:0, reward:20000, done:false },
    questLog: [],
    unlockedMaps: ['town'],
    playerLevel: 1,
    playerExp: 0
  };
}

function save() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(G)); } catch(e){} }

function load() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (raw) { try { G = JSON.parse(raw); } catch(e){ G = newGame(); } }
  else G = newGame();
  if (!G.equipment) G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' };
  if (G.equipment.melee === undefined) G.equipment.melee = null;
  if (!G.equipment.meds) G.equipment.meds = [];
  if (G.equipment.ammo === undefined) G.equipment.ammo = 0;
  if (G.equipment.ammoType === undefined) G.equipment.ammoType = 'AM1';
  if (!G.parts) G.parts = {};
  if (!G.stats) G.stats = { raids:0, extracts:0, deaths:0, kills:0, bestLoot:0, totalKills:0 };
  if (G.stats.bestLoot === undefined) G.stats.bestLoot = 0;
  if (!G.quest) G.quest = { id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离', target:1, progress:0, reward:20000, done:false };
  if (!G.questLog) G.questLog = [];
  if (!G.unlockedMaps) G.unlockedMaps = ['town'];
  if (G.playerLevel === undefined) G.playerLevel = 1;
  if (G.playerExp === undefined) G.playerExp = 0;
}

/* ================= 3. 工具 ================= */
const $  = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const fmt = n => (n||0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const rand = (a,b) => Math.floor(Math.random()*(b-a+1))+a;
const randPick = a => a[Math.floor(Math.random()*a.length)];
const clone = o => JSON.parse(JSON.stringify(o));
const uid = () => 'U' + Date.now() + Math.random().toString(36).slice(2,6);

function rollLevel(tier) {
  const t = DROP_RATE[tier];
  if (!t) return 1;
  const r = Math.random(); let acc = 0;
  for (let lv = 1; lv <= 7; lv++) { acc += t[lv]; if (r < acc) return lv; }
  return 1;
}
function rollLoot(tier) {
  const lv = rollLevel(tier);
  const pool = ALL_LOOT.filter(x => x.level === lv);
  return clone(randPick(pool));
}
function addToWarehouse(item) {
  if (!item) return;
  if (!item.uid) item.uid = uid();
  if (!item.type) item.type = inferType(item);
  if (item.type === 'ammo') {
    const ex = G.warehouse.find(x => x.type === 'ammo' && x.ammoId === item.ammoId);
    if (ex) { ex.count = (ex.count||1) + (item.count||1); return; }
  }
  G.warehouse.push(item);
}
function removeFromWarehouse(u) {
  const i = G.warehouse.findIndex(x => x.uid === u);
  if (i >= 0) G.warehouse.splice(i, 1);
}
function inferType(item) {
  if (!item) return 'loot';
  if (item.type) return item.type;
  if (WEAPONS.find(w => w.id === item.id)) return 'weapon';
  if (MELEES.find(m => m.id === item.id)) return 'melee';
  if (ARMORS.find(a => a.id === item.id)) return 'armor';
  if (HELMETS.find(h => h.id === item.id)) return 'helmet';
  if (MEDS.find(m => m.id === item.id)) return 'med';
  if (AMMO_TYPES.find(a => a.id === item.id)) return 'ammo';
  if (PARTS.find(p => p.id === item.id)) return 'part';
  return 'loot';
}
function getTypeIcon(t) {
  return { weapon:'🔫', melee:'🔪', armor:'🛡️', helmet:'⛑️', med:'🩹', ammo:'🔸', part:'🔧', loot:'❔' }[t] || '❔';
}
function typeName(t) {
  return { loot:'变卖物', weapon:'枪械', melee:'刀具', armor:'护甲', helmet:'头盔', med:'药品', ammo:'弹药', part:'配件' }[t] || '未知';
}

/* ================= 4. 界面路由（强制显示） ================= */
let currentScreen = 'lobby';

function go(name) {
  try {
    var all = document.querySelectorAll('.screen');
    for (var i = 0; i < all.length; i++) {
      all[i].style.display = 'none';
      all[i].classList.add('hidden');
    }
    var target = document.getElementById('scr-' + name);
    if (!target) { console.error('screen not found:', name); return; }
    target.style.display = 'block';
    target.classList.remove('hidden');
    currentScreen = name;
    setTimeout(function() {
      try {
        if (name === 'lobby')     renderLobby();
        if (name === 'warehouse') renderWarehouse();
        if (name === 'market')    renderMarket('buy-weapon');
        if (name === 'loadout')   renderLoadout();
        if (name === 'map')       renderMap();
        if (name === 'quest')     renderQuest();
        if (name === 'workbench') renderWorkbench();
        if (name === 'quest-log') renderQuestLog();
      } catch(e) { console.error('render error:', e); }
    }, 10);
  } catch(e) {
    console.error('go() error:', e);
  }
}

function renderTopbar() {
  if (!G) return;
  var m = document.getElementById('money'); if (m) m.textContent = fmt(G.money);
  var w = document.getElementById('wh-count'); if (w) w.textContent = G.warehouse.length;
  var lv = document.getElementById('player-level'); if (lv) lv.textContent = G.playerLevel || 1;
  var ex = document.getElementById('player-exp'); if (ex) ex.textContent = Math.floor(G.playerExp || 0);
  var exm = document.getElementById('player-exp-max'); if (exm) exm.textContent = expToNext(G.playerLevel || 1);
  var k = document.getElementById('player-kills'); if (k) k.textContent = G.stats.totalKills || 0;
}
function expToNext(lv) { return 100 + (lv-1) * 80; }

/* ================= 5. 大厅（内联样式，不依赖 CSS） ================= */
function renderLobby() {
  renderTopbar();
  var scr = document.getElementById('scr-lobby');
  if (!scr) return;
  var eq = G.equipment;
  var wname = eq.weapon ? eq.weapon.name : '空';
  var aname = eq.armor ? eq.armor.name : '空';
  var hname = eq.helmet ? eq.helmet.name : '空';
  var currentMap = MAPS[G.unlockedMaps[G.unlockedMaps.length - 1]] || MAPS.town;

  var btnStyle = 'display:flex;align-items:center;gap:10px;background:rgba(13,15,12,.85);border:2px solid #444;border-left:4px solid #c8742a;color:#d8d4c4;font-size:13px;padding:10px 18px;text-align:left;min-width:130px;border-radius:0 4px 4px 0;font-family:inherit;cursor:pointer;';

  scr.innerHTML =
    '<div style="position:absolute;inset:0;z-index:0;background:linear-gradient(135deg,rgba(13,15,12,.9),rgba(20,25,15,.95)),radial-gradient(circle at 70% 30%,rgba(200,116,42,.18),transparent 50%),radial-gradient(circle at 20% 80%,rgba(76,175,80,.1),transparent 50%);"></div>' +

    '<div style="position:absolute;left:20px;top:50%;transform:translateY(-50%);display:flex;flex-direction:column;gap:8px;z-index:10;max-height:85%;overflow-y:auto;">' +
      '<button class="lobby-btn" data-go="warehouse" style="' + btnStyle + '"><span style="font-size:18px;">🎒</span>仓库</button>' +
      '<button class="lobby-btn" data-go="market" style="' + btnStyle + '"><span style="font-size:18px;">🛒</span>市场</button>' +
      '<button class="lobby-btn" data-go="loadout" style="' + btnStyle + '"><span style="font-size:18px;">🔫</span>装备</button>' +
      '<button class="lobby-btn" data-go="workbench" style="' + btnStyle + '"><span style="font-size:18px;">🔧</span>改枪台</button>' +
      '<button class="lobby-btn" data-go="quest" style="' + btnStyle + '"><span style="font-size:18px;">📋</span>任务</button>' +
      '<button class="lobby-btn" data-go="quest-log" style="' + btnStyle + '"><span style="font-size:18px;">📜</span>战报</button>' +
    '</div>' +

    '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;z-index:5;pointer-events:none;">' +
      '<div style="font-size:52px;color:#c8742a;letter-spacing:10px;font-weight:bold;text-shadow:0 0 30px rgba(200,116,42,.7);margin-bottom:8px;">' + currentMap.name + '</div>' +
      '<div style="font-size:14px;color:#8a8578;letter-spacing:2px;">' + currentMap.desc + '</div>' +
    '</div>' +

    '<div style="position:absolute;right:20px;bottom:20px;display:flex;flex-direction:column;align-items:flex-end;gap:10px;z-index:10;">' +
      '<div style="display:flex;gap:6px;background:rgba(13,15,12,.75);border:1px solid #444;border-radius:6px;padding:6px;">' +
        '<div style="display:flex;flex-direction:column;align-items:center;min-width:70px;font-size:9px;color:#8a8578;padding:4px 6px;"><span>主武器</span><b style="color:#c8742a;font-size:11px;margin-top:2px;">' + wname + '</b></div>' +
        '<div style="display:flex;flex-direction:column;align-items:center;min-width:70px;font-size:9px;color:#8a8578;padding:4px 6px;"><span>护甲</span><b style="color:#c8742a;font-size:11px;margin-top:2px;">' + aname + '</b></div>' +
        '<div style="display:flex;flex-direction:column;align-items:center;min-width:70px;font-size:9px;color:#8a8578;padding:4px 6px;"><span>头盔</span><b style="color:#c8742a;font-size:11px;margin-top:2px;">' + hname + '</b></div>' +
      '</div>' +
      '<button id="btn-start-raid" style="padding:18px 42px;background:linear-gradient(135deg,#c8742a,#8a4a1a);color:#0d0f0c;border:3px solid #ffd700;border-radius:8px;font-size:20px;font-weight:bold;letter-spacing:4px;font-family:inherit;cursor:pointer;box-shadow:0 0 30px rgba(200,116,42,.6);">▶ 开 始 行 动</button>' +
    '</div>' +

    '<div style="position:absolute;left:20px;bottom:20px;font-size:11px;color:#8a8578;max-width:260px;z-index:5;pointer-events:none;">' +
      '<p style="margin:2px 0;">▸ 携带价值：' + fmt(equipValue()) + ' 币</p>' +
      '<p style="margin:2px 0;">▸ 累计撤离：' + (G.stats.extracts||0) + ' 次</p>' +
      '<p style="margin:2px 0;">▸ 最佳战利：' + fmt(G.stats.bestLoot||0) + ' 币</p>' +
    '</div>';

  var btns = scr.querySelectorAll('.lobby-btn');
  for (var i = 0; i < btns.length; i++) {
    btns[i].onclick = function() { go(this.dataset.go); };
  }
  var sb = scr.querySelector('#btn-start-raid');
  if (sb) sb.onclick = function() { go('map'); };
}

/* ================= 6. 仓库 ================= */
let warehouseFilter = 'all';

function renderWarehouse() {
  renderTopbar();
  var grid = document.getElementById('warehouse-grid');
  if (!grid) return;
  grid.innerHTML = '';
  var list = G.warehouse.filter(function(it) {
    if (warehouseFilter === 'all') return true;
    return inferType(it) === warehouseFilter;
  });
  if (list.length === 0) {
    grid.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">这个分类下没有物品。</p>';
    return;
  }
  list.sort(function(a,b){ return (b.level||0)-(a.level||0); }).forEach(function(item) {
    var card = document.createElement('div');
    var t = inferType(item);
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = '<span class="lvl">' + (item.level?'Lv'+item.level:'') + '</span>' +
      '<span class="emoji">' + (item.icon||getTypeIcon(t)) + '</span>' +
      '<span class="name-mini">' + item.name + '</span>' +
      (item.count > 1 ? '<span class="count-badge">×' + item.count + '</span>' : '');
    card.onclick = function(){ showItemDetail(item); };
    grid.appendChild(card);
  });
}

function showItemDetail(item) {
  var panel = document.getElementById('item-detail');
  if (!panel) return;
  panel.style.display = 'block';
  panel.classList.remove('hidden');
  var t = inferType(item);
  var extra = '';
  if (t === 'weapon') extra = '<p>伤害：' + item.dmg + ' · 射速：' + item.rate + ' · 弹匣：' + item.mag + '</p>';
  if (t === 'melee') extra = '<p>伤害：' + item.dmg + ' · 攻速：' + item.rate + '</p>';
  if (t === 'armor' || t === 'helmet') extra = '<p>减伤：' + Math.round(item.red*100) + '% · 耐久：' + item.dur + '</p>';
  if (t === 'med') extra = '<p>恢复：' + Math.round(item.heal*100) + '%</p>';
  if (t === 'ammo') extra = '<p>数量：' + (item.count||1) + '</p>';
  if (t === 'part') extra = '<p>效果：' + item.eff + '</p>';
  var canEquip = ['weapon','melee','armor','helmet','med','ammo'].indexOf(t) >= 0;
  var sellPrice = Math.floor((item.price||0) * 0.8);
  panel.innerHTML =
    '<h3>' + item.name + '</h3>' +
    '<p>类型：' + typeName(t) + '</p>' +
    '<p>等级：' + (item.level || '—') + '</p>' + extra +
    '<p>估价：' + fmt(item.price||0) + '</p>' +
    '<p>出售可得：' + fmt(sellPrice) + '</p>' +
    (canEquip ? '<button class="alt" id="btn-equip-one">装备</button>' : '') +
    '<button id="btn-sell-one">出售 1 个</button>' +
    (item.count > 1 ? '<button id="btn-sell-all">出售全部 (' + item.count + ')</button>' : '') +
    '<button class="gray" id="btn-close-detail">关闭</button>';
  document.getElementById('btn-close-detail').onclick = function(){ panel.style.display = 'none'; };
  document.getElementById('btn-sell-one').onclick = function(){ quickSell(item, 1); panel.style.display = 'none'; };
  if (document.getElementById('btn-sell-all')) document.getElementById('btn-sell-all').onclick = function(){ quickSell(item, item.count); panel.style.display = 'none'; };
  if (document.getElementById('btn-equip-one')) document.getElementById('btn-equip-one').onclick = function(){
    equipFromWarehouse(item); panel.style.display = 'none'; renderWarehouse();
  };
}

function quickSell(item, count) {
  var c = count || 1;
  if (item.count && item.count > 1) {
    var take = Math.min(c, item.count);
    G.money += Math.floor(item.price * 0.8) * take;
    item.count -= take;
    if (item.count <= 0) removeFromWarehouse(item.uid);
  } else {
    G.money += Math.floor(item.price * 0.8);
    removeFromWarehouse(item.uid);
  }
  save(); renderWarehouse(); renderTopbar();
}

/* ================= 7. 市场 ================= */
function renderMarket(tab) {
  renderTopbar();
  var tabs = document.querySelectorAll('.tabs button');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.toggle('active', tabs[i].dataset.tab === tab);
  var body = document.getElementById('market-body');
  if (!body) return;
  body.innerHTML = '';

  if (tab === 'buy-weapon') {
    WEAPONS.forEach(function(w){ body.appendChild(marketCard({ icon:'🔫', name:w.name, price:w.price, sub:'伤害'+w.dmg+' 射速'+w.rate+' 弹匣'+w.mag, onBuy:function(){ buyEquip('weapon', w); } })); });
  } else if (tab === 'buy-melee') {
    MELEES.forEach(function(m){ body.appendChild(marketCard({ icon:'🔪', name:m.name, price:m.price, sub:'伤害'+m.dmg+' 攻速'+m.rate, onBuy:function(){ buyEquip('melee', m); } })); });
  } else if (tab === 'buy-armor') {
    ARMORS.forEach(function(a){ body.appendChild(marketCard({ icon:'🛡️', name:a.name, price:a.price, sub:a.tier+'级甲 耐久'+a.dur+' 减伤'+Math.round(a.red*100)+'%', onBuy:function(){ buyEquip('armor', a); } })); });
    HELMETS.forEach(function(h){ body.appendChild(marketCard({ icon:'⛑️', name:h.name, price:h.price, sub:h.tier+'级盔 耐久'+h.dur+' 减伤'+Math.round(h.red*100)+'%', onBuy:function(){ buyEquip('helmet', h); } })); });
  } else if (tab === 'buy-med') {
    MEDS.forEach(function(m){ body.appendChild(marketCard({ icon:m.icon, name:m.name, price:m.price, sub:'恢复'+Math.round(m.heal*100)+'%', onBuy:function(){ buyEquip('med', m); } })); });
  } else if (tab === 'buy-ammo') {
    AMMO_TYPES.forEach(function(a){ body.appendChild(marketCard({ icon:a.icon, name:a.name + ' ×30', price:a.price*30, sub:'伤害系数 ×'+a.dmgMul, onBuy:function(){ buyAmmo(a, 30); } })); });
  } else if (tab === 'buy-part') {
    PARTS.forEach(function(p){ body.appendChild(marketCard({ icon:'🔧', name:p.name, price:p.price, sub:p.eff + ' · 槽位:' + p.slot, onBuy:function(){ buyEquip('part', p); } })); });
  } else if (tab === 'sell') {
    var sellable = G.warehouse.filter(function(it){ return inferType(it) === 'loot'; });
    if (sellable.length === 0) { body.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">没有可卖出的变卖物。</p>'; return; }
    sellable.sort(function(a,b){ return (b.level||0)-(a.level||0); }).forEach(function(item){
      body.appendChild(marketCard({
        icon: item.icon || '❔', name: item.name,
        price: Math.floor((item.price||0)*0.8),
        sub: 'Lv' + (item.level||'—') + ' · 原价' + fmt(item.price||0),
        onBuy: function(){ G.money += Math.floor(item.price*0.8); removeFromWarehouse(item.uid); save(); renderMarket('sell'); renderTopbar(); },
        buyLabel: '出售'
      }));
    });
  }
}

function marketCard(o) {
  var c = document.createElement('div');
  c.className = 'market-card';
  c.innerHTML = '<div class="mk-icon">' + o.icon + '</div>' +
    '<div class="mk-name">' + o.name + '</div>' +
    '<div class="mk-sub">' + (o.sub||'') + '</div>' +
    '<div class="mk-price">' + fmt(o.price) + ' 币</div>' +
    '<button class="mk-btn">' + (o.buyLabel||'购买') + '</button>';
  var btn = c.querySelector('.mk-btn');
  btn.onclick = function(e){ e.stopPropagation(); o.onBuy(); };
  return c;
}

function buyEquip(slot, data) {
  if (G.money < data.price) { alert('柯恩币不足'); return; }
  G.money -= data.price;
  var item = clone(data);
  item.type = slot;
  item.uid = uid();
  if (slot === 'med') item.icon = item.icon || '🩹';
  addToWarehouse(item);
  save(); renderTopbar();
  alert(item.name + ' 已放入仓库');
}

function buyAmmo(data, count) {
  var total = data.price * count;
  if (G.money < total) { alert('柯恩币不足'); return; }
  G.money -= total;
  var item = clone(data);
  item.type = 'ammo';
  item.ammoId = data.id;
  item.icon = data.icon;
  item.count = count;
  item.uid = uid();
  item.price = data.price;
  addToWarehouse(item);
  save(); renderTopbar();
  alert('购买 ' + data.name + ' ×' + count);
}

/* ================= 8. 装备 ================= */
function equipFromWarehouse(item) {
  var t = inferType(item);
  if (t === 'loot') { alert('变卖物不能装备'); return; }
  if (t === 'ammo') {
    G.equipment.ammo = (G.equipment.ammo || 0) + (item.count || 0);
    G.equipment.ammoType = item.ammoId || 'AM1';
    removeFromWarehouse(item.uid);
    save(); alert('装填 ' + item.name + ' ×' + item.count); return;
  }
  if (t === 'med') {
    if (G.equipment.meds.length >= 3) { alert('药品已满（3 个）'); return; }
    removeFromWarehouse(item.uid);
    G.equipment.meds.push(item);
    save(); return;
  }
  if (t === 'part') { alert('配件请在改枪台安装'); return; }
  var slotMap = { weapon:'weapon', melee:'melee', armor:'armor', helmet:'helmet' };
  var slot = slotMap[t];
  if (!slot) return;
  if (G.equipment[slot]) {
    var old = G.equipment[slot];
    old.type = slot;
    addToWarehouse(old);
  }
  G.equipment[slot] = item;
  removeFromWarehouse(item.uid);
  save();
}

function unequip(slot) {
  if (slot === 'meds') {
    G.equipment.meds.forEach(function(m){ addToWarehouse(m); });
    G.equipment.meds = [];
    save(); return;
  }
  var item = G.equipment[slot];
  if (!item) return;
  item.type = slot;
  addToWarehouse(item);
  G.equipment[slot] = null;
  save();
}

function renderLoadout() {
  renderTopbar();
  var eq = G.equipment;
  setSlot('slot-weapon', eq.weapon);
  setSlot('slot-melee', eq.melee);
  setSlot('slot-armor', eq.armor);
  setSlot('slot-helmet', eq.helmet);
  var medSlot = document.getElementById('slot-meds');
  if (medSlot) {
    medSlot.querySelector('.slot-value').textContent = eq.meds.length ? eq.meds.map(function(m){return m.name;}).join(' / ') : '空';
    medSlot.classList.toggle('filled', eq.meds.length > 0);
  }
  var lv = document.getElementById('loadout-value'); if (lv) lv.textContent = fmt(equipValue());
  var la = document.getElementById('loadout-ammo'); if (la) la.textContent = eq.ammo || 0;

  var slots = document.querySelectorAll('.slot');
  for (var i = 0; i < slots.length; i++) {
    slots[i].onclick = function() {
      var k = this.dataset.key;
      if (k === 'meds') { if (eq.meds.length) { unequip('meds'); renderLoadout(); } }
      else if (eq[k]) { unequip(k); renderLoadout(); }
    };
  }

  var picker = document.getElementById('loadout-picker');
  if (!picker) return;
  picker.innerHTML = '';
  var candidates = G.warehouse.filter(function(it) {
    var t = inferType(it);
    return ['weapon','melee','armor','helmet','med','ammo'].indexOf(t) >= 0;
  });
  if (candidates.length === 0) {
    picker.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:20px">仓库里没有可装备的物品。</p>';
    return;
  }
  candidates.forEach(function(item) {
    var t = inferType(item);
    var card = document.createElement('div');
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = '<span class="emoji">' + (item.icon||getTypeIcon(t)) + '</span>' +
      '<span class="name-mini">' + item.name + '</span>' +
      (item.count > 1 ? '<span class="count-badge">×' + item.count + '</span>' : '');
    card.onclick = function() { equipFromWarehouse(item); renderLoadout(); };
    picker.appendChild(card);
  });
}

function setSlot(id, item) {
  var el = document.getElementById(id);
  if (!el) return;
  var v = el.querySelector('.slot-value');
  if (item) { v.textContent = item.name; el.classList.add('filled'); }
  else { v.textContent = '空'; el.classList.remove('filled'); }
}

function equipValue() {
  var e = G.equipment;
  var v = 0;
  if (e.weapon) v += e.weapon.price||0;
  if (e.melee)  v += e.melee.price||0;
  if (e.armor)  v += e.armor.price||0;
  if (e.helmet) v += e.helmet.price||0;
  e.meds.forEach(function(m){ v += m.price||0; });
  v += (e.ammo || 0) * 3;
  return v;
}

/* ================= 9. 改枪台 ================= */
var wbCurrentGun = null;

function renderWorkbench() {
  renderTopbar();
  var list = document.getElementById('wb-gun-select');
  if (!list) return;
  list.innerHTML = '';
  var guns = G.warehouse.filter(function(it){ return inferType(it) === 'weapon'; });
  if (guns.length === 0) {
    list.innerHTML = '<p style="color:#666;font-size:12px">仓库中没有枪械。</p>';
    var p = document.getElementById('wb-panel'); if (p) p.innerHTML = '';
    return;
  }
  guns.forEach(function(g) {
    var el = document.createElement('div');
    el.className = 'wb-gun-item' + (wbCurrentGun && wbCurrentGun.uid === g.uid ? ' active' : '');
    el.innerHTML = '<span class="emoji">🔫</span>' + g.name;
    el.onclick = function(){ wbCurrentGun = g; renderWorkbench(); };
    list.appendChild(el);
  });
  if (!wbCurrentGun || !guns.find(function(g){return g.uid === wbCurrentGun.uid;})) {
    wbCurrentGun = guns[0];
  }
  renderWbPanel();
}

function renderWbPanel() {
  var panel = document.getElementById('wb-panel');
  if (!panel) return;
  if (!wbCurrentGun) { panel.innerHTML = ''; return; }
  var parts = G.parts[wbCurrentGun.uid] || {};
  var slotLabels = { scope:'瞄准镜', muzzle:'枪口', mag:'弹匣', stock:'枪托', grip:'握把' };
  var slotsHtml = Object.keys(slotLabels).map(function(slot) {
    var p = parts[slot];
    return '<div class="wb-slot ' + (p?'filled':'') + '"><div class="wb-slot-label">' + slotLabels[slot] + '</div><div class="wb-slot-val">' + (p ? p.name : '空') + '</div></div>';
  }).join('');
  panel.innerHTML =
    '<div class="wb-gun-info">' +
      '<div class="big-icon">🔫</div>' +
      '<div class="wb-stats">' +
        '<div><b>' + wbCurrentGun.name + '</b></div>' +
        '<div>基础伤害：' + wbCurrentGun.dmg + '</div>' +
        '<div>射速：' + wbCurrentGun.rate + ' · 弹匣：' + wbCurrentGun.mag + '</div>' +
      '</div>' +
    '</div>' +
    '<h3 class="sub-title">配件槽位</h3>' +
    '<div class="wb-slots">' + slotsHtml + '</div>' +
    '<h3 class="sub-title">仓库可用配件</h3>' +
    '<div id="wb-part-list" class="grid"></div>';
  var partList = document.getElementById('wb-part-list');
  var partsInWh = G.warehouse.filter(function(it){ return inferType(it) === 'part'; });
  if (partsInWh.length === 0) {
    partList.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:20px">仓库中没有配件。</p>';
  } else {
    partsInWh.forEach(function(p) {
      var card = document.createElement('div');
      card.className = 'item lv3';
      card.innerHTML = '<span class="emoji">🔧</span><span class="name-mini">' + p.name + '</span>';
      card.onclick = function() {
        G.parts[wbCurrentGun.uid] = G.parts[wbCurrentGun.uid] || {};
        if (G.parts[wbCurrentGun.uid][p.slot]) addToWarehouse(G.parts[wbCurrentGun.uid][p.slot]);
        G.parts[wbCurrentGun.uid][p.slot] = p;
        removeFromWarehouse(p.uid);
        save(); renderWorkbench();
      };
      partList.appendChild(card);
    });
  }
}

/* ================= 10. 任务 & 战报 ================= */
function renderQuest() {
  renderTopbar();
  var q = G.quest;
  var el = document.getElementById('quest-list');
  if (!el) return;
  el.innerHTML = '<div class="map-card">' +
    '<div class="map-name" style="font-size:18px">' + q.name + '</div>' +
    '<div class="map-desc">' + q.desc + '</div>' +
    '<p style="font-size:13px;color:#c8742a;margin:10px 0">进度：' + q.progress + '/' + q.target + '</p>' +
    '<p style="font-size:12px;color:#8a8578">奖励：' + fmt(q.reward) + ' 币</p>' +
    (q.done ? '<p style="color:#4caf50;margin-top:10px">✅ 已完成</p>' : '') +
    '</div>';
}

function updateQuest(type) {
  var q = G.quest;
  if (q.done) return;
  if (q.id === 'q1' && type === 'extract') q.progress = Math.min(q.target, q.progress + 1);
  if (q.progress >= q.target) {
    q.done = true;
    G.money += q.reward;
    alert('任务完成：' + q.name + '\n奖励 ' + fmt(q.reward) + ' 币');
    if (G.unlockedMaps.indexOf('mine') < 0) {
      G.unlockedMaps.push('mine');
      alert('🎉 解锁新地图：废弃矿洞');
    }
  }
}

function renderQuestLog() {
  renderTopbar();
  var el = document.getElementById('quest-log-list');
  if (!el) return;
  if (!G.questLog || G.questLog.length === 0) {
    el.innerHTML = '<p style="color:#666;text-align:center;padding:40px">暂无战报。</p>';
    return;
  }
  el.innerHTML = G.questLog.slice(-20).reverse().map(function(r) {
    return '<div class="map-card" style="padding:10px;text-align:left;font-size:12px">' +
      '<div style="color:' + (r.success?'#4caf50':'#c62828') + ';font-weight:bold">' + (r.success?'✅ 撤离成功':'❌ 任务失败') + '</div>' +
      '<div style="color:#8a8578;margin-top:4px">' + r.map + ' · 击杀 ' + r.kills + ' · 战利 ' + fmt(r.loot) + '</div>' +
    '</div>';
  }).join('');
}

/* ================= 11. 地图选择 ================= */
function renderMap() {
  renderTopbar();
  var body = document.getElementById('scr-map');
  if (!body) return;
  var mapList = Object.values(MAPS).map(function(m) {
    var locked = G.unlockedMaps.indexOf(m.id) < 0;
    var btns = locked ? '' :
      '<div class="difficulty-row">' +
      '<button data-map="' + m.id + '" data-diff="normal">普通 ×1.0</button>' +
      '<button data-map="' + m.id + '" data-diff="hard" class="' + (equipValue() < 50000 ? 'locked' : '') + '">困难 ×1.5</button>' +
      '<button data-map="' + m.id + '" data-diff="lockdown" class="' + (equipValue() < 150000 ? 'locked' : '') + '">封锁 ×2.5</button>' +
      '</div>';
    return '<div class="map-card" style="' + (locked?'opacity:.4':'') + '">' +
      '<div class="map-name">' + m.name + '</div>' +
      '<div class="map-desc">' + m.desc + (locked?' · 未解锁':'') + '</div>' + btns +
    '</div>';
  }).join('');
  body.innerHTML =
    '<div class="screen-header"><h2>选择地图</h2><div class="screen-tools">携带价值：<span style="color:#c8742a">' + fmt(equipValue()) + '</span></div></div>' +
    mapList +
    '<button id="btn-map-back" style="margin-top:16px;padding:10px 20px;background:#444;color:#d8d4c4;border:none;border-radius:4px;font-family:inherit">返回大厅</button>';
  var back = document.getElementById('btn-map-back');
  if (back) back.onclick = function(){ go('lobby'); };
  var allBtns = body.querySelectorAll('.difficulty-row button');
  for (var i = 0; i < allBtns.length; i++) {
    allBtns[i].onclick = function() {
      var d = DIFFICULTY[this.dataset.diff];
      if (equipValue() < d.minValue) { alert(d.name + '难度需携带价值 ≥ ' + fmt(d.minValue)); return; }
      startRaid(this.dataset.map, this.dataset.diff);
    };
  }
}

/* ================= 12. 局内 ================= */
let raid = null, raidTimer = null, gameLoopTimer = null, bulletsTimer = null, fireInterval = null;
let playerPos = { x:1500, y:1500 };
let moveDir = { x:0, y:0 };
let aimDir = { x:1, y:0 };
let firing = false;
let extractCountdown = null;

function startRaid(mapId, diffKey) {
  try {
    var diff = DIFFICULTY[diffKey];
    var map = MAPS[mapId];
    if (!G.equipment.weapon && !G.equipment.melee) {
      G.equipment.melee = clone(MELEES[0]);
      G.equipment.melee.uid = uid();
      G.equipment.melee.type = 'melee';
    }
    go('raid');
    setTimeout(function() { initRaidScene(mapId, diffKey, diff, map); }, 80);
  } catch(e) {
    alert('启动失败：' + e.message);
  }
}

function initRaidScene(mapId, diffKey, diff, map) {
  try {
    var field = document.getElementById('raid-field');
    if (!field) { alert('局内界面加载失败'); return; }
    field.innerHTML = '';
    playerPos = { x:1500, y:1500 };
    moveDir = { x:0, y:0 }; aimDir = { x:1, y:0 };
    firing = false;

    var gun = G.equipment.weapon ? clone(G.equipment.weapon) : null;
    if (gun) {
      var parts = G.parts[gun.uid] || {};
      if (parts.muzzle && parts.muzzle.name === '补偿器') gun.dmg = Math.round(gun.dmg * 1.1);
      if (parts.mag && parts.mag.name === '扩容弹匣') gun.mag += 10;
    }

    raid = {
      mapId: mapId, diff: diffKey, luck: diff.luck * map.lootMul,
      hp: 100, maxHp: 100, timeLeft: 300,
      lootValue: 0, backpack: [],
      enemies: [], boxes: [], extract: null,
      armor: G.equipment.armor ? clone(G.equipment.armor) : null,
      helmet: G.equipment.helmet ? clone(G.equipment.helmet) : null,
      log: [], over: false, kills: 0,
      ammo: G.equipment.ammo || 0,
      magSize: gun ? gun.mag : 0,
      magAmmo: gun ? gun.mag : 0,
      weapon: gun,
      melee: G.equipment.melee ? clone(G.equipment.melee) : clone(MELEES[0]),
      bullets: [],
      isKnifeRun: !G.equipment.weapon
    };

    var pEl = document.createElement('div');
    pEl.id = 'player'; pEl.textContent = '🧍';
    pEl.style.left = '1500px'; pEl.style.top = '1500px';
    field.appendChild(pEl);

    for (var i = 0; i < 50; i++) {
      var t = randPick(['house','rock','tree','']);
      if (!t) continue;
      var d = document.createElement('div');
      d.className = 'deco ' + t;
      d.textContent = t==='house'?'🏚️':t==='rock'?'🪨':'🌲';
      d.style.left = rand(100,2900) + 'px';
      d.style.top  = rand(100,2900) + 'px';
      field.appendChild(d);
    }

    var count = Math.round(rand(diff.ec[0], diff.ec[1]) * map.enMul);
    for (var j = 0; j < count; j++) spawnEnemy(randPick(ENEMIES), field);
    if (diff.boss) spawnEnemy(BOSS, field);

    var boxCount = Math.round(16 * map.lootMul);
    for (var k = 0; k < boxCount; k++) spawnBox(randPick(CONTAINERS), field);

    spawnExtract(field);
    bindRaidControls();
    updateCamera();
    renderRaidHUD();
    updateMedSlots();

    var fb = document.getElementById('btn-fire');
    var mb = document.getElementById('btn-melee');
    if (raid.weapon) { fb.style.display = 'flex'; mb.style.display = 'none'; }
    else { fb.style.display = 'none'; mb.style.display = 'flex'; }

    clearInterval(raidTimer);
    raidTimer = setInterval(function() {
      if (!raid || raid.over) return;
      raid.timeLeft--;
      if (raid.timeLeft <= 0) { endRaid(false); return; }
      renderRaidHUD();
      drawMinimap();
    }, 1000);

    clearInterval(gameLoopTimer);
    gameLoopTimer = setInterval(gameLoop, 50);
    clearInterval(bulletsTimer);
    bulletsTimer = setInterval(updateBullets, 30);
  } catch(err) {
    alert('进入地图失败：' + err.message);
  }
}

function spawnEnemy(tpl, field) {
  var el = document.createElement('div');
  el.className = 'enemy' + (tpl.id === 'BOSS' ? ' boss' : '');
  var x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  el.innerHTML = '<div class="hp-mini"><div style="width:100%"></div></div>' + tpl.icon;
  var obj = { el: el, tpl: clone(tpl), hp: tpl.hp, x: x, y: y, alive:true, cd:0, alert:false };
  raid.enemies.push(obj);
  field.appendChild(el);
}
function spawnBox(tpl, field) {
  var el = document.createElement('div');
  el.className = 'loot-box'; el.textContent = tpl.icon;
  var x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  var obj = { el: el, tpl: tpl, x: x, y: y, searched:false };
  el.onclick = function(e) { e.stopPropagation(); searchBox(obj); };
  raid.boxes.push(obj); field.appendChild(el);
}
function spawnExtract(field) {
  var el = document.createElement('div');
  el.className = 'extract-zone'; el.textContent = '撤离';
  var x = rand(300,2700), y = rand(300,2700);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  var obj = { el: el, x: x, y: y };
  el.onclick = function(e) { e.stopPropagation(); tryExtract(); };
  raid.extract = obj; field.appendChild(el);
}

function bindRaidControls() {
  var jz = document.getElementById('joystick-zone'), js = document.getElementById('joystick-stick'), jb = document.getElementById('joystick-base');
  if (!jz) return;
  var jActive = false;
  var jStart = function(e) { e.preventDefault(); jActive = true; };
  var jMove = function(e) {
    if (!jActive) return;
    e.preventDefault();
    var t = e.touches ? e.touches[0] : e;
    var r = jb.getBoundingClientRect();
    var cx = r.left + r.width/2, cy = r.top + r.height/2;
    var dx = t.clientX - cx, dy = t.clientY - cy;
    var len = Math.hypot(dx, dy), max = r.width/2 - 20;
    if (len > max){ dx = dx/len*max; dy = dy/len*max; }
    js.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    if (Math.hypot(dx, dy) > 10) moveDir = { x: dx/max, y: dy/max };
    else moveDir = { x:0, y:0 };
  };
  var jEnd = function() { jActive = false; moveDir = { x:0, y:0 }; js.style.transform = ''; };
  jz.addEventListener('touchstart', jStart, { passive:false });
  jz.addEventListener('touchmove', jMove, { passive:false });
  jz.addEventListener('touchend', jEnd);

  var az = document.getElementById('aim-zone'), as = document.getElementById('aim-stick'), ab = document.getElementById('aim-base');
  if (az) {
    var aActive = false;
    var aStart = function(e) { e.preventDefault(); aActive = true; };
    var aMove = function(e) {
      if (!aActive) return;
      e.preventDefault();
      var t = e.touches ? e.touches[0] : e;
      var r = ab.getBoundingClientRect();
      var cx = r.left + r.width/2, cy = r.top + r.height/2;
      var dx = t.clientX - cx, dy = t.clientY - cy;
      var len = Math.hypot(dx, dy), max = r.width/2 - 18;
      if (len > max){ dx = dx/len*max; dy = dy/len*max; }
      as.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      var nlen = Math.hypot(dx, dy);
      if (nlen > 8){ aimDir = { x: dx/nlen, y: dy/nlen }; updateCrosshair(); }
    };
    var aEnd = function() { aActive = false; as.style.transform = ''; };
    az.addEventListener('touchstart', aStart, { passive:false });
    az.addEventListener('touchmove', aMove, { passive:false });
    az.addEventListener('touchend', aEnd);
  }

  var fb = document.getElementById('btn-fire');
  if (fb) {
    fb.addEventListener('touchstart', function(e){ e.preventDefault(); startFire(); });
    fb.addEventListener('touchend', function(e){ e.preventDefault(); stopFire(); });
  }
  var mb = document.getElementById('btn-melee');
  if (mb) {
    mb.addEventListener('touchstart', function(e){ e.preventDefault(); meleeAttack(); });
  }
  var gb = document.getElementById('btn-grenade');
  if (gb) {
    gb.addEventListener('touchstart', function(e){ e.preventDefault(); throwGrenade(); });
  }
  var rb = document.getElementById('btn-reload'); if (rb) rb.onclick = reload;
  var eb = document.getElementById('btn-extract'); if (eb) eb.onclick = tryExtract;
  var meds = document.querySelectorAll('.med-slot');
  for (var i = 0; i < meds.length; i++) {
    (function(idx){ meds[idx].onclick = function(){ useMed(idx); }; })(i);
  }
  var bb = document.getElementById('btn-back'); if (bb) bb.onclick = function(){ go('lobby'); };
}

function updateCrosshair() {
  var ch = document.getElementById('crosshair');
  if (!ch) return;
  var dist = 80;
  var vw = window.innerWidth / 2, vh = window.innerHeight / 2;
  ch.style.left = (vw + aimDir.x * dist) + 'px';
  ch.style.top  = (vh + aimDir.y * dist) + 'px';
}

function updateCamera() {
  if (!raid) return;
  var cam = document.getElementById('raid-camera');
  if (!cam) return;
  var cx = playerPos.x - window.innerWidth / 2;
  var cy = playerPos.y - window.innerHeight / 2;
  cam.style.transform = 'translate(' + (-cx) + 'px,' + (-cy) + 'px)';
}

function startFire() {
  if (!raid || raid.over || !raid.weapon) return;
  firing = true;
  var fb = document.getElementById('btn-fire'); if (fb) fb.classList.add('firing');
  var interval = Math.max(60, 60000 / raid.weapon.rate);
  doFire();
  fireInterval = setInterval(doFire, interval);
}
function stopFire() {
  firing = false;
  var fb = document.getElementById('btn-fire'); if (fb) fb.classList.remove('firing');
  clearInterval(fireInterval);
}
function doFire() {
  if (!raid || raid.over || !firing) return;
  if (!raid.weapon) return;
  if (raid.magAmmo <= 0) { autoReload(); return; }
  if (raid.ammo <= 0) { raid.log.push('没子弹了！'); renderRaidHUD(); stopFire(); return; }
  raid.magAmmo--;
  raid.ammo--;
  var bx = playerPos.x + aimDir.x * 30;
  var by = playerPos.y + aimDir.y * 30;
  var el = document.createElement('div');
  el.className = 'bullet';
  el.style.left = bx + 'px'; el.style.top = by + 'px';
  var angle = Math.atan2(aimDir.y, aimDir.x) * 180 / Math.PI;
  el.style.transform = 'translate(-50%,-50%) rotate(' + angle + 'deg)';
  document.getElementById('raid-field').appendChild(el);
  var speed = raid.weapon.bulletSpeed;
  raid.bullets.push({ el: el, x: bx, y: by, vx: aimDir.x * speed, vy: aimDir.y * speed, dmg: raid.weapon.dmg, range: raid.weapon.range, dist: 0, owner: 'player' });
  var m = document.createElement('div');
  m.className = 'muzzle';
  m.style.left = bx + 'px'; m.style.top = by + 'px';
  document.getElementById('raid-field').appendChild(m);
  setTimeout(function(){ m.remove(); }, 100);
  renderRaidHUD();
}

function autoReload() {
  if (!raid || !raid.weapon) return;
  if (raid.ammo <= 0) { raid.log.push('无弹药可换'); renderRaidHUD(); return; }
  var need = raid.magSize - raid.magAmmo;
  var take = Math.min(need, raid.ammo);
  raid.magAmmo += take;
  raid.ammo -= take;
  raid.log.push('换弹 +' + take);
  renderRaidHUD();
}
function reload() { autoReload(); }

function meleeAttack() {
  if (!raid || raid.over) return;
  var m = raid.melee || MELEES[0];
  var now = Date.now();
  if (raid._lastMelee && now - raid._lastMelee < 60000/m.rate) return;
  raid._lastMelee = now;
  var checkRange = m.range + 20;
  var targets = raid.enemies.filter(function(e) {
    return e.alive && Math.hypot(e.x - playerPos.x, e.y - playerPos.y) <= checkRange;
  });
  if (targets.length === 0) { raid.log.push('挥空了'); renderRaidHUD(); return; }
  var target = targets[0];
  hitEnemy(target, m.dmg);
  raid.log.push('⚔️ ' + m.name + ' 命中 ' + target.tpl.name);
  renderRaidHUD();
  var slash = document.createElement('div');
  slash.className = 'slash';
  slash.style.left = target.x + 'px'; slash.style.top = target.y + 'px';
  document.getElementById('raid-field').appendChild(slash);
  setTimeout(function(){ slash.remove(); }, 250);
}

function throwGrenade() {
  if (!raid || raid.over) return;
  if (raid._grenadeCd && Date.now() - raid._grenadeCd < 5000) { raid.log.push('手雷冷却中'); renderRaidHUD(); return; }
  raid._grenadeCd = Date.now();
  var tx = playerPos.x + aimDir.x * 220;
  var ty = playerPos.y + aimDir.y * 220;
  var el = document.createElement('div');
  el.className = 'explosion';
  el.style.left = tx + 'px'; el.style.top = ty + 'px';
  document.getElementById('raid-field').appendChild(el);
  setTimeout(function(){ el.remove(); }, 600);
  raid.enemies.forEach(function(e) {
    if (!e.alive) return;
    var d = Math.hypot(e.x - tx, e.y - ty);
    if (d < 130) hitEnemy(e, Math.round(120 * (1 - d/130)));
  });
  raid.log.push('💣 手雷爆炸');
  renderRaidHUD();
}

function updateBullets() {
  if (!raid || raid.over) return;
  for (var i = raid.bullets.length - 1; i >= 0; i--) {
    var b = raid.bullets[i];
    b.x += b.vx; b.y += b.vy;
    b.dist += Math.hypot(b.vx, b.vy);
    b.el.style.left = b.x + 'px'; b.el.style.top = b.y + 'px';
    if (b.dist > b.range) { b.el.remove(); raid.bullets.splice(i, 1); continue; }
    if (b.owner === 'player') {
      for (var j = 0; j < raid.enemies.length; j++) {
        var e = raid.enemies[j];
        if (!e.alive) continue;
        if (Math.hypot(e.x - b.x, e.y - b.y) < 25) {
          hitEnemy(e, b.dmg);
          b.el.remove(); raid.bullets.splice(i, 1); break;
        }
      }
    }
  }
}

function hitEnemy(enemy, dmg) {
  enemy.hp -= dmg;
  enemy.el.classList.add('hurt');
  setTimeout(function(){ enemy.el.classList.remove('hurt'); }, 200);
  var hpBar = enemy.el.querySelector('.hp-mini > div');
  if (hpBar) hpBar.style.width = Math.max(0, enemy.hp/enemy.tpl.hp*100) + '%';
  var bl = document.createElement('div');
  bl.className = 'blood';
  bl.style.left = enemy.x + 'px'; bl.style.top = enemy.y + 'px';
  document.getElementById('raid-field').appendChild(bl);
  setTimeout(function(){ bl.remove(); }, 400);

  if (enemy.hp <= 0) {
    enemy.alive = false;
    enemy.el.classList.add('dead');
    raid.kills++; G.stats.kills++; G.stats.totalKills++;
    raid.log.push('击杀 ' + enemy.tpl.name);
    addKillFeed(enemy.tpl.name);
    var exp = enemy.tpl.exp || 10;
    addExp(exp);
    G.money += Math.round(exp * 20);
    var drop = rollLoot(enemy.tpl.dropTier);
    if (drop) {
      raid.backpack.push(drop);
      raid.lootValue += drop.price;
      raid.log.push('拾取 ' + drop.name + '（' + fmt(drop.price) + '）');
    }
    if (enemy.tpl.id === 'BOSS' && Math.random() < 0.6) {
      var sp = clone(BOSS.specialDrop);
      sp.uid = uid();
      raid.backpack.push(sp);
      raid.lootValue += sp.price;
      raid.log.push('★ 掉落 ' + sp.name);
    }
    renderRaidHUD();
  }
}

function addKillFeed(name) {
  var kf = document.getElementById('kill-feed');
  if (!kf) return;
  var d = document.createElement('div');
  d.textContent = '💀 击杀 ' + name;
  kf.appendChild(d);
  setTimeout(function(){ d.remove(); }, 3000);
}

function addExp(n) {
  G.playerExp = (G.playerExp || 0) + n;
  while (G.playerExp >= expToNext(G.playerLevel)) {
    G.playerExp -= expToNext(G.playerLevel);
    G.playerLevel++;
    setTimeout(function(){ alert('⭐ 升级到 Lv' + G.playerLevel); }, 100);
  }
}

function gameLoop() {
  if (!raid || raid.over) return;
  if (moveDir.x !== 0 || moveDir.y !== 0) {
    var speed = raid.isKnifeRun ? 6.5 : 5;
    playerPos.x = Math.max(40, Math.min(2960, playerPos.x + moveDir.x * speed));
    playerPos.y = Math.max(40, Math.min(2960, playerPos.y + moveDir.y * speed));
    var p = document.getElementById('player');
    if (p) { p.style.left = playerPos.x + 'px'; p.style.top = playerPos.y + 'px'; }
    updateCamera();
  }
  var now = Date.now();
  raid.enemies.forEach(function(e) {
    if (!e.alive) return;
    var dx = playerPos.x - e.x, dy = playerPos.y - e.y;
    var dist = Math.hypot(dx, dy);
    if (dist < 600) {
      if (!e.alert) { e.alert = true; e.el.classList.add('alert'); }
      if (dist > 80) {
        var sp = 1.3;
        e.x += (dx/dist) * sp; e.y += (dy/dist) * sp;
        e.el.style.left = e.x + 'px'; e.el.style.top = e.y + 'px';
      }
      if (dist < 480 && now - e.cd > 1500) {
        e.cd = now;
        enemyShoot(e);
      }
    } else {
      e.alert = false; e.el.classList.remove('alert');
    }
  });
}

function enemyShoot(e) {
  var dmg = e.tpl.dmg;
  var red = 0;
  if (raid.armor && raid.armor.dur > 0) { red += raid.armor.red; raid.armor.dur -= rand(1,3); if (raid.armor.dur < 0) raid.armor.dur = 0; }
  if (raid.helmet && raid.helmet.dur > 0) { red += raid.helmet.red * 0.5; raid.helmet.dur -= rand(1,2); if (raid.helmet.dur < 0) raid.helmet.dur = 0; }
  dmg = dmg * (1 - Math.min(red, 0.85));
  raid.hp -= dmg;
  var flash = document.getElementById('damage-flash');
  if (flash) { flash.classList.add('on'); setTimeout(function(){ flash.classList.remove('on'); }, 80); }
  if (raid.hp <= 0) { raid.hp = 0; endRaid(false); return; }
  if (raid.hp < raid.maxHp * 0.3 && G.equipment.meds.length > 0) useMed(0);
  renderRaidHUD();
}

function searchBox(obj) {
  if (!obj || obj.searched || !raid || raid.over) return;
  var dist = Math.hypot(obj.x - playerPos.x, obj.y - playerPos.y);
  if (dist > 90) { raid.log.push('太远了，走近点'); renderRaidHUD(); return; }
  obj.searched = true;
  obj.el.classList.add('searched');
  var drop = rollLoot(obj.tpl.tier);
  if (drop) {
    raid.backpack.push(drop);
    raid.lootValue += drop.price;
    raid.log.push('获得 ' + drop.name + '（' + fmt(drop.price) + '）');
  } else raid.log.push('空空如也');
  renderRaidHUD();
}

function useMed(i) {
  if (!raid || raid.over) return;
  var item = G.equipment.meds[i];
  if (!item) return;
  var heal = item.heal * raid.maxHp;
  raid.hp = Math.min(raid.maxHp, raid.hp + heal);
  G.equipment.meds.splice(i, 1);
  save(); updateMedSlots(); renderRaidHUD();
  raid.log.push('使用 ' + item.name + '，恢复 ' + Math.round(heal));
  renderRaidHUD();
}

function updateMedSlots() {
  var slots = document.querySelectorAll('.med-slot');
  for (var i = 0; i < slots.length; i++) {
    var med = G.equipment.meds[i];
    slots[i].textContent = med ? med.icon : '➕';
    slots[i].classList.toggle('filled', !!med);
  }
}

function tryExtract() {
  if (!raid || raid.over) return;
  var d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
  if (d > 100) { raid.log.push('离撤离点太远'); renderRaidHUD(); return; }
  startExtractCountdown();
}

function startExtractCountdown() {
  if (extractCountdown) return;
  var count = 5;
  var ec = document.getElementById('extract-count'); if (ec) ec.textContent = count;
  var ep = document.getElementById('extract-progress'); if (ep) ep.classList.remove('hidden');
  extractCountdown = setInterval(function() {
    if (!raid || raid.over) { clearInterval(extractCountdown); extractCountdown = null; if (ep) ep.classList.add('hidden'); return; }
    var d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
    if (d > 130) {
      clearInterval(extractCountdown); extractCountdown = null;
      if (ep) ep.classList.add('hidden');
      raid.log.push('离开撤离点，撤离中断'); renderRaidHUD(); return;
    }
    count--;
    if (ec) ec.textContent = count;
    if (count <= 0) {
      clearInterval(extractCountdown); extractCountdown = null;
      if (ep) ep.classList.add('hidden');
      endRaid(true);
    }
  }, 1000);
}

function endRaid(success) {
  if (raid.over) return;
  raid.over = true;
  clearInterval(raidTimer); clearInterval(gameLoopTimer); clearInterval(bulletsTimer); clearInterval(fireInterval);
  if (extractCountdown) { clearInterval(extractCountdown); extractCountdown = null; }
  G.stats.raids++;
  var record = { success: success, map: MAPS[raid.mapId].name, kills: raid.kills, loot: raid.lootValue };
  if (success) {
    G.stats.extracts++;
    raid.backpack.forEach(function(it){ addToWarehouse(it); });
    if (raid.lootValue > G.stats.bestLoot) G.stats.bestLoot = raid.lootValue;
    updateQuest('extract');
  } else {
    G.stats.deaths++;
    G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' };
  }
  G.questLog.push(record);
  if (G.questLog.length > 50) G.questLog.shift();
  save();
  showResult(success);
}

function showResult(success) {
  var overlay = document.getElementById('result-overlay');
  if (!overlay) { go('lobby'); return; }
  overlay.classList.remove('hidden');
  document.getElementById('result-title').textContent = success ? '撤离成功' : '任务失败 · 装备丢失';
  var body = document.getElementById('result-body');
  if (success) {
    body.innerHTML = '<p>带回 ' + raid.backpack.length + ' 件物资</p><p>总价值：' + fmt(raid.lootValue) + ' 柯恩币</p><p>击杀：' + raid.kills + '</p>';
  } else {
    body.innerHTML = '<p>你在 ' + MAPS[raid.mapId].name + ' 倒下了</p><p>装备全部丢失，仓库物资安全</p><p>本次击杀：' + raid.kills + '</p>';
  }
  renderTopbar();
}

function renderRaidHUD() {
  if (!raid) return;
  var rl = document.getElementById('raid-loot'); if (rl) rl.textContent = fmt(raid.lootValue);
  var rk = document.getElementById('raid-kills'); if (rk) rk.textContent = raid.kills;
  var m = String(Math.floor(raid.timeLeft/60)).padStart(2,'0');
  var s = String(raid.timeLeft % 60).padStart(2,'0');
  if (raid.weapon) {
    document.getElementById('raid-timer').textContent = m + ':' + s;
    var ap = document.getElementById('ammo-pill'); if (ap) ap.style.display = 'block';
    document.getElementById('raid-ammo').textContent = raid.magAmmo + '/' + raid.magSize + ' (剩' + raid.ammo + ')';
    if (ap) ap.classList.toggle('low', raid.magAmmo <= raid.magSize * 0.3);
  } else {
    document.getElementById('raid-timer').textContent = m + ':' + s + ' 🔪';
    var ap2 = document.getElementById('ammo-pill'); if (ap2) ap2.style.display = 'none';
  }
  var hpPct = raid.hp / raid.maxHp * 100;
  var fill = document.getElementById('hp-fill');
  if (fill) { fill.style.width = hpPct + '%'; fill.classList.toggle('low', hpPct < 30); }
  document.getElementById('hp-text').textContent = Math.round(raid.hp) + ' / ' + raid.maxHp;
  var log = document.getElementById('raid-log');
  if (log) log.innerHTML = raid.log.slice(-5).map(function(l){ return '· ' + l; }).join('<br>');
  var si = document.getElementById('status-icons');
  if (si) {
    var html = '';
    if (raid.armor && raid.armor.dur > 0) html += '<div class="status-icon">🛡️ ' + raid.armor.dur + '</div>';
    if (raid.helmet && raid.helmet.dur > 0) html += '<div class="status-icon">⛑️ ' + raid.helmet.dur + '</div>';
    if (raid.isKnifeRun) html += '<div class="status-icon">🔪 跑刀</div>';
    si.innerHTML = html;
  }
}

function drawMinimap() {
  var c = document.getElementById('minimap'); if (!c || !raid) return;
  var ctx = c.getContext('2d');
  var W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(13,15,12,0.85)';
  ctx.fillRect(0, 0, W, H);
  var scale = W / 3000;
  raid.enemies.forEach(function(e) {
    if (!e.alive) return;
    ctx.fillStyle = e.tpl.id === 'BOSS' ? '#ffd700' : '#ff3b3b';
    ctx.beginPath(); ctx.arc(e.x*scale, e.y*scale, 3, 0, Math.PI*2); ctx.fill();
  });
  ctx.fillStyle = '#c8742a';
  raid.boxes.forEach(function(b) {
    if (b.searched) return;
    ctx.fillRect(b.x*scale-2, b.y*scale-2, 3, 3);
  });
  if (raid.extract) {
    ctx.fillStyle = '#4caf50';
    ctx.beginPath(); ctx.arc(raid.extract.x*scale, raid.extract.y*scale, 5, 0, Math.PI*2); ctx.fill();
  }
  ctx.fillStyle = '#ffd700';
  ctx.beginPath(); ctx.arc(playerPos.x*scale, playerPos.y*scale, 4, 0, Math.PI*2); ctx.fill();
}

/* ================= 13. 存档 ================= */
function exportSave() {
  try {
    var data = JSON.stringify(G);
    var str = btoa(unescape(encodeURIComponent(data)));
    prompt('复制下面这串存档码：', str);
  } catch(e) { alert('导出失败：' + e.message); }
}
function importSave() {
  var str = prompt('粘贴存档码：');
  if (!str) return;
  try {
    var data = decodeURIComponent(escape(atob(str)));
    var obj = JSON.parse(data);
    if (obj && obj.money !== undefined) {
      G = obj; save(); alert('导入成功');
      renderTopbar(); renderWarehouse();
    } else alert('存档格式错误');
  } catch(e) { alert('导入失败：' + e.message); }
}

/* ================= 14. 启动 ================= */
function bindEvents() {
  var tabs = document.querySelectorAll('.tabs button');
  for (var i = 0; i < tabs.length; i++) {
    (function(btn){ btn.onclick = function(){ renderMarket(btn.dataset.tab); }; })(tabs[i]);
  }
  var fbtns = document.querySelectorAll('.filter-tabs button');
  for (var j = 0; j < fbtns.length; j++) {
    (function(btn){
      btn.onclick = function() {
        warehouseFilter = btn.dataset.filter;
        var all = document.querySelectorAll('.filter-tabs button');
        for (var k = 0; k < all.length; k++) all[k].classList.toggle('active', all[k] === btn);
        renderWarehouse();
      };
    })(fbtns[j]);
  }
  var be = document.getElementById('btn-export-save'); if (be) be.onclick = exportSave;
  var bi = document.getElementById('btn-import-save'); if (bi) bi.onclick = importSave;
  window.addEventListener('resize', checkOrientation);
  window.addEventListener('orientationchange', checkOrientation);
}

function checkOrientation() {
  var tip = document.getElementById('rotate-tip');
  if (!tip) return;
  tip.style.display = (window.innerHeight > window.innerWidth) ? 'flex' : 'none';
}

function boot() {
  try {
    load();
    bindEvents();
    checkOrientation();
    renderTopbar();
    go('lobby');
  } catch(e) {
    console.error('boot error:', e);
    document.body.innerHTML = '<div style="padding:20px;color:#fff;font-family:monospace;"><h2 style="color:#ff3b3b;">启动失败</h2><p>' + e.message + '</p><pre style="font-size:11px;color:#888;">' + (e.stack||'') + '</pre></div>';
  }
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();