/* =========================================================
   棍母小镇 · game.js · 完整修复版
   ========================================================= */

/* ================= 1. 数据层 ================= */

const LOOT_NAMES = {
  1: ['锈铁钉','破布条','空塑料瓶','旧电池','铜线圈','断扳手','黄胶带','油气打火机',
      '短铅笔','碎橡皮','铁螺丝','小弹簧','麻绳头','汽水瓶盖','湿纸板','塑料袋',
      '瘪铝罐','脏纱布','木楔子','橡皮筋','订书钉','弯回形针','半截牙签'],
  2: ['医用绷带','压缩能量棒','打火机油','黄铜管','废电缆','铁皮工具箱','防水帆布',
      '旧手电','五号电池组','军用水壶','硬饼干','止血带','铁口哨','指南针',
      '裂镜放大镜','温度计','听诊器','手术刀片','注射器','氧气罐','滤毒罐芯'],
  3: ['军用口粮','红外滤镜','加密U盘','SIM卡组','夜视仪镜片','消音器零件','四倍瞄准镜',
      '防弹插板','战术手套','军靴','头盔衬垫','水袋','GPS模块','短波电台','双筒望远镜',
      '红色信号弹','灰烟幕弹','闪光雷','破片手雷','燃烧瓶','C4塑胶炸药'],
  4: ['金壳手表','金手镯','镀金手机','碎钻戒指','银质胸针','老式摄影机','矿卡显卡',
      '钯金线材','除颤器','宫廷银器','激光指示模块','液压扳手','掌上游戏机','黑胶唱片机',
      '古董打字机','维修手册','金豹小雕像','青花茶壶','宝石项链','胰岛素泵',
      '精密水平仪','鎏金酒杯','纯金小块'],
  5: ['热成像模块','目标定位模块','碎纹花瓶','金狮雕像','盛宴雕塑','金魔方',
      '军用加密硬盘','卫星电话','夜视仪','防弹公文包','钛合金板','碳纤维布',
      '军用无人机','高级工具组','稀有化学品'],
  6: ['理想国芯片','军用主控芯片','核废料样本','古代金币','陨石碎片','生物样本容器','量子处理器'],
  7: ['机密文件']
};
const LEVEL_PRICE = {1:[500,3000],2:[3000,8000],3:[8000,20000],4:[20000,60000],
  5:[60000,150000],6:[150000,400000],7:[800000,900000]};
const LEVEL_STYLE = {1:{icon:'🔩',cls:'lv1'},2:{icon:'🧰',cls:'lv2'},3:{icon:'📦',cls:'lv3'},
  4:{icon:'💎',cls:'lv4'},5:{icon:'🏆',cls:'lv5'},6:{icon:'👑',cls:'lv6'},7:{icon:'🗂️',cls:'lv7'}};

const ALL_LOOT = [];
(function(){
  let uid = 1;
  for (let lv = 1; lv <= 7; lv++) {
    const [lo, hi] = LEVEL_PRICE[lv];
    LOOT_NAMES[lv].forEach((name, i) => {
      const ratio = LOOT_NAMES[lv].length === 1 ? 1 : i / (LOOT_NAMES[lv].length - 1);
      const base = lo + (hi - lo) * ratio;
      const jitter = base * (Math.random() * 0.3 - 0.15);
      const price = Math.round((base + jitter) / 100) * 100;
      ALL_LOOT.push({ id:'L'+uid++, name, level:lv, price,
        icon: LEVEL_STYLE[lv].icon, cls: LEVEL_STYLE[lv].cls, type:'loot' });
    });
  }
})();

const WEAPONS = [
  { id:'W01', name:'锈蜂 PDW-9',  price:1000,   dmg:15, rate:900, mag:30, range:600,  bulletSpeed:14 },
  { id:'W02', name:'矿工 M870',   price:3000,   dmg:45, rate:60,  mag:6,  range:280,  bulletSpeed:9 },
  { id:'W03', name:'夜莺 MP5',    price:8000,   dmg:20, rate:800, mag:30, range:650,  bulletSpeed:14 },
  { id:'W04', name:'红壤 AK74N',  price:15000,  dmg:32, rate:650, mag:30, range:900,  bulletSpeed:16 },
  { id:'W05', name:'铁砧 SKS',    price:22000,  dmg:38, rate:300, mag:10, range:1000, bulletSpeed:17 },
  { id:'W06', name:'峡谷 BM59',   price:26000,  dmg:42, rate:350, mag:20, range:1000, bulletSpeed:17 },
  { id:'W07', name:'远钟 M14',    price:35000,  dmg:55, rate:250, mag:20, range:1100, bulletSpeed:18 },
  { id:'W08', name:'白桦 Mosin',  price:39000,  dmg:85, rate:40,  mag:5,  range:1300, bulletSpeed:22 },
  { id:'W09', name:'沙狐 MDR',    price:45000,  dmg:40, rate:700, mag:30, range:900,  bulletSpeed:15 },
  { id:'W10', name:'长枪管 M4A1', price:75000,  dmg:35, rate:800, mag:30, range:950,  bulletSpeed:16 },
  { id:'W11', name:'赤铁 AK-102', price:93000,  dmg:38, rate:650, mag:30, range:950,  bulletSpeed:16 },
  { id:'W12', name:'鹰眼 AUG',    price:120000, dmg:40, rate:750, mag:30, range:1000, bulletSpeed:16 },
  { id:'W13', name:'大西洋 FAL',  price:180000, dmg:52, rate:630, mag:20, range:1050, bulletSpeed:17 },
  { id:'W14', name:'幽灵 H416',   price:280000, dmg:45, rate:850, mag:30, range:1000, bulletSpeed:17 },
  { id:'W15', name:'审判 MK14',   price:450000, dmg:70, rate:400, mag:20, range:1200, bulletSpeed:19 }
];

const MELEES = [
  { id:'K01', name:'生锈小刀',   price:0,     dmg:20,  rate:180, range:50 },
  { id:'K02', name:'矿工匕首',   price:500,   dmg:35,  rate:200, range:55 },
  { id:'K03', name:'军用战术刀', price:2500,  dmg:55,  rate:220, range:60 },
  { id:'K04', name:'猎刀',       price:8000,  dmg:80,  rate:200, range:65 },
  { id:'K05', name:'消防斧',     price:20000, dmg:120, rate:150, range:70 },
  { id:'K06', name:'碳纤维砍刀', price:60000, dmg:180, rate:180, range:75 },
  { id:'K07', name:'武士刀',     price:200000,dmg:300, rate:200, range:85 }
];

const ARMORS = [
  { id:'A1', name:'特勤防弹衣',   price:2000,   dur:35, red:0.20, tier:1 },
  { id:'A2', name:'H-Tac 特勤甲', price:4500,   dur:45, red:0.30, tier:2 },
  { id:'A3', name:'KN 制式甲',    price:30000,  dur:55, red:0.45, tier:3 },
  { id:'A4', name:'SEK 壁垒甲',   price:100000, dur:65, red:0.55, tier:4 },
  { id:'A5', name:'926 复合甲',   price:200000, dur:75, red:0.65, tier:5 },
  { id:'A6', name:'IMTV 武士甲',  price:450000, dur:90, red:0.75, tier:6 }
];
const HELMETS = [
  { id:'H1', name:'工地安全帽',   price:800,    dur:20, red:0.15, tier:1 },
  { id:'H2', name:'战术软帽',     price:2500,   dur:28, red:0.25, tier:2 },
  { id:'H3', name:'KN 防弹盔',    price:18000,  dur:38, red:0.40, tier:3 },
  { id:'H4', name:'SEK 重型盔',   price:60000,  dur:50, red:0.52, tier:4 },
  { id:'H5', name:'926 复合盔',   price:130000, dur:62, red:0.62, tier:5 },
  { id:'H6', name:'IMTV 武士盔',  price:280000, dur:78, red:0.72, tier:6 }
];
const MEDS = [
  { id:'M1', name:'简易急救包', price:800,  heal:0.33, icon:'🩹' },
  { id:'M2', name:'军用急救包', price:2500, heal:0.50, icon:'💉' },
  { id:'M3', name:'白色医疗箱', price:8000, heal:1.00, icon:'🧰' }
];
const AMMO_TYPES = [
  { id:'AM1', name:'手枪弹',  price:2,  dmgMul:1.0, icon:'🔸' },
  { id:'AM2', name:'步枪弹',  price:4,  dmgMul:1.1, icon:'🔶' },
  { id:'AM3', name:'穿甲弹',  price:12, dmgMul:1.4, icon:'💥' }
];

const ENEMIES = [
  { id:'E01', name:'流浪拾荒者', hp:60,  dmg:8,  dropTier:'low',  icon:'🧟', exp:5 },
  { id:'E02', name:'武装匪徒',   hp:90,  dmg:15, dropTier:'low',  icon:'🥷', exp:10 },
  { id:'E03', name:'巡逻哨兵',   hp:80,  dmg:12, dropTier:'low',  icon:'💂', exp:8 },
  { id:'E04', name:'精英斥候',   hp:110, dmg:20, dropTier:'mid',  icon:'🕵️', exp:20 },
  { id:'E05', name:'重装守卫',   hp:150, dmg:18, dropTier:'mid',  icon:'🛡️', exp:25 },
  { id:'E06', name:'屋顶狙击手', hp:70,  dmg:35, dropTier:'mid',  icon:'🎯', exp:22 },
  { id:'E07', name:'废墟突击兵', hp:100, dmg:22, dropTier:'mid',  icon:'🔫', exp:18 },
  { id:'E08', name:'爆破专家',   hp:95,  dmg:28, dropTier:'high', icon:'💣', exp:35 },
  { id:'E09', name:'随队医疗兵', hp:85,  dmg:10, dropTier:'high', icon:'⛑️', exp:30 },
  { id:'E10', name:'精英指挥官', hp:130, dmg:25, dropTier:'high', icon:'🎖️', exp:45 }
];
const BOSS = {
  id:'BOSS', name:'“棍母”镇长', hp:500, dmg:40, dropTier:'boss', icon:'👺', exp:200,
  specialDrop: { id:'L-SP1', name:'镇长的金印章', level:6, price:520000, icon:'🔱', cls:'lv6', type:'loot' }
};

const CONTAINERS = [
  { id:'C01', name:'军用保险箱', tier:'low',  icon:'🗄️' },
  { id:'C02', name:'加密集装箱', tier:'low',  icon:'📦' },
  { id:'C03', name:'医疗空投',   tier:'low',  icon:'🚁' },
  { id:'C04', name:'武器箱',     tier:'low',  icon:'🔫' },
  { id:'C05', name:'电子保险箱', tier:'low',  icon:'💻' },
  { id:'C06', name:'军用背包',   tier:'mid',  icon:'🎒' },
  { id:'C07', name:'弹药箱',     tier:'mid',  icon:'📦' },
  { id:'C08', name:'工具箱',     tier:'mid',  icon:'🧰' },
  { id:'C09', name:'旅行箱',     tier:'mid',  icon:'🧳' },
  { id:'C10', name:'抽屉',       tier:'mid',  icon:'🗃️' },
  { id:'C11', name:'普通补给箱', tier:'high', icon:'📮' },
  { id:'C12', name:'散落物资点', tier:'high', icon:'🧷' },
  { id:'C13', name:'衣柜',       tier:'high', icon:'🚪' },
  { id:'C14', name:'废弃车辆',   tier:'high', icon:'🚗' }
];
const DROP_RATE = {
  low:  { 1:0.05, 2:0.10, 3:0.20, 4:0.35, 5:0.20, 6:0.08, 7:0.02 },
  mid:  { 1:0.15, 2:0.25, 3:0.30, 4:0.20, 5:0.08, 6:0.02, 7:0.00 },
  high: { 1:0.40, 2:0.35, 3:0.20, 4:0.05, 5:0.00, 6:0.00, 7:0.00 },
  boss: { 1:0.00, 2:0.05, 3:0.10, 4:0.25, 5:0.35, 6:0.20, 7:0.05 }
};
const MAPS = {
  town:     { id:'town',     name:'棍母小镇', desc:'废弃矿区旁的居民点',     lootMul:1.0, enMul:1.0 },
  mine:     { id:'mine',     name:'废弃矿洞', desc:'塌方频发，矿脉里全是宝', lootMul:1.4, enMul:1.3 },
  facility: { id:'facility', name:'旧军事设施', desc:'危险最高，机密出没',   lootMul:1.9, enMul:1.6 }
};
const DIFFICULTY = {
  normal:   { name:'普通', ec:[5,8],   luck:1.0, boss:false, minValue:0 },
  hard:     { name:'困难', ec:[8,12],  luck:1.5, boss:false, minValue:50000 },
  lockdown: { name:'封锁', ec:[12,15], luck:2.5, boss:true,  minValue:150000 }
};

/* ================= 2. 状态层 ================= */

const SAVE_KEY = 'gunmu_town_save_v2';
let G = null;

function newGame() {
  return {
    money: 500000,
    warehouse: [],
    equipment: { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' },
    stats: { raids:0, extracts:0, deaths:0, kills:0, bestLoot:0, totalKills:0 },
    quest: { id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离',
             target:1, progress:0, reward:20000, done:false },
    unlockedMaps: ['town'],
    lastDaily: '',
    dailyStreak: 0
  };
}

function save() {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(G)); } catch(e){}
}
function load() {
  const raw = localStorage.getItem(SAVE_KEY);
  if (raw) { try { G = JSON.parse(raw); } catch(e){ G = newGame(); } }
  else G = newGame();
  // 兼容补全
  if (!G.equipment) G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' };
  if (G.equipment.melee === undefined) G.equipment.melee = null;
  if (!G.equipment.meds) G.equipment.meds = [];
  if (G.equipment.ammo === undefined) G.equipment.ammo = 0;
  if (G.equipment.ammoType === undefined) G.equipment.ammoType = 'AM1';
  if (!G.stats) G.stats = { raids:0, extracts:0, deaths:0, kills:0, bestLoot:0, totalKills:0 };
  if (G.stats.bestLoot === undefined) G.stats.bestLoot = 0;
  if (!G.quest) G.quest = { id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离', target:1, progress:0, reward:20000, done:false };
  if (!G.unlockedMaps) G.unlockedMaps = ['town'];
  if (!G.lastDaily) G.lastDaily = '';
  if (!G.dailyStreak) G.dailyStreak = 0;
}

/* ================= 3. 工具函数 ================= */

const $  = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const fmt = n => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const rand = (a,b) => Math.floor(Math.random()*(b-a+1))+a;
const randPick = a => a[Math.floor(Math.random()*a.length)];
const clone = o => JSON.parse(JSON.stringify(o));
const uid = () => 'U' + Date.now() + Math.random().toString(36).slice(2,6);

function rollLevel(tier) {
  const t = DROP_RATE[tier]; const r = Math.random(); let acc = 0;
  for (let lv = 1; lv <= 7; lv++) { acc += t[lv]; if (r < acc) return lv; }
  return 1;
}
function rollLoot(tier) {
  const lv = rollLevel(tier);
  const pool = ALL_LOOT.filter(x => x.level === lv);
  return clone(randPick(pool));
}

function addToWarehouse(item) {
  if (!item) return;
  if (!item.uid) item.uid = uid();
  if (!item.type) item.type = inferType(item);
  // 弹药可叠加
  if (item.type === 'ammo') {
    const existing = G.warehouse.find(x => x.type === 'ammo' && x.ammoId === item.ammoId);
    if (existing) { existing.count = (existing.count||1) + (item.count||1); return; }
  }
  G.warehouse.push(item);
}
function removeFromWarehouse(uidStr) {
  const i = G.warehouse.findIndex(x => x.uid === uidStr);
  if (i >= 0) G.warehouse.splice(i, 1);
}
function inferType(item) {
  if (!item) return 'loot';
  if (item.type) return item.type;
  if (WEAPONS.find(w => w.id === item.id)) return 'weapon';
  if (MELEES.find(m => m.id === item.id)) return 'melee';
  if (ARMORS.find(a => a.id === item.id)) return 'armor';
  if (HELMETS.find(h => h.id === item.id)) return 'helmet';
  if (MEDS.find(m => m.id === item.id)) return 'med';
  if (AMMO_TYPES.find(a => a.id === item.id)) return 'ammo';
  return 'loot';
}

/* ================= 4. 界面路由 ================= */

function go(name) {
  $$('.screen').forEach(s => s.classList.add('hidden'));
  const el = $('#scr-' + name);
  if (el) el.classList.remove('hidden');
  if (name === 'warehouse') renderWarehouse();
  if (name === 'market')    renderMarket('buy-weapon');
  if (name === 'loadout')   renderLoadout();
  if (name === 'map')       renderMap();
  if (name === 'quest')     renderQuest();
}

function renderTopbar() {
  $('#money').textContent = fmt(G.money);
  $('#wh-count').textContent = G.warehouse.length;
}

/* ================= 5. 仓库 ================= */

let warehouseFilter = 'all';

function renderWarehouse() {
  renderTopbar();
  const grid = $('#warehouse-grid');
  grid.innerHTML = '';
  const list = G.warehouse.filter(it => {
    if (warehouseFilter === 'all') return true;
    return inferType(it) === warehouseFilter;
  });
  if (list.length === 0) {
    grid.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">这个分类下没有物品。</p>';
    return;
  }
  [...list].sort((a,b) => (b.level||0)-(a.level||0)).forEach(item => {
    const card = document.createElement('div');
    const t = inferType(item);
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = `
      <span class="lvl">${item.level?'Lv'+item.level:''}</span>
      <span class="emoji">${item.icon||getTypeIcon(t)}</span>
      <span class="name-mini">${item.name}</span>
      ${item.count > 1 ? `<span class="count-badge">×${item.count}</span>` : ''}
    `;
    card.onclick = () => showItemDetail(item);
    card.oncontextmenu = e => { e.preventDefault(); quickSell(item); };
    grid.appendChild(card);
  });
}
function getTypeIcon(t) {
  if (t === 'weapon') return '🔫';
  if (t === 'melee') return '🔪';
  if (t === 'armor') return '🛡️';
  if (t === 'helmet') return '⛑️';
  if (t === 'med') return '🩹';
  if (t === 'ammo') return '🔸';
  return '❔';
}

function showItemDetail(item) {
  const panel = $('#item-detail');
  panel.classList.remove('hidden');
  const t = inferType(item);
  let extra = '';
  if (t === 'weapon') extra = `<p>伤害：${item.dmg} · 射速：${item.rate} · 弹匣：${item.mag}</p>`;
  if (t === 'melee') extra = `<p>伤害：${item.dmg} · 攻速：${item.rate}</p>`;
  if (t === 'armor' || t === 'helmet') extra = `<p>减伤：${Math.round(item.red*100)}% · 耐久：${item.dur}</p>`;
  if (t === 'med') extra = `<p>恢复：${Math.round(item.heal*100)}%</p>`;
  if (t === 'ammo') extra = `<p>数量：${item.count||1}</p>`;

  const canEquip = ['weapon','melee','armor','helmet','med'].includes(t);
  const sellPrice = Math.floor((item.price||0) * 0.8);

  panel.innerHTML = `
    <h3>${item.name}</h3>
    <p>类型：${typeName(t)}</p>
    <p>等级：${item.level || '—'}</p>
    ${extra}
    <p>估价：${fmt(item.price||0)}</p>
    <p>出售可得：${fmt(sellPrice)}</p>
    ${canEquip ? `<button class="alt" id="btn-equip-one">装备</button>` : ''}
    <button id="btn-sell-one">出售 1 个</button>
    ${item.count > 1 ? `<button id="btn-sell-all">出售全部 (${item.count})</button>` : ''}
    <button class="gray" id="btn-close-detail">关闭</button>
  `;
  $('#btn-close-detail').onclick = () => panel.classList.add('hidden');
  $('#btn-sell-one').onclick = () => quickSell(item, 1);
  if ($('#btn-sell-all')) $('#btn-sell-all').onclick = () => quickSell(item, item.count);
  if ($('#btn-equip-one')) $('#btn-equip-one').onclick = () => {
    equipFromWarehouse(item);
    panel.classList.add('hidden');
    renderWarehouse();
  };
}

function typeName(t) {
  return { loot:'变卖物', weapon:'枪械', melee:'刀具', armor:'护甲',
    helmet:'头盔', med:'药品', ammo:'弹药' }[t] || '未知';
}

function quickSell(item, count) {
  const c = count || 1;
  if (item.count && item.count > 1) {
    const take = Math.min(c, item.count);
    G.money += Math.floor(item.price * 0.8) * take;
    item.count -= take;
    if (item.count <= 0) removeFromWarehouse(item.uid);
  } else {
    G.money += Math.floor(item.price * 0.8);
    removeFromWarehouse(item.uid);
  }
  save(); renderWarehouse();
}

/* ================= 6. 市场 ================= */

function renderMarket(tab) {
  renderTopbar();
  $$('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const body = $('#market-body');
  body.innerHTML = '';

  if (tab === 'buy-weapon') {
    WEAPONS.forEach(w => body.appendChild(marketCard({
      icon:'🔫', name:w.name, price:w.price, type:'weapon',
      sub:`伤害${w.dmg} 射速${w.rate} 弹匣${w.mag}`,
      data:w, onBuy:() => buyEquip('weapon', w)
    })));
  } else if (tab === 'buy-melee') {
    MELEES.forEach(m => body.appendChild(marketCard({
      icon:'🔪', name:m.name, price:m.price, type:'melee',
      sub:`伤害${m.dmg} 攻速${m.rate} 范围${m.range}`,
      data:m, onBuy:() => buyEquip('melee', m)
    })));
  } else if (tab === 'buy-armor') {
    ARMORS.forEach(a => body.appendChild(marketCard({
      icon:'🛡️', name:a.name, price:a.price, type:'armor',
      sub:`${a.tier}级甲 耐久${a.dur} 减伤${Math.round(a.red*100)}%`,
      data:a, onBuy:() => buyEquip('armor', a)
    })));
    HELMETS.forEach(h => body.appendChild(marketCard({
      icon:'⛑️', name:h.name, price:h.price, type:'helmet',
      sub:`${h.tier}级盔 耐久${h.dur} 减伤${Math.round(h.red*100)}%`,
      data:h, onBuy:() => buyEquip('helmet', h)
    })));
  } else if (tab === 'buy-med') {
    MEDS.forEach(m => body.appendChild(marketCard({
      icon:m.icon, name:m.name, price:m.price, type:'med',
      sub:`恢复${Math.round(m.heal*100)}%`,
      data:m, onBuy:() => buyEquip('med', m)
    })));
  } else if (tab === 'buy-ammo') {
    AMMO_TYPES.forEach(a => body.appendChild(marketCard({
      icon:a.icon, name:a.name, price:a.price, type:'ammo',
      sub:`伤害系数 ×${a.dmgMul} · 每发${a.price}币`,
      data:a, onBuy:() => buyAmmo(a, 30)
    })));
  } else if (tab === 'sell') {
    const sellable = G.warehouse.filter(it => inferType(it) === 'loot');
    if (sellable.length === 0) {
      body.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">没有可卖出的变卖物。</p>';
      return;
    }
    sellable.sort((a,b)=>(b.level||0)-(a.level||0)).forEach(item => {
      body.appendChild(marketCard({
        icon:item.icon||'❔', name:item.name,
        price:Math.floor((item.price||0)*0.8),
        sub:`Lv${item.level||'—'} · 原价${fmt(item.price||0)}`,
        onBuy:() => {
          G.money += Math.floor(item.price * 0.8);
          removeFromWarehouse(item.uid);
          save(); renderMarket('sell');
        }, buyLabel:'出售', data:item, type:'loot'
      }));
    });
  }
}

function marketCard({icon, name, price, sub, onBuy, buyLabel='购买', type, data}) {
  const c = document.createElement('div');
  c.className = 'market-card';
  c.innerHTML = `
    <div class="mk-icon">${icon}</div>
    <div class="mk-name">${name}</div>
    <div class="mk-sub">${sub||''}</div>
    <div class="mk-price">${fmt(price)} 币</div>
    <button class="mk-btn">${buyLabel}</button>
  `;
  const btn = c.querySelector('.mk-btn');
  btn.onclick = (e) => {
    e.stopPropagation();
    onBuy();
  };
  return c;
}

function buyEquip(slot, data) {
  if (G.money < data.price) { alert('柯恩币不足'); return; }
  G.money -= data.price;
  const item = clone(data);
  item.type = slot;
  item.uid = uid();
  item.kind = slot;
  if (slot === 'med') item.icon = item.icon || '🩹';
  addToWarehouse(item);
  save();
  alert(`${item.name} 已放入仓库`);
  renderTopbar();
  renderMarket('buy-' + (slot === 'melee' ? 'melee' : slot === 'med' ? 'med' : slot === 'weapon' ? 'weapon' : 'armor'));
}

function buyAmmo(data, count) {
  const total = data.price * count;
  if (G.money < total) { alert('柯恩币不足'); return; }
  G.money -= total;
  const item = clone(data);
  item.type = 'ammo';
  item.ammoId = data.id;
  item.icon = data.icon;
  item.count = count;
  item.uid = uid();
  item.price = data.price;
  addToWarehouse(item);
  save();
  alert(`购买 ${data.name} ×${count}`);
  renderTopbar();
  renderMarket('buy-ammo');
}

/* ================= 7. 装备 ================= */

function equipFromWarehouse(item) {
  const t = inferType(item);
  if (t === 'loot') { alert('变卖物不能装备'); return; }
  if (t === 'ammo') {
    G.equipment.ammo = (G.equipment.ammo || 0) + (item.count || 0);
    G.equipment.ammoType = item.ammoId || 'AM1';
    removeFromWarehouse(item.uid);
    save();
    alert(`装填 ${item.name} ×${item.count}`);
    return;
  }
  if (t === 'med') {
    if (G.equipment.meds.length >= 3) { alert('药品已满（3 个）'); return; }
    removeFromWarehouse(item.uid);
    G.equipment.meds.push(item);
    save();
    return;
  }
  // 武器/刀/甲/盔
  const slotMap = { weapon:'weapon', melee:'melee', armor:'armor', helmet:'helmet' };
  const slot = slotMap[t];
  if (!slot) return;
  // 已有装备退回仓库
  if (G.equipment[slot]) {
    const old = G.equipment[slot];
    old.type = slot;
    addToWarehouse(old);
  }
  G.equipment[slot] = item;
  removeFromWarehouse(item.uid);
  save();
}

function unequip(slot) {
  if (slot === 'meds') {
    G.equipment.meds.forEach(m => addToWarehouse(m));
    G.equipment.meds = [];
    save(); renderLoadout(); return;
  }
  const item = G.equipment[slot];
  if (!item) return;
  item.type = slot;
  addToWarehouse(item);
  G.equipment[slot] = null;
  save();
  renderLoadout();
}

function renderLoadout() {
  renderTopbar();
  const eq = G.equipment;
  setSlot('#slot-weapon', eq.weapon, 'weapon');
  setSlot('#slot-melee', eq.melee, 'melee');
  setSlot('#slot-armor', eq.armor, 'armor');
  setSlot('#slot-helmet', eq.helmet, 'helmet');
  const medSlot = $('#slot-meds');
  medSlot.querySelector('.slot-value').textContent = eq.meds.length
    ? eq.meds.map(m => m.name).join(' / ') : '空';
  medSlot.classList.toggle('filled', eq.meds.length > 0);

  $('#loadout-value').textContent = fmt(equipValue());
  $('#loadout-ammo').textContent = eq.ammo || 0;

  // 绑定卸下
  $$('.slot').forEach(el => {
    el.onclick = () => {
      const k = el.dataset.key;
      if (k === 'meds') {
        if (eq.meds.length) unequip('meds');
      } else if (eq[k]) {
        unequip(k);
      }
    };
  });

  // 渲染仓库可选
  const picker = $('#loadout-picker');
  picker.innerHTML = '';
  const candidates = G.warehouse.filter(it => {
    const t = inferType(it);
    return ['weapon','melee','armor','helmet','med','ammo'].includes(t);
  });
  if (candidates.length === 0) {
    picker.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:20px">仓库里没有可装备的物品。</p>';
    return;
  }
  candidates.forEach(item => {
    const t = inferType(item);
    const card = document.createElement('div');
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = `
      <span class="emoji">${item.icon||getTypeIcon(t)}</span>
      <span class="name-mini">${item.name}</span>
      ${item.count > 1 ? `<span class="count-badge">×${item.count}</span>` : ''}
    `;
    card.onclick = () => {
      equipFromWarehouse(item);
      renderLoadout();
    };
    picker.appendChild(card);
  });
}

function setSlot(sel, item, key) {
  const el = $(sel);
  const v = el.querySelector('.slot-value');
  if (item) {
    v.textContent = item.name;
    el.classList.add('filled');
  } else {
    v.textContent = '空';
    el.classList.remove('filled');
  }
}

function equipValue() {
  const e = G.equipment;
  let v = 0;
  if (e.weapon) v += e.weapon.price||0;
  if (e.melee)  v += e.melee.price||0;
  if (e.armor)  v += e.armor.price||0;
  if (e.helmet) v += e.helmet.price||0;
  e.meds.forEach(m => v += m.price||0);
  v += (e.ammo || 0) * 3;
  return v;
}

/* ================= 8. 地图 ================= */

function renderMap() {
  renderTopbar();
  const body = $('#scr-map');
  const mapList = Object.values(MAPS).map(m => {
    const locked = !G.unlockedMaps.includes(m.id);
    const btns = locked ? '' : `
      <div class="difficulty-row">
        <button data-map="${m.id}" data-diff="normal">普通 ×1.0</button>
        <button data-map="${m.id}" data-diff="hard" class="${equipValue() < 50000 ? 'locked' : ''}">困难 ×1.5</button>
        <button data-map="${m.id}" data-diff="lockdown" class="${equipValue() < 150000 ? 'locked' : ''}">封锁 ×2.5</button>
      </div>`;
    return `<div class="map-card" style="${locked?'opacity:.4':''}">
      <div class="map-name">${m.name}</div>
      <div class="map-desc">${m.desc}${locked?' · 未解锁':''}</div>
      ${btns}
    </div>`;
  }).join('');
  body.innerHTML = `
    <div class="screen-header">
      <h2>选择地图</h2>
      <div class="screen-tools">携带价值：<span style="color:#c8742a">${fmt(equipValue())}</span></div>
    </div>
    ${mapList}
  `;
  body.querySelectorAll('.difficulty-row button').forEach(btn => {
    btn.onclick = () => {
      const d = DIFFICULTY[btn.dataset.diff];
      if (equipValue() < d.minValue) {
        alert(`${d.name}难度需携带价值 ≥ ${fmt(d.minValue)}`);
        return;
      }
      startRaid(btn.dataset.map, btn.dataset.diff);
    };
  });
}

/* ================= 9. 任务 ================= */

function renderQuest() {
  renderTopbar();
  const q = G.quest;
  $('#scr-quest').innerHTML = `
    <h2>任务</h2>
    <div class="map-card">
      <div class="map-name" style="font-size:18px">${q.name}</div>
      <div class="map-desc">${q.desc}</div>
      <p style="font-size:13px;color:#c8742a;margin:10px 0">进度：${q.progress}/${q.target}</p>
      <p style="font-size:12px;color:#8a8578">奖励：${fmt(q.reward)}</p>
      ${q.done ? '<p style="color:#4caf50;margin-top:10px">✅ 已完成</p>' : ''}
    </div>
  `;
}

function updateQuest(type) {
  const q = G.quest;
  if (q.done) return;
  if (q.id === 'q1' && type === 'extract') q.progress = Math.min(q.target, q.progress + 1);
  if (q.progress >= q.target) {
    q.done = true;
    G.money += q.reward;
    alert(`任务完成：${q.name}\n奖励 ${fmt(q.reward)} 币`);
    if (!G.unlockedMaps.includes('mine')) {
      G.unlockedMaps.push('mine');
      alert('🎉 解锁新地图：废弃矿洞');
    }
  }
}

/* ================= 10. 局内 ================= */

let raid = null;
let raidTimer = null;
let gameLoopTimer = null;
let bulletsTimer = null;
let fireInterval = null;
let playerPos = { x:1500, y:1500 };
let moveDir = { x:0, y:0 };
let aimDir = { x:1, y:0 };
let firing = false;
let extractCountdown = null;

function startRaid(mapId, diffKey) {
  const diff = DIFFICULTY[diffKey];
  const map = MAPS[mapId];

  // 跑刀模式：没枪没刀自动给生锈小刀
  if (!G.equipment.weapon && !G.equipment.melee) {
    G.equipment.melee = clone(MELEES[0]);
    G.equipment.melee.uid = uid();
    G.equipment.melee.type = 'melee';
    G.equipment.melee.kind = 'melee';
  }

  const field = $('#raid-field');
  field.innerHTML = '';
  playerPos = { x:1500, y:1500 };
  moveDir = { x:0, y:0 }; aimDir = { x:1, y:0 };
  firing = false;

  raid = {
    mapId, diff: diffKey,
    luck: diff.luck * map.lootMul,
    hp: 100, maxHp: 100,
    timeLeft: 300,
    lootValue: 0, backpack: [],
    enemies: [], boxes: [], extract: null,
    armor: G.equipment.armor ? clone(G.equipment.armor) : null,
    helmet: G.equipment.helmet ? clone(G.equipment.helmet) : null,
    log: [], over: false, kills: 0,
    ammo: G.equipment.ammo || 0,
    magSize: G.equipment.weapon ? G.equipment.weapon.mag : 0,
    magAmmo: G.equipment.weapon ? G.equipment.weapon.mag : 0,
    weapon: G.equipment.weapon ? clone(G.equipment.weapon) : null,
    melee: G.equipment.melee ? clone(G.equipment.melee) : clone(MELEES[0]),
    bullets: [],
    isKnifeRun: !G.equipment.weapon,
    autoUseMed: true
  };

  // 玩家元素
  const pEl = document.createElement('div');
  pEl.id = 'player'; pEl.textContent = '🧍';
  pEl.style.left = '1500px'; pEl.style.top = '1500px';
  field.appendChild(pEl);

  // 场景装饰
  for (let i = 0; i < 50; i++) {
    const t = randPick(['house','rock','tree','']);
    if (!t) continue;
    const d = document.createElement('div');
    d.className = 'deco ' + t;
    d.textContent = t==='house'?'🏚️':t==='rock'?'🪨':'🌲';
    d.style.left = rand(100,2900) + 'px';
    d.style.top  = rand(100,2900) + 'px';
    field.appendChild(d);
  }

  // 敌人
  const count = Math.round(rand(diff.ec[0], diff.ec[1]) * map.enMul);
  for (let i = 0; i < count; i++) spawnEnemy(randPick(ENEMIES), field);
  if (diff.boss) spawnEnemy(BOSS, field);

  // 容器
  const boxCount = Math.round(16 * map.lootMul);
  for (let i = 0; i < boxCount; i++) spawnBox(randPick(CONTAINERS), field);

  // 撤离点
  spawnExtract(field);

  go('raid');
  bindRaidControls();
  updateCamera();
  renderRaidHUD();
  updateMedSlots();

  // 切换开火/挥刀
  const fb = $('#btn-fire'), mb = $('#btn-melee');
  if (raid.weapon) { fb.style.display = 'flex'; mb.style.display = 'none'; }
  else { fb.style.display = 'none'; mb.style.display = 'flex'; }

  // 计时
  clearInterval(raidTimer);
  raidTimer = setInterval(() => {
    if (!raid || raid.over) return;
    raid.timeLeft--;
    if (raid.timeLeft <= 0) { endRaid(false); return; }
    renderRaidHUD();
    drawMinimap();
  }, 1000);

  // 游戏循环
  clearInterval(gameLoopTimer);
  gameLoopTimer = setInterval(gameLoop, 50);
  clearInterval(bulletsTimer);
  bulletsTimer = setInterval(updateBullets, 30);
}

function spawnEnemy(tpl, field) {
  const el = document.createElement('div');
  el.className = 'enemy' + (tpl.id === 'BOSS' ? ' boss' : '');
  const x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  el.innerHTML = `<div class="hp-mini"><div style="width:100%"></div></div>` + tpl.icon;
  const obj = { el, tpl: clone(tpl), hp: tpl.hp, x, y, alive:true, cd:0, alert:false };
  raid.enemies.push(obj);
  field.appendChild(el);
}

function spawnBox(tpl, field) {
  const el = document.createElement('div');
  el.className = 'loot-box'; el.textContent = tpl.icon;
  const x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  const obj = { el, tpl, x, y, searched:false };
  el.onclick = e => { e.stopPropagation(); searchBox(obj); };
  raid.boxes.push(obj); field.appendChild(el);
}

function spawnExtract(field) {
  const el = document.createElement('div');
  el.className = 'extract-zone'; el.textContent = '撤离';
  const x = rand(300,2700), y = rand(300,2700);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  const obj = { el, x, y };
  el.onclick = e => { e.stopPropagation(); tryExtract(); };
  raid.extract = obj; field.appendChild(el);
}

/* ---------- 操作绑定 ---------- */
function bindRaidControls() {
  // 左摇杆移动
  const jz = $('#joystick-zone'), js = $('#joystick-stick'), jb = $('#joystick-base');
  let jActive = false;
  const jStart = e => { e.preventDefault(); jActive = true; };
  const jMove = e => {
    if (!jActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    const r = jb.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = t.clientX - cx, dy = t.clientY - cy;
    const len = Math.hypot(dx, dy), max = r.width/2 - 20;
    if (len > max){ dx = dx/len*max; dy = dy/len*max; }
    js.style.transform = `translate(${dx}px,${dy}px)`;
    if (Math.hypot(dx, dy) > 10) moveDir = { x: dx/max, y: dy/max };
    else moveDir = { x:0, y:0 };
  };
  const jEnd = () => { jActive = false; moveDir = { x:0, y:0 }; js.style.transform = ''; };
  jz.addEventListener('touchstart', jStart, { passive:false });
  jz.addEventListener('touchmove', jMove, { passive:false });
  jz.addEventListener('touchend', jEnd);
  jz.addEventListener('mousedown', jStart);
  document.addEventListener('mousemove', e => { if (jActive) jMove(e); });
  document.addEventListener('mouseup', () => { if (jActive) jEnd(); });

  // 右摇杆瞄准
  const az = $('#aim-zone'), as = $('#aim-stick'), ab = $('#aim-base');
  let aActive = false;
  const aStart = e => { e.preventDefault(); aActive = true; };
  const aMove = e => {
    if (!aActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    const r = ab.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = t.clientX - cx, dy = t.clientY - cy;
    const len = Math.hypot(dx, dy), max = r.width/2 - 18;
    if (len > max){ dx = dx/len*max; dy = dy/len*max; }
    as.style.transform = `translate(${dx}px,${dy}px)`;
    const nlen = Math.hypot(dx, dy);
    if (nlen > 8){ aimDir = { x: dx/nlen, y: dy/nlen }; updateCrosshair(); }
  };
  const aEnd = () => { aActive = false; as.style.transform = ''; };
  az.addEventListener('touchstart', aStart, { passive:false });
  az.addEventListener('touchmove', aMove, { passive:false });
  az.addEventListener('touchend', aEnd);
  az.addEventListener('mousedown', aStart);
  document.addEventListener('mousemove', e => { if (aActive) aMove(e); });
  document.addEventListener('mouseup', () => { if (aActive) aEnd(); });

  // 开火
  const fb = $('#btn-fire');
  fb.addEventListener('touchstart', e => { e.preventDefault(); startFire(); });
  fb.addEventListener('touchend', e => { e.preventDefault(); stopFire(); });
  fb.addEventListener('mousedown', e => { e.preventDefault(); startFire(); });
  fb.addEventListener('mouseup', stopFire);

  // 近战
  const mb = $('#btn-melee');
  mb.addEventListener('touchstart', e => { e.preventDefault(); meleeAttack(); });
  mb.addEventListener('mousedown', e => { e.preventDefault(); meleeAttack(); });

  // 手雷
  const gb = $('#btn-grenade');
  if (gb) {
    gb.addEventListener('touchstart', e => { e.preventDefault(); throwGrenade(); });
    gb.addEventListener('mousedown', e => { e.preventDefault(); throwGrenade(); });
  }

  // 换弹、撤离、药品
  $('#btn-reload').onclick = reload;
  $('#btn-extract').onclick = tryExtract;
  $$('.med-slot').forEach((el, i) => { el.onclick = () => useMed(i); });
  $('#btn-back').onclick = () => go('warehouse');
}

function updateCrosshair() {
  const ch = $('#crosshair');
  if (!ch) return;
  const dist = 80;
  const vw = window.innerWidth / 2, vh = window.innerHeight / 2;
  ch.style.left = (vw + aimDir.x * dist) + 'px';
  ch.style.top  = (vh + aimDir.y * dist) + 'px';
}

function updateCamera() {
  if (!raid) return;
  const cam = $('#raid-camera');
  const cx = playerPos.x - window.innerWidth / 2;
  const cy = playerPos.y - window.innerHeight / 2;
  cam.style.transform = `translate(${-cx}px,${-cy}px)`;
}

/* ---------- 开火 ---------- */
function startFire() {
  if (!raid || raid.over || !raid.weapon) return;
  firing = true;
  $('#btn-fire').classList.add('firing');
  const interval = Math.max(60, 60000 / raid.weapon.rate);
  doFire();
  fireInterval = setInterval(doFire, interval);
}
function stopFire() {
  firing = false;
  $('#btn-fire').classList.remove('firing');
  clearInterval(fireInterval);
}
function doFire() {
  if (!raid || raid.over || !firing) return;
  if (!raid.weapon) return;
  if (raid.magAmmo <= 0) { autoReload(); return; }
  if (raid.ammo <= 0) { raid.log.push('没子弹了！'); renderRaidHUD(); stopFire(); return; }
  raid.magAmmo--;
  raid.ammo--;

  const bx = playerPos.x + aimDir.x * 30;
  const by = playerPos.y + aimDir.y * 30;
  const el = document.createElement('div');
  el.className = 'bullet';
  el.style.left = bx + 'px'; el.style.top = by + 'px';
  const angle = Math.atan2(aimDir.y, aimDir.x) * 180 / Math.PI;
  el.style.transform = `translate(-50%,-50%) rotate(${angle}deg)`;
  $('#raid-field').appendChild(el);

  const speed = raid.weapon.bulletSpeed;
  raid.bullets.push({
    el, x:bx, y:by,
    vx: aimDir.x * speed, vy: aimDir.y * speed,
    dmg: raid.weapon.dmg,
    range: raid.weapon.range, dist: 0, owner: 'player'
  });

  // 枪口火焰
  const m = document.createElement('div');
  m.className = 'muzzle';
  m.style.left = bx + 'px'; m.style.top = by + 'px';
  $('#raid-field').appendChild(m);
  setTimeout(() => m.remove(), 100);
  renderRaidHUD();
}

function autoReload() {
  if (!raid || !raid.weapon) return;
  if (raid.ammo <= 0) { raid.log.push('无弹药可换'); renderRaidHUD(); return; }
  const need = raid.magSize - raid.magAmmo;
  const take = Math.min(need, raid.ammo);
  raid.magAmmo += take;
  raid.ammo -= take;
  raid.log.push(`换弹 +${take}`);
  renderRaidHUD();
}
function reload() { autoReload(); }

/* ---------- 近战 ---------- */
function meleeAttack() {
  if (!raid || raid.over) return;
  const m = raid.melee || MELEES[0];
  const now = Date.now();
  if (raid._lastMelee && now - raid._lastMelee < 60000/m.rate) return;
  raid._lastMelee = now;
  const checkRange = m.range + 20;
  const targets = raid.enemies.filter(e =>
    e.alive && Math.hypot(e.x - playerPos.x, e.y - playerPos.y) <= checkRange
  );
  if (targets.length === 0) { raid.log.push('挥空了'); renderRaidHUD(); return; }
  const target = targets[0];
  hitEnemy(target, m.dmg);
  raid.log.push(`⚔️ ${m.name} 命中 ${target.tpl.name}`);
  renderRaidHUD();
  const slash = document.createElement('div');
  slash.className = 'slash';
  slash.style.left = target.x + 'px';
  slash.style.top  = target.y + 'px';
  $('#raid-field').appendChild(slash);
  setTimeout(() => slash.remove(), 250);
}

/* ---------- 手雷 ---------- */
function throwGrenade() {
  if (!raid || raid.over) return;
  if (raid._grenadeCd && Date.now() - raid._grenadeCd < 5000) {
    raid.log.push('手雷冷却中');
    renderRaidHUD(); return;
  }
  raid._grenadeCd = Date.now();
  const tx = playerPos.x + aimDir.x * 220;
  const ty = playerPos.y + aimDir.y * 220;
  const el = document.createElement('div');
  el.className = 'explosion';
  el.style.left = tx + 'px';
  el.style.top = ty + 'px';
  $('#raid-field').appendChild(el);
  setTimeout(() => el.remove(), 600);

  // 伤害范围内敌人
  raid.enemies.forEach(e => {
    if (!e.alive) return;
    const d = Math.hypot(e.x - tx, e.y - ty);
    if (d < 130) {
      const dmg = Math.round(120 * (1 - d/130));
      hitEnemy(e, dmg);
    }
  });
  raid.log.push('💣 手雷爆炸');
  renderRaidHUD();
}

/* ---------- 子弹更新 ---------- */
function updateBullets() {
  if (!raid || raid.over) return;
  for (let i = raid.bullets.length - 1; i >= 0; i--) {
    const b = raid.bullets[i];
    b.x += b.vx; b.y += b.vy;
    b.dist += Math.hypot(b.vx, b.vy);
    b.el.style.left = b.x + 'px';
    b.el.style.top  = b.y + 'px';
    if (b.dist > b.range) { b.el.remove(); raid.bullets.splice(i, 1); continue; }
    let hit = false;
    if (b.owner === 'player') {
      for (const e of raid.enemies) {
        if (!e.alive) continue;
        if (Math.hypot(e.x - b.x, e.y - b.y) < 25) {
          hitEnemy(e, b.dmg);
          b.el.remove(); raid.bullets.splice(i, 1); hit = true; break;
        }
      }
    }
    if (hit) continue;
  }
}

/* ---------- 伤害敌人 ---------- */
function hitEnemy(enemy, dmg) {
  enemy.hp -= dmg;
  enemy.el.classList.add('hurt');
  setTimeout(() => enemy.el.classList.remove('hurt'), 200);
  const hpBar = enemy.el.querySelector('.hp-mini > div');
  if (hpBar) hpBar.style.width = Math.max(0, enemy.hp/enemy.tpl.hp*100) + '%';
  const bl = document.createElement('div');
  bl.className = 'blood';
  bl.style.left = enemy.x + 'px'; bl.style.top = enemy.y + 'px';
  $('#raid-field').appendChild(bl);
  setTimeout(() => bl.remove(), 400);

  if (enemy.hp <= 0) {
    enemy.alive = false;
    enemy.el.classList.add('dead');
    raid.kills++; G.stats.kills++; G.stats.totalKills++;
    raid.log.push(`击杀 ${enemy.tpl.name}`);
    addKillFeed(enemy.tpl.name);

    // 经验与奖励
    const exp = enemy.tpl.exp || 10;
    addExp(exp);
    const killReward = Math.round(exp * 20);
    G.money += killReward;

    // 掉落
    const drop = rollLoot(enemy.tpl.dropTier);
    if (drop) {
      raid.backpack.push(drop);
      raid.lootValue += drop.price;
      raid.log.push(`拾取 ${drop.name}（${fmt(drop.price)}）`);
    }
    // Boss 专属掉落
    if (enemy.tpl.id === 'BOSS' && Math.random() < 0.6) {
      const sp = clone(BOSS.specialDrop);
      sp.uid = uid();
      raid.backpack.push(sp);
      raid.lootValue += sp.price;
      raid.log.push(`★ 掉落 ${sp.name}`);
    }
    renderRaidHUD();
  }
}

function addKillFeed(name) {
  const kf = $('#kill-feed');
  const d = document.createElement('div');
  d.textContent = `💀 击杀 ${name}`;
  kf.appendChild(d);
  setTimeout(() => d.remove(), 3000);
}

/* ---------- 玩家经验 ---------- */
let playerLevel = 1, playerExp = 0;
function expToNext(lv) { return 100 + (lv-1) * 80; }

function addExp(n) {
  playerExp += n;
  while (playerExp >= expToNext(playerLevel)) {
    playerExp -= expToNext(playerLevel);
    playerLevel++;
    alert(`⭐ 升级到 Lv${playerLevel}`);
  }
}

/* ---------- 游戏循环 ---------- */
function gameLoop() {
  if (!raid || raid.over) return;
  // 玩家移动
  if (moveDir.x !== 0 || moveDir.y !== 0) {
    const speed = raid.isKnifeRun ? 6.5 : 5;
    playerPos.x = Math.max(40, Math.min(2960, playerPos.x + moveDir.x * speed));
    playerPos.y = Math.max(40, Math.min(2960, playerPos.y + moveDir.y * speed));
    const p = $('#player');
    if (p) { p.style.left = playerPos.x + 'px'; p.style.top = playerPos.y + 'px'; }
    updateCamera();
  }
  // 敌人 AI
  const now = Date.now();
  raid.enemies.forEach(e => {
    if (!e.alive) return;
    const dx = playerPos.x - e.x, dy = playerPos.y - e.y;
    const dist = Math.hypot(dx, dy);
    // 视距警戒
    if (dist < 600) {
      if (!e.alert) { e.alert = true; e.el.classList.add('alert'); }
      if (dist > 80) {
        const sp = 1.3;
        e.x += (dx/dist) * sp; e.y += (dy/dist) * sp;
        e.el.style.left = e.x + 'px'; e.el.style.top = e.y + 'px';
      }
      // 开火
      if (dist < 480 && now - e.cd > 1500) {
        e.cd = now;
        enemyShoot(e);
      }
    } else {
      e.alert = false; e.el.classList.remove('alert');
    }
  });
}

function enemyShoot(e) {
  let dmg = e.tpl.dmg;
  let red = 0;
  if (raid.armor && raid.armor.dur > 0) {
    red += raid.armor.red;
    raid.armor.dur -= rand(1,3);
    if (raid.armor.dur < 0) raid.armor.dur = 0;
  }
  if (raid.helmet && raid.helmet.dur > 0) {
    red += raid.helmet.red * 0.5;
    raid.helmet.dur -= rand(1,2);
    if (raid.helmet.dur < 0) raid.helmet.dur = 0;
  }
  dmg = dmg * (1 - Math.min(red, 0.85));
  raid.hp -= dmg;
  const flash = $('#damage-flash');
  flash.classList.add('on');
  setTimeout(() => flash.classList.remove('on'), 80);
  if (raid.hp <= 0) { raid.hp = 0; endRaid(false); return; }
  // 自动吃药
  if (raid.autoUseMed && raid.hp < raid.maxHp * 0.3 && G.equipment.meds.length > 0) {
    useMed(0);
  }
  renderRaidHUD();
}

/* ---------- 搜索 ---------- */
function searchBox(obj) {
  if (!obj || obj.searched || !raid || raid.over) return;
  const dist = Math.hypot(obj.x - playerPos.x, obj.y - playerPos.y);
  if (dist > 90) { raid.log.push('太远了，走近点'); renderRaidHUD(); return; }
  obj.searched = true;
  obj.el.classList.add('searched');
  const drop = rollLoot(obj.tpl.tier);
  if (drop) {
    raid.backpack.push(drop);
    raid.lootValue += drop.price;
    raid.log.push(`获得 ${drop.name}（${fmt(drop.price)}）`);
  } else raid.log.push('空空如也');
  renderRaidHUD();
}

/* ---------- 药品 ---------- */
function useMed(i) {
  if (!raid || raid.over) return;
  const item = G.equipment.meds[i];
  if (!item) return;
  const heal = item.heal * raid.maxHp;
  raid.hp = Math.min(raid.maxHp, raid.hp + heal);
  G.equipment.meds.splice(i, 1);
  save(); updateMedSlots(); renderRaidHUD();
  raid.log.push(`使用 ${item.name}，恢复 ${Math.round(heal)}`);
  renderRaidHUD();
}

function updateMedSlots() {
  $$('.med-slot').forEach((el, i) => {
    const med = G.equipment.meds[i];
    el.textContent = med ? med.icon : '➕';
    el.classList.toggle('filled', !!med);
  });
}

/* ---------- 撤离 ---------- */
function tryExtract() {
  if (!raid || raid.over) return;
  const d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
  if (d > 100) { raid.log.push('离撤离点太远'); renderRaidHUD(); return; }
  startExtractCountdown();
}

function startExtractCountdown() {
  if (extractCountdown) return;
  let count = 5;
  $('#extract-count').textContent = count;
  $('#extract-progress').classList.remove('hidden');
  extractCountdown = setInterval(() => {
    // 中断检查
    if (!raid || raid.over) {
      clearInterval(extractCountdown); extractCountdown = null;
      $('#extract-progress').classList.add('hidden');
      return;
    }
    const d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
    if (d > 130) {
      clearInterval(extractCountdown); extractCountdown = null;
      $('#extract-progress').classList.add('hidden');
      raid.log.push('离开撤离点，撤离中断');
      renderRaidHUD();
      return;
    }
    count--;
    $('#extract-count').textContent = count;
    if (count <= 0) {
      clearInterval(extractCountdown); extractCountdown = null;
      $('#extract-progress').classList.add('hidden');
      endRaid(true);
    }
  }, 1000);
}

/* ---------- 结束 ---------- */
function endRaid(success) {
  if (raid.over) return;
  raid.over = true;
  clearInterval(raidTimer);
  clearInterval(gameLoopTimer);
  clearInterval(bulletsTimer);
  clearInterval(fireInterval);
  if (extractCountdown) { clearInterval(extractCountdown); extractCountdown = null; }
  G.stats.raids++;

  if (success) {
    G.stats.extracts++;
    // 背包物品入仓库
    raid.backpack.forEach(addToWarehouse);
    // 更新最佳记录
    if (raid.lootValue > G.stats.bestLoot) G.stats.bestLoot = raid.lootValue;
    updateQuest('extract');
    // 药品消耗清空
    // 装备保留，但弹药和药品消耗
  } else {
    G.stats.deaths++;
    // 死亡：装备全掉
    G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[], ammo:0, ammoType:'AM1' };
  }
  save();
  showResult(success);
}

function showResult(success) {
  const overlay = $('#result-overlay');
  overlay.classList.remove('hidden');
  $('#result-title').textContent = success ? '撤离成功' : '任务失败 · 装备丢失';
  const body = $('#result-body');
  if (success) {
    body.innerHTML = `
      <p>带回 ${raid.backpack.length} 件物资</p>
      <p>总价值：${fmt(raid.lootValue)} 柯恩币</p>
      <p>击杀：${raid.kills}</p>`;
  } else {
    body.innerHTML = `
      <p>你在 ${MAPS[raid.mapId].name} 倒下了</p>
      <p>装备全部丢失，仓库物资安全</p>
      <p>本次击杀：${raid.kills}</p>`;
  }
  renderTopbar();
}

/* ---------- HUD ---------- */
function renderRaidHUD() {
  if (!raid) return;
  $('#raid-loot').textContent = fmt(raid.lootValue);
  $('#raid-kills').textContent = raid.kills;
  const m = String(Math.floor(raid.timeLeft/60)).padStart(2,'0');
  const s = String(raid.timeLeft % 60).padStart(2,'0');
  if (raid.weapon) {
    $('#raid-timer').textContent = `${m}:${s}`;
    $('#ammo-pill').style.display = 'block';
    $('#raid-ammo').textContent = `${raid.magAmmo}/${raid.magSize} (剩${raid.ammo})`;
    $('#ammo-pill').classList.toggle('low', raid.magAmmo <= raid.magSize * 0.3);
  } else {
    $('#raid-timer').textContent = `${m}:${s} 🔪`;
    $('#ammo-pill').style.display = 'none';
  }
  const hpPct = raid.hp / raid.maxHp * 100;
  const fill = $('#hp-fill');
  fill.style.width = hpPct + '%';
  fill.classList.toggle('low', hpPct < 30);
  $('#hp-text').textContent = `${Math.round(raid.hp)} / ${raid.maxHp}`;
  const log = $('#raid-log');
  log.innerHTML = raid.log.slice(-5).map(l => '· ' + l).join('<br>');

  // 状态图标（护甲/头盔耐久）
  const si = $('#status-icons');
  let html = '';
  if (raid.armor && raid.armor.dur > 0) html += `<div class="status-icon">🛡️ ${raid.armor.dur}</div>`;
  if (raid.helmet && raid.helmet.dur > 0) html += `<div class="status-icon">⛑️ ${raid.helmet.dur}</div>`;
  if (raid.isKnifeRun) html += `<div class="status-icon">🔪 跑刀</div>`;
  si.innerHTML = html;
}

/* ---------- 小地图 ---------- */
function drawMinimap() {
  const c = $('#minimap'); if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height;
  ctx.clearRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(13,15,12,0.85)';
  ctx.fillRect(0, 0, W, H);
  const scale = W / 3000;
  raid.enemies.forEach(e => {
    if (!e.alive) return;
    ctx.fillStyle = e.tpl.id === 'BOSS' ? '#ffd700' : '#ff3b3b';
    ctx.beginPath();
    ctx.arc(e.x*scale, e.y*scale, 3, 0, Math.PI*2);
    ctx.fill();
  });
  ctx.fillStyle = '#c8742a';
  raid.boxes.forEach(b => {
    if (b.searched) return;
    ctx.fillRect(b.x*scale-2, b.y*scale-2, 3, 3);
  });
  if (raid.extract) {
    ctx.fillStyle = '#4caf50';
    ctx.beginPath();
    ctx.arc(raid.extract.x*scale, raid.extract.y*scale, 5, 0, Math.PI*2);
    ctx.fill();
  }
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(playerPos.x*scale, playerPos.y*scale, 4, 0, Math.PI*2);
  ctx.fill();
}

/* ================= 11. 存档导出/导入 ================= */

function exportSave() {
  const data = JSON.stringify(G);
  const str = btoa(unescape(encodeURIComponent(data)));
  prompt('复制下面这串存档码：', str);
}
function importSave() {
  const str = prompt('粘贴存档码：');
  if (!str) return;
  try {
    const data = decodeURIComponent(escape(atob(str)));
    const obj = JSON.parse(data);
    if (obj && obj.money !== undefined) {
      G = obj;
      save();
      alert('导入成功');
      renderTopbar(); renderWarehouse();
    } else {
      alert('存档格式错误');
    }
  } catch(e) { alert('导入失败：' + e.message); }
}

/* ================= 12. 启动 ================= */

function bindEvents() {
  $$('#bottomnav button').forEach(btn => {
    btn.onclick = () => go(btn.dataset.go);
  });
  $$('.tabs button').forEach(btn => {
    btn.onclick = () => renderMarket(btn.dataset.tab);
  });
  $$('.filter-tabs button').forEach(btn => {
    btn.onclick = () => {
      warehouseFilter = btn.dataset.filter;
      $$('.filter-tabs button').forEach(b => b.classList.toggle('active', b === btn));
      renderWarehouse();
    };
  });
  const be = $('#btn-export-save'); if (be) be.onclick = exportSave;
  const bi = $('#btn-import-save'); if (bi) bi.onclick = importSave;

  window.addEventListener('resize', checkOrientation);
  window.addEventListener('orientationchange', checkOrientation);
  window.addEventListener('keydown', e => {
    if (!raid || raid.over) return;
    if (e.key === 'r' || e.key === 'R') reload();
  });
}

function checkOrientation() {
  const tip = $('#rotate-tip');
  if (!tip) return;
  tip.style.display = (window.innerHeight > window.innerWidth) ? 'flex' : 'none';
}

function boot() {
  load();
  bindEvents();
  checkOrientation();
  renderTopbar();
  go('warehouse');
}

window.addEventListener('DOMContentLoaded', boot);
if (document.readyState !== 'loading') boot();