/* ================= 数据层 ================= */
const LOOT_NAMES = {
  1: ['锈铁钉','破布条','空塑料瓶','旧电池','铜线圈','断扳手','黄胶带','油气打火机',
      '短铅笔','碎橡皮','铁螺丝','小弹簧','麻绳头','汽水瓶盖','湿纸板','塑料袋',
      '瘪铝罐','脏纱布','木楔子','橡皮筋','订书钉','弯回形针','半截牙签'],
  2: ['医用绷带','压缩能量棒','打火机油','黄铜管','废电缆','铁皮工具箱','防水帆布',
      '旧手电','五号电池组','军用水壶','硬饼干','止血带','铁口哨','指南针',
      '裂镜放大镜','温度计','听诊器','手术刀片','注射器','氧气罐','滤毒罐芯'],
  3: ['军用口粮','红外滤镜','加密U盘','SIM卡组','夜视仪镜片','消音器零件','四倍瞄准镜',
      '防弹插板','战术手套','军靴','头盔衬垫','水袋','GPS模块','短波电台','双筒望远镜',
      '红色信号弹','灰烟幕弹','闪光雷','破片手雷','燃烧瓶','C4塑胶炸药'],
  4: ['金壳手表','金手镯','镀金手机','碎钻戒指','银质胸针','老式摄影机','矿卡显卡',
      '钯金线材','除颤器','宫廷银器','激光指示模块','液压扳手','掌上游戏机','黑胶唱片机',
      '古董打字机','维修手册','金豹小雕像','青花茶壶','宝石项链','胰岛素泵',
      '精密水平仪','鎏金酒杯','纯金小块'],
  5: ['热成像模块','目标定位模块','碎纹花瓶','金狮雕像','盛宴雕塑','金魔方',
      '军用加密硬盘','卫星电话','夜视仪','防弹公文包','钛合金板','碳纤维布',
      '军用无人机','高级工具组','稀有化学品'],
  6: ['理想国芯片','军用主控芯片','核废料样本','古代金币','陨石碎片','生物样本容器','量子处理器'],
  7: ['机密文件']
};
const LEVEL_PRICE = {1:[500,3000],2:[3000,8000],3:[8000,20000],4:[20000,60000],
  5:[60000,150000],6:[150000,400000],7:[800000,900000]};
const LEVEL_STYLE = {1:{icon:'🔩',cls:'lv1'},2:{icon:'🧰',cls:'lv2'},3:{icon:'📦',cls:'lv3'},
  4:{icon:'💎',cls:'lv4'},5:{icon:'🏆',cls:'lv5'},6:{icon:'👑',cls:'lv6'},7:{icon:'🗂️',cls:'lv7'}};

const ALL_LOOT = [];
(function(){
  let uid = 1;
  for (let lv = 1; lv <= 7; lv++) {
    const [lo, hi] = LEVEL_PRICE[lv];
    LOOT_NAMES[lv].forEach((name, i) => {
      const ratio = LOOT_NAMES[lv].length === 1 ? 1 : i / (LOOT_NAMES[lv].length - 1);
      const base = lo + (hi - lo) * ratio;
      const jitter = base * (Math.random() * 0.3 - 0.15);
      const price = Math.round((base + jitter) / 100) * 100;
      ALL_LOOT.push({ id:'L'+uid++, name, level:lv, price,
        icon: LEVEL_STYLE[lv].icon, cls: LEVEL_STYLE[lv].cls });
    });
  }
})();

const WEAPONS = [
  { id:'W01', name:'锈蜂 PDW-9',  price:1000,   dmg:15, rate:900, mag:30, range:600,  bulletSpeed:14 },
  { id:'W02', name:'矿工 M870',   price:3000,   dmg:45, rate:60,  mag:6,  range:280,  bulletSpeed:9 },
  { id:'W03', name:'夜莺 MP5',    price:8000,   dmg:20, rate:800, mag:30, range:650,  bulletSpeed:14 },
  { id:'W04', name:'红壤 AK74N',  price:15000,  dmg:32, rate:650, mag:30, range:900,  bulletSpeed:16 },
  { id:'W05', name:'铁砧 SKS',    price:22000,  dmg:38, rate:300, mag:10, range:1000, bulletSpeed:17 },
  { id:'W06', name:'峡谷 BM59',   price:26000,  dmg:42, rate:350, mag:20, range:1000, bulletSpeed:17 },
  { id:'W07', name:'远钟 M14',    price:35000,  dmg:55, rate:250, mag:20, range:1100, bulletSpeed:18 },
  { id:'W08', name:'白桦 Mosin',  price:39000,  dmg:85, rate:40,  mag:5,  range:1300, bulletSpeed:22 },
  { id:'W09', name:'沙狐 MDR',    price:45000,  dmg:40, rate:700, mag:30, range:900,  bulletSpeed:15 },
  { id:'W10', name:'长枪管 M4A1', price:75000,  dmg:35, rate:800, mag:30, range:950,  bulletSpeed:16 },
  { id:'W11', name:'赤铁 AK-102', price:93000,  dmg:38, rate:650, mag:30, range:950,  bulletSpeed:16 },
  { id:'W12', name:'鹰眼 AUG',    price:120000, dmg:40, rate:750, mag:30, range:1000, bulletSpeed:16 },
  { id:'W13', name:'大西洋 FAL',  price:180000, dmg:52, rate:630, mag:20, range:1050, bulletSpeed:17 },
  { id:'W14', name:'幽灵 H416',   price:280000, dmg:45, rate:850, mag:30, range:1000, bulletSpeed:17 },
  { id:'W15', name:'审判 MK14',   price:450000, dmg:70, rate:400, mag:20, range:1200, bulletSpeed:19 }
];

const MELEES = [
  { id:'K01', name:'生锈小刀',   price:0,     dmg:20,  rate:180, range:50, desc:'默认赠送' },
  { id:'K02', name:'矿工匕首',   price:500,   dmg:35,  rate:200, range:55, desc:'便宜好用' },
  { id:'K03', name:'军用战术刀', price:2500,  dmg:55,  rate:220, range:60, desc:'一刀一个拾荒者' },
  { id:'K04', name:'猎刀',       price:8000,  dmg:80,  rate:200, range:65, desc:'高伤害' },
  { id:'K05', name:'消防斧',     price:20000, dmg:120, rate:150, range:70, desc:'劈开重装守卫' },
  { id:'K06', name:'碳纤维砍刀', price:60000, dmg:180, rate:180, range:75, desc:'顶级近战' },
  { id:'K07', name:'武士刀',     price:200000,dmg:300, rate:200, range:85, desc:'一刀必杀' }
];

const ARMORS = [
  { id:'A1', name:'特勤防弹衣',   price:2000,   dur:35, red:0.20, tier:1 },
  { id:'A2', name:'H-Tac 特勤甲', price:4500,   dur:45, red:0.30, tier:2 },
  { id:'A3', name:'KN 制式甲',    price:30000,  dur:55, red:0.45, tier:3 },
  { id:'A4', name:'SEK 壁垒甲',   price:100000, dur:65, red:0.55, tier:4 },
  { id:'A5', name:'926 复合甲',   price:200000, dur:75, red:0.65, tier:5 },
  { id:'A6', name:'IMTV 武士甲',  price:450000, dur:90, red:0.75, tier:6 }
];
const HELMETS = [
  { id:'H1', name:'工地安全帽',   price:800,    dur:20, red:0.15, tier:1 },
  { id:'H2', name:'战术软帽',     price:2500,   dur:28, red:0.25, tier:2 },
  { id:'H3', name:'KN 防弹盔',    price:18000,  dur:38, red:0.40, tier:3 },
  { id:'H4', name:'SEK 重型盔',   price:60000,  dur:50, red:0.52, tier:4 },
  { id:'H5', name:'926 复合盔',   price:130000, dur:62, red:0.62, tier:5 },
  { id:'H6', name:'IMTV 武士盔',  price:280000, dur:78, red:0.72, tier:6 }
];
const MEDS = [
  { id:'M1', name:'简易急救包', price:800,  heal:0.33, icon:'🩹' },
  { id:'M2', name:'军用急救包', price:2500, heal:0.50, icon:'💉' },
  { id:'M3', name:'白色医疗箱', price:8000, heal:1.00, icon:'🧰' }
];
const ENEMIES = [
  { id:'E01', name:'流浪拾荒者', hp:60,  dmg:8,  dropTier:'low',  icon:'🧟' },
  { id:'E02', name:'武装匪徒',   hp:90,  dmg:15, dropTier:'low',  icon:'🥷' },
  { id:'E03', name:'巡逻哨兵',   hp:80,  dmg:12, dropTier:'low',  icon:'💂' },
  { id:'E04', name:'精英斥候',   hp:110, dmg:20, dropTier:'mid',  icon:'🕵️' },
  { id:'E05', name:'重装守卫',   hp:150, dmg:18, dropTier:'mid',  icon:'🛡️' },
  { id:'E06', name:'屋顶狙击手', hp:70,  dmg:35, dropTier:'mid',  icon:'🎯' },
  { id:'E07', name:'废墟突击兵', hp:100, dmg:22, dropTier:'mid',  icon:'🔫' },
  { id:'E08', name:'爆破专家',   hp:95,  dmg:28, dropTier:'high', icon:'💣' },
  { id:'E09', name:'随队医疗兵', hp:85,  dmg:10, dropTier:'high', icon:'⛑️' },
  { id:'E10', name:'精英指挥官', hp:130, dmg:25, dropTier:'high', icon:'🎖️' }
];
const BOSS = {
  id:'BOSS', name:'“棍母”镇长', hp:500, dmg:40, dropTier:'boss', icon:'👺',
  specialDrop: { id:'L-SP1', name:'镇长的金印章', level:6, price:520000, icon:'🔱', cls:'lv6' }
};
const CONTAINERS = [
  { id:'C01', name:'军用保险箱', tier:'low',  icon:'🗄️' },
  { id:'C02', name:'加密集装箱', tier:'low',  icon:'📦' },
  { id:'C03', name:'医疗空投',   tier:'low',  icon:'🚁' },
  { id:'C04', name:'武器箱',     tier:'low',  icon:'🔫' },
  { id:'C05', name:'电子保险箱', tier:'low',  icon:'💻' },
  { id:'C06', name:'军用背包',   tier:'mid',  icon:'🎒' },
  { id:'C07', name:'弹药箱',     tier:'mid',  icon:'📦' },
  { id:'C08', name:'工具箱',     tier:'mid',  icon:'🧰' },
  { id:'C09', name:'旅行箱',     tier:'mid',  icon:'🧳' },
  { id:'C10', name:'抽屉',       tier:'mid',  icon:'🗃️' },
  { id:'C11', name:'普通补给箱', tier:'high', icon:'📮' },
  { id:'C12', name:'散落物资点', tier:'high', icon:'🧷' },
  { id:'C13', name:'衣柜',       tier:'high', icon:'🚪' },
  { id:'C14', name:'废弃车辆',   tier:'high', icon:'🚗' }
];
const DROP_RATE = {
  low:  { 1:0.05, 2:0.10, 3:0.20, 4:0.35, 5:0.20, 6:0.08, 7:0.02 },
  mid:  { 1:0.15, 2:0.25, 3:0.30, 4:0.20, 5:0.08, 6:0.02, 7:0.00 },
  high: { 1:0.40, 2:0.35, 3:0.20, 4:0.05, 5:0.00, 6:0.00, 7:0.00 },
  boss: { 1:0.00, 2:0.05, 3:0.10, 4:0.25, 5:0.35, 6:0.20, 7:0.05 }
};
const MAPS = {
  town:     { id:'town',     name:'棍母小镇', desc:'废弃矿区旁的居民点',     lootMul:1.0 },
  mine:     { id:'mine',     name:'废弃矿洞', desc:'塌方频发，矿脉里全是宝', lootMul:1.4 },
  facility: { id:'facility', name:'旧军事设施', desc:'危险最高，机密出没',   lootMul:1.9 }
};/* ================= 状态层 ================= */
const SAVE_KEY = 'gunmu_town_save_v1';
let G = null;
function newGame(){ return {
  money:500000, warehouse:[],
  equipment:{ weapon:null, melee:null, armor:null, helmet:null, meds:[] },
  stats:{ raids:0, extracts:0, deaths:0, kills:0 },
  quest:{ id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离',
          target:1, progress:0, reward:20000, done:false },
  unlockedMaps:['town']
};}
function save(){ try{ localStorage.setItem(SAVE_KEY, JSON.stringify(G)); }catch(e){} }
function load(){
  const raw = localStorage.getItem(SAVE_KEY);
  if (raw){ try{ G = JSON.parse(raw); }catch(e){ G = newGame(); } } else G = newGame();
  if (!G.equipment) G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[] };
  if (G.equipment.melee === undefined) G.equipment.melee = null;
  if (!G.equipment.meds) G.equipment.meds = [];
  if (!G.stats) G.stats = { raids:0, extracts:0, deaths:0, kills:0 };
  if (!G.quest) G.quest = { id:'q1', name:'首次撤离', desc:'完成 1 次成功撤离',
    target:1, progress:0, reward:20000, done:false };
  if (!G.unlockedMaps) G.unlockedMaps = ['town'];
}
const $  = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const fmt = n => n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const rand = (a,b) => Math.floor(Math.random()*(b-a+1))+a;
const randPick = a => a[Math.floor(Math.random()*a.length)];
const clone = o => JSON.parse(JSON.stringify(o));
function rollLevel(tier){
  const t = DROP_RATE[tier]; const r = Math.random(); let acc = 0;
  for (let lv = 1; lv <= 7; lv++){ acc += t[lv]; if (r < acc) return lv; }
  return 1;
}
function rollLoot(tier){
  const lv = rollLevel(tier);
  const pool = ALL_LOOT.filter(x => x.level === lv);
  return clone(randPick(pool));
}
function addToWarehouse(item){
  if (!item) return;
  if (!item.uid) item.uid = 'U' + Date.now() + Math.random().toString(36).slice(2,6);
  G.warehouse.push(item);
}
function removeFromWarehouse(uid){
  const i = G.warehouse.findIndex(x => x.uid === uid);
  if (i >= 0) G.warehouse.splice(i, 1);
}

/* ================= 界面 ================= */
function go(name){
  $$('.screen').forEach(s => s.classList.add('hidden'));
  const el = $('#scr-' + name); if (el) el.classList.remove('hidden');
  if (name === 'warehouse') renderWarehouse();
  if (name === 'market')    renderMarket('buy-weapon');
  if (name === 'loadout')   renderLoadout();
  if (name === 'map')       renderMap();
  if (name === 'quest')     renderQuest();
}
function renderTopbar(){
  $('#money').textContent = fmt(G.money);
  $('#wh-count').textContent = G.warehouse.length;
}
function renderWarehouse(){
  renderTopbar();
  const grid = $('#warehouse-grid'); grid.innerHTML = '';
  if (G.warehouse.length === 0){
    grid.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">仓库空空如也。</p>';
    return;
  }
  [...G.warehouse].sort((a,b)=>(b.level||0)-(a.level||0)).forEach(item => {
    const card = document.createElement('div');
    card.className = 'item ' + (item.cls || 'lv1');
    card.innerHTML = `<span class="lvl">${item.level?'Lv'+item.level:''}</span>
      <span class="emoji">${item.icon||'❔'}</span>
      <span class="price">${fmt(item.price||0)}</span>`;
    card.onclick = () => showItemDetail(item);
    grid.appendChild(card);
  });
}
function showItemDetail(item){
  const panel = $('#item-detail');
  panel.classList.remove('hidden');
  panel.innerHTML = `<h3>${item.name}</h3>
    <p>等级：${item.level||'—'}</p>
    <p>估价：${fmt(item.price)}</p>
    <p>出售可得：${fmt(Math.floor(item.price*0.8))}</p>
    <button id="btn-sell-one">出售</button>
    <button id="btn-close-detail" style="background:#444;color:#d8d4c4;margin-top:4px">关闭</button>`;
  $('#btn-sell-one').onclick = () => {
    G.money += Math.floor(item.price*0.8);
    removeFromWarehouse(item.uid);
    save(); panel.classList.add('hidden'); renderWarehouse();
  };
  $('#btn-close-detail').onclick = () => panel.classList.add('hidden');
}
function renderMarket(tab){
  renderTopbar();
  $$('.tabs button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  const body = $('#market-body'); body.innerHTML = '';
  if (tab === 'buy-weapon'){
    WEAPONS.forEach(w => body.appendChild(marketCard({
      icon:'🔫', name:w.name, price:w.price,
      sub:`伤害${w.dmg} 射速${w.rate} 弹匣${w.mag}`,
      onBuy:() => buyEquip('weapon', w) })));
  } else if (tab === 'buy-melee'){
    MELEES.forEach(m => body.appendChild(marketCard({
      icon:'🔪', name:m.name, price:m.price,
      sub:`伤害${m.dmg} 速度${m.rate} 范围${m.range}`,
      onBuy:() => buyEquip('melee', m) })));
  } else if (tab === 'buy-armor'){
    ARMORS.forEach(a => body.appendChild(marketCard({
      icon:'🛡️', name:a.name, price:a.price,
      sub:`${a.tier}级甲 耐久${a.dur} 减伤${Math.round(a.red*100)}%`,
      onBuy:() => buyEquip('armor', a) })));
    HELMETS.forEach(h => body.appendChild(marketCard({
      icon:'⛑️', name:h.name, price:h.price,
      sub:`${h.tier}级盔 耐久${h.dur} 减伤${Math.round(h.red*100)}%`,
      onBuy:() => buyEquip('helmet', h) })));
  } else if (tab === 'buy-med'){
    MEDS.forEach(m => body.appendChild(marketCard({
      icon:m.icon, name:m.name, price:m.price,
      sub:`恢复${Math.round(m.heal*100)}%`,
      onBuy:() => buyMed(m) })));
  } else if (tab === 'sell'){
    if (G.warehouse.length === 0){
      body.innerHTML = '<p style="grid-column:1/-1;color:#666;text-align:center;padding:40px">无可卖物品。</p>';
      return;
    }
    [...G.warehouse].sort((a,b)=>(b.level||0)-(a.level||0)).forEach(item => {
      body.appendChild(marketCard({
        icon:item.icon||'❔', name:item.name,
        price:Math.floor((item.price||0)*0.8),
        sub:`Lv${item.level||'—'}`,
        onBuy:() => {
          G.money += Math.floor(item.price*0.8);
          removeFromWarehouse(item.uid); save(); renderMarket('sell');
        }, buyLabel:'出售' }));
    });
  }
}
function marketCard({icon,name,price,sub,onBuy,buyLabel='购买'}){
  const c = document.createElement('div');
  c.className = 'item lv3';
  c.style.cssText = 'aspect-ratio:auto;padding:10px;text-align:left;align-items:flex-start';
  c.innerHTML = `<div style="font-size:24px">${icon}</div>
    <div style="font-size:12px;color:#ffd700;margin:4px 0">${name}</div>
    <div style="font-size:10px;color:#8a8578">${sub||''}</div>
    <div style="font-size:12px;color:#c8742a;margin:6px 0">${fmt(price)}</div>
    <button style="background:#c8742a;color:#0d0f0c;border:none;padding:4px 10px;border-radius:3px;font-size:11px">${buyLabel}</button>`;
  c.querySelector('button').onclick = e => { e.stopPropagation(); onBuy(); };
  return c;
}
function buyEquip(slot, data){
  if (G.money < data.price){ alert('柯恩币不足'); return; }
  G.money -= data.price;
  const item = clone(data); item.kind = slot;
  item.uid = 'U' + Date.now() + Math.random().toString(36).slice(2,6);
  if (slot === 'med'){
    if (G.equipment.meds.length >= 3){ alert('药品已满'); G.money += data.price; return; }
    G.equipment.meds.push(item);
  } else G.equipment[slot] = item;
  save();
  let newTab = 'buy-weapon';
  if (slot === 'melee') newTab = 'buy-melee';
  else if (slot === 'armor' || slot === 'helmet') newTab = 'buy-armor';
  else if (slot === 'med') newTab = 'buy-med';
  renderMarket(newTab);
  renderTopbar();
}
function buyMed(m){
  if (G.money < m.price){ alert('柯恩币不足'); return; }
  if (G.equipment.meds.length >= 3){ alert('药品已满'); return; }
  G.money -= m.price;
  const item = clone(m); item.kind = 'med';
  item.uid = 'U' + Date.now() + Math.random().toString(36).slice(2,6);
  G.equipment.meds.push(item);
  save(); renderMarket('buy-med'); renderTopbar();
}
function renderLoadout(){
  renderTopbar();
  const eq = G.equipment;
  setSlot('#slot-weapon', eq.weapon);
  setSlot('#slot-melee', eq.melee);
  setSlot('#slot-armor', eq.armor);
  setSlot('#slot-helmet', eq.helmet);
  const medSlot = $('#slot-meds');
  medSlot.querySelector('span').textContent = eq.meds.length
    ? eq.meds.map(m=>m.name).join('/') : '—';
  medSlot.classList.toggle('filled', eq.meds.length > 0);
  ['#slot-weapon','#slot-melee','#slot-armor','#slot-helmet'].forEach(sel => {
    const el = $(sel);
    el.onclick = () => {
      const key = sel.replace('#slot-','');
      if (G.equipment[key]){ G.equipment[key] = null; save(); renderLoadout(); }
    };
  });
}
function setSlot(sel, item){
  const el = $(sel);
  el.querySelector('span').textContent = item ? item.name : '—';
  el.classList.toggle('filled', !!item);
}
const DIFFICULTY = {
  normal:   { name:'普通', ec:[5,8],   luck:1.0, boss:false, minValue:0 },
  hard:     { name:'困难', ec:[8,12],  luck:1.5, boss:false, minValue:50000 },
  lockdown: { name:'封锁', ec:[12,15], luck:2.5, boss:true,  minValue:150000 }
};
function equipValue(){
  const e = G.equipment; let v = 0;
  if (e.weapon) v += e.weapon.price||0;
  if (e.melee)  v += e.melee.price||0;
  if (e.armor)  v += e.armor.price||0;
  if (e.helmet) v += e.helmet.price||0;
  e.meds.forEach(m => v += m.price||0);
  return v;
}
function renderMap(){
  renderTopbar();
  const body = $('#scr-map');
  const mapList = Object.values(MAPS).map(m => {
    const locked = !G.unlockedMaps.includes(m.id);
    return `<div class="map-card" style="margin-bottom:10px;${locked?'opacity:.4':''}">
      <div class="map-name">${m.name}</div>
      <div class="map-desc">${m.desc}${locked?' · 未解锁':''}</div>
      ${locked ? '' : `<div class="difficulty-row">
        <button data-map="${m.id}" data-diff="normal">普通 ×1.0</button>
        <button data-map="${m.id}" data-diff="hard">困难 ×1.5</button>
        <button data-map="${m.id}" data-diff="lockdown">封锁 ×2.5</button>
      </div>`}</div>`;
  }).join('');
  body.innerHTML = `<h2>选择地图</h2>${mapList}
    <div style="margin-top:16px;font-size:12px;color:#8a8578">
      <p>携带价值：${fmt(equipValue())}</p></div>`;
  body.querySelectorAll('.difficulty-row button').forEach(btn => {
    btn.onclick = () => startRaid(btn.dataset.map, btn.dataset.diff);
  });
}
function renderQuest(){
  renderTopbar();
  const body = $('#scr-quest'); const q = G.quest;
  body.innerHTML = `<h2>任务</h2>
    <div class="map-card">
      <div class="map-name" style="font-size:18px">${q.name}</div>
      <div class="map-desc">${q.desc}</div>
      <p style="font-size:13px;color:#c8742a;margin:10px 0">进度：${q.progress}/${q.target}</p>
      <p style="font-size:12px;color:#8a8578">奖励：${fmt(q.reward)}</p>
      ${q.done ? '<p style="color:#4caf50;margin-top:10px">✅ 已完成</p>' : ''}
    </div>`;
}
function updateQuest(type){
  const q = G.quest; if (q.done) return;
  if (q.id === 'q1' && type === 'extract') q.progress = Math.min(q.target, q.progress+1);
  if (q.progress >= q.target){
    q.done = true; G.money += q.reward;
    alert(`任务完成：${q.name}\n奖励 ${fmt(q.reward)}`);
    if (!G.unlockedMaps.includes('mine')) G.unlockedMaps.push('mine');
  }
}/* ================= 局内 ================= */
let raid = null, raidTimer = null;
let playerPos = { x:1500, y:1500 };
let moveDir = { x:0, y:0 };
let aimDir = { x:1, y:0 };
let firing = false, fireInterval = null;
let gameLoopTimer = null, bulletsTimer = null;

function startRaid(mapId, diffKey){
  const diff = DIFFICULTY[diffKey], map = MAPS[mapId];
  // 跑刀模式：没枪自动给生锈小刀
  if (!G.equipment.weapon && !G.equipment.melee){
    G.equipment.melee = clone(MELEES[0]);
    G.equipment.melee.uid = 'U' + Date.now();
    G.equipment.melee.kind = 'melee';
    save();
  }
  if (equipValue() < diff.minValue){
    alert(`${diff.name}难度需装备价值≥${fmt(diff.minValue)}`);
    return;
  }
  const field = $('#raid-field'); field.innerHTML = '';
  playerPos = { x:1500, y:1500 };
  moveDir = { x:0, y:0 }; aimDir = { x:1, y:0 };

  raid = {
    mapId, diff: diffKey, luck: diff.luck * map.lootMul,
    hp:100, maxHp:100, timeLeft:300,
    lootValue:0, backpack:[], enemies:[], boxes:[], extract:null,
    armor: G.equipment.armor ? clone(G.equipment.armor) : null,
    helmet: G.equipment.helmet ? clone(G.equipment.helmet) : null,
    log:[], over:false, kills:0,
    ammo: G.equipment.weapon ? G.equipment.weapon.mag : 0,
    magSize: G.equipment.weapon ? G.equipment.weapon.mag : 0,
    weapon: G.equipment.weapon ? clone(G.equipment.weapon) : null,
    melee: G.equipment.melee ? clone(G.equipment.melee) : clone(MELEES[0]),
    bullets: [],
    isKnifeRun: !G.equipment.weapon
  };

  const pEl = document.createElement('div');
  pEl.id = 'player'; pEl.textContent = '🧍';
  pEl.style.left = '1500px'; pEl.style.top = '1500px';
  field.appendChild(pEl);

  for (let i = 0; i < 40; i++){
    const t = randPick(['house','rock','tree','']);
    if (!t) continue;
    const d = document.createElement('div');
    d.className = 'deco ' + t;
    d.textContent = t==='house'?'🏚️':t==='rock'?'🪨':'🌲';
    d.style.left = rand(100,2900) + 'px';
    d.style.top  = rand(100,2900) + 'px';
    field.appendChild(d);
  }

  const count = rand(diff.ec[0], diff.ec[1]);
  for (let i = 0; i < count; i++) spawnEnemy(randPick(ENEMIES), field);
  if (diff.boss) spawnEnemy(BOSS, field);

  const boxCount = Math.round(16 * map.lootMul);
  for (let i = 0; i < boxCount; i++) spawnBox(randPick(CONTAINERS), field);

  spawnExtract(field);

  go('raid');
  bindRaidControls();
  updateCamera();
  renderRaidHUD();
  updateMedSlots();

  // 切换开火/挥刀按钮
  const fb = $('#btn-fire'), mb = $('#btn-melee');
  if (raid.weapon){ fb.style.display = 'flex'; mb.style.display = 'none'; }
  else { fb.style.display = 'none'; mb.style.display = 'flex'; }

  clearInterval(raidTimer);
  raidTimer = setInterval(() => {
    if (!raid || raid.over) return;
    raid.timeLeft--;
    if (raid.timeLeft <= 0){ endRaid(false); return; }
    renderRaidHUD();
    drawMinimap();
  }, 1000);

  clearInterval(gameLoopTimer);
  gameLoopTimer = setInterval(gameLoop, 50);
  clearInterval(bulletsTimer);
  bulletsTimer = setInterval(updateBullets, 30);
}

function spawnEnemy(tpl, field){
  const el = document.createElement('div');
  el.className = 'enemy' + (tpl.id === 'BOSS' ? ' boss' : '');
  const x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  el.innerHTML = `<div class="hp-mini"><div style="width:100%"></div></div>` + tpl.icon;
  const obj = { el, tpl: clone(tpl), hp: tpl.hp, x, y, alive:true, cd:0 };
  raid.enemies.push(obj);
  field.appendChild(el);
}
function spawnBox(tpl, field){
  const el = document.createElement('div');
  el.className = 'loot-box'; el.textContent = tpl.icon;
  const x = rand(200,2800), y = rand(200,2800);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  const obj = { el, tpl, x, y, searched:false };
  el.onclick = e => { e.stopPropagation(); searchBox(obj); };
  raid.boxes.push(obj); field.appendChild(el);
}
function spawnExtract(field){
  const el = document.createElement('div');
  el.className = 'extract-zone'; el.textContent = '撤离';
  const x = rand(300,2700), y = rand(300,2700);
  el.style.left = x + 'px'; el.style.top = y + 'px';
  const obj = { el, x, y };
  el.onclick = e => { e.stopPropagation(); tryExtract(); };
  raid.extract = obj; field.appendChild(el);
}

function bindRaidControls(){
  // 左摇杆
  const jz = $('#joystick-zone'), js = $('#joystick-stick'), jb = $('#joystick-base');
  let jActive = false;
  const jStart = e => { e.preventDefault(); jActive = true; };
  const jMove = e => {
    if (!jActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    const r = jb.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = t.clientX - cx, dy = t.clientY - cy;
    const len = Math.hypot(dx, dy), max = r.width/2 - 20;
    if (len > max){ dx = dx/len*max; dy = dy/len*max; }
    js.style.transform = `translate(${dx}px,${dy}px)`;
    if (Math.hypot(dx, dy) > 10) moveDir = { x: dx/max, y: dy/max };
    else moveDir = { x:0, y:0 };
  };
  const jEnd = () => { jActive = false; moveDir = { x:0, y:0 }; js.style.transform = ''; };
  jz.addEventListener('touchstart', jStart, { passive:false });
  jz.addEventListener('touchmove', jMove, { passive:false });
  jz.addEventListener('touchend', jEnd);
  jz.addEventListener('mousedown', jStart);
  document.addEventListener('mousemove', e => { if (jActive) jMove(e); });
  document.addEventListener('mouseup', () => { if (jActive) jEnd(); });

  // 右摇杆：瞄准
  const az = $('#aim-zone'), as = $('#aim-stick'), ab = $('#aim-base');
  let aActive = false;
  const aStart = e => { e.preventDefault(); aActive = true; };
  const aMove = e => {
    if (!aActive) return;
    e.preventDefault();
    const t = e.touches ? e.touches[0] : e;
    const r = ab.getBoundingClientRect();
    const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = t.clientX - cx, dy = t.clientY - cy;
    const len = Math.hypot(dx, dy), max = r.width/2 - 18;
    if (len > max){ dx = dx/len*max; dy = dy/len*max; }
    as.style.transform = `translate(${dx}px,${dy}px)`;
    const nlen = Math.hypot(dx, dy);
    if (nlen > 8){ aimDir = { x: dx/nlen, y: dy/nlen }; updateCrosshair(); }
  };
  const aEnd = () => { aActive = false; as.style.transform = ''; };
  az.addEventListener('touchstart', aStart, { passive:false });
  az.addEventListener('touchmove', aMove, { passive:false });
  az.addEventListener('touchend', aEnd);
  az.addEventListener('mousedown', aStart);
  document.addEventListener('mousemove', e => { if (aActive) aMove(e); });
  document.addEventListener('mouseup', () => { if (aActive) aEnd(); });

  // 开火
  const fb = $('#btn-fire');
  fb.addEventListener('touchstart', e => { e.preventDefault(); startFire(); });
  fb.addEventListener('touchend', e => { e.preventDefault(); stopFire(); });
  fb.addEventListener('mousedown', e => { e.preventDefault(); startFire(); });
  fb.addEventListener('mouseup', stopFire);

  // 近战
  const mb = $('#btn-melee');
  mb.addEventListener('touchstart', e => { e.preventDefault(); meleeAttack(); });
  mb.addEventListener('mousedown', e => { e.preventDefault(); meleeAttack(); });

  $('#btn-reload').onclick = reload;
  $('#btn-extract').onclick = tryExtract;
  $$('.med-slot').forEach((el, i) => { el.onclick = () => useMed(i); });
  $('#btn-back').onclick = () => go('warehouse');
}

function updateCrosshair(){
  const ch = $('#crosshair');
  if (!ch) return;
  const dist = 80;
  const vw = window.innerWidth / 2, vh = window.innerHeight / 2;
  ch.style.left = (vw + aimDir.x * dist) + 'px';
  ch.style.top  = (vh + aimDir.y * dist) + 'px';
}

function updateCamera(){
  if (!raid) return;
  const cam = $('#raid-camera');
  const cx = playerPos.x - window.innerWidth/2;
  const cy = playerPos.y - window.innerHeight/2;
  cam.style.transform = `translate(${-cx}px,${-cy}px)`;
}

function startFire(){
  if (!raid || raid.over || !raid.weapon) return;
  firing = true;
  $('#btn-fire').classList.add('firing');
  const interval = Math.max(60, 60000 / raid.weapon.rate);
  doFire();
  fireInterval = setInterval(doFire, interval);
}
function stopFire(){
  firing = false;
  $('#btn-fire').classList.remove('firing');
  clearInterval(fireInterval);
}

function doFire(){
  if (!raid || raid.over || !firing) return;
  if (!raid.weapon) return;
  if (raid.ammo <= 0){ reload(); return; }
  raid.ammo--;
  const bx = playerPos.x + aimDir.x * 30;
  const by = playerPos.y + aimDir.y * 30;
  const el = document.createElement('div');
  el.className = 'bullet';
  el.style.left = bx + 'px'; el.style.top = by + 'px';
  const angle = Math.atan2(aimDir.y, aimDir.x) * 180 / Math.PI;
  el.style.transform = `translate(-50%,-50%) rotate(${angle}deg)`;
  $('#raid-field').appendChild(el);
  const speed = raid.weapon.bulletSpeed;
  raid.bullets.push({
    el, x:bx, y:by,
    vx: aimDir.x * speed, vy: aimDir.y * speed,
    dmg: raid.weapon.dmg,
    range: raid.weapon.range, dist: 0
  });
  const m = document.createElement('div');
  m.className = 'muzzle';
  m.style.left = bx + 'px'; m.style.top = by + 'px';
  $('#raid-field').appendChild(m);
  setTimeout(() => m.remove(), 100);
  renderRaidHUD();
}

function meleeAttack(){
  if (!raid || raid.over) return;
  const m = raid.melee || MELEES[0];
  const now = Date.now();
  if (raid._lastMelee && now - raid._lastMelee < 60000/m.rate) return;
  raid._lastMelee = now;
  const checkRange = m.range + 20;
  const targets = raid.enemies.filter(e =>
    e.alive && Math.hypot(e.x - playerPos.x, e.y - playerPos.y) <= checkRange
  );
  if (targets.length === 0){ raid.log.push('挥空了'); renderRaidHUD(); return; }
  const target = targets[0];
  hitEnemy(target, m.dmg);
  raid.log.push(`⚔️ ${m.name} 命中 ${target.tpl.name}`);
  renderRaidHUD();
  const slash = document.createElement('div');
  slash.className = 'slash';
  slash.style.left = target.x + 'px';
  slash.style.top  = target.y + 'px';
  $('#raid-field').appendChild(slash);
  setTimeout(() => slash.remove(), 250);
}

function updateBullets(){
  if (!raid || raid.over) return;
  for (let i = raid.bullets.length - 1; i >= 0; i--){
    const b = raid.bullets[i];
    b.x += b.vx; b.y += b.vy;
    b.dist += Math.hypot(b.vx, b.vy);
    b.el.style.left = b.x + 'px';
    b.el.style.top  = b.y + 'px';
    if (b.dist > b.range){ b.el.remove(); raid.bullets.splice(i, 1); continue; }
    let hit = false;
    for (const e of raid.enemies){
      if (!e.alive) continue;
      if (Math.hypot(e.x - b.x, e.y - b.y) < 25){
        hitEnemy(e, b.dmg);
        b.el.remove(); raid.bullets.splice(i, 1); hit = true; break;
      }
    }
  }
}

function hitEnemy(enemy, dmg){
  enemy.hp -= dmg;
  enemy.el.classList.add('hurt');
  setTimeout(() => enemy.el.classList.remove('hurt'), 200);
  const hpBar = enemy.el.querySelector('.hp-mini > div');
  if (hpBar) hpBar.style.width = Math.max(0, enemy.hp/enemy.tpl.hp*100) + '%';
  const bl = document.createElement('div');
  bl.className = 'blood';
  bl.style.left = enemy.x + 'px'; bl.style.top = enemy.y + 'px';
  $('#raid-field').appendChild(bl);
  setTimeout(() => bl.remove(), 400);
  if (enemy.hp <= 0){
    enemy.alive = false;
    enemy.el.classList.add('dead');
    raid.kills++; G.stats.kills++;
    raid.log.push(`击杀 ${enemy.tpl.name}`);
    const drop = rollLoot(enemy.tpl.dropTier);
    if (drop){
      raid.backpack.push(drop);
      raid.lootValue += drop.price;
      raid.log.push(`拾取 ${drop.name}（${fmt(drop.price)}）`);
    }
    if (enemy.tpl.id === 'BOSS' && Math.random() < 0.6){
      const sp = clone(BOSS.specialDrop);
      sp.uid = 'U' + Date.now();
      raid.backpack.push(sp); raid.lootValue += sp.price;
      raid.log.push(`★ 掉落 ${sp.name}`);
    }
    renderRaidHUD();
  }
}

function gameLoop(){
  if (!raid || raid.over) return;
  // 玩家移动
  if (moveDir.x !== 0 || moveDir.y !== 0){
    const speed = raid.isKnifeRun ? 6.5 : 5;
    playerPos.x = Math.max(40, Math.min(2960, playerPos.x + moveDir.x * speed));
    playerPos.y = Math.max(40, Math.min(2960, playerPos.y + moveDir.y * speed));
    const p = $('#player');
    if (p){ p.style.left = playerPos.x + 'px'; p.style.top = playerPos.y + 'px'; }
    updateCamera();
  }
  // 敌人 AI
  const now = Date.now();
  raid.enemies.forEach(e => {
    if (!e.alive) return;
    const dx = playerPos.x - e.x, dy = playerPos.y - e.y;
    const dist = Math.hypot(dx, dy);
    if (dist < 700 && dist > 60){
      const sp = 1.2;
      e.x += (dx/dist) * sp; e.y += (dy/dist) * sp;
      e.el.style.left = e.x + 'px'; e.el.style.top = e.y + 'px';
    }
    if (dist < 500 && now - e.cd > 1500){
      e.cd = now;
      enemyShoot(e);
    }
  });
}

function enemyShoot(e){
  let dmg = e.tpl.dmg;
  let red = 0;
  if (raid.armor && raid.armor.dur > 0){ red += raid.armor.red; raid.armor.dur -= rand(1,3); if (raid.armor.dur < 0) raid.armor.dur = 0; }
  if (raid.helmet && raid.helmet.dur > 0){ red += raid.helmet.red*0.5; raid.helmet.dur -= rand(1,2); if (raid.helmet.dur < 0) raid.helmet.dur = 0; }
  dmg = dmg * (1 - Math.min(red, 0.85));
  raid.hp -= dmg;
  const flash = $('#damage-flash');
  flash.classList.add('on');
  setTimeout(() => flash.classList.remove('on'), 80);
  if (raid.hp <= 0){ raid.hp = 0; endRaid(false); return; }
  renderRaidHUD();
}

function reload(){
  if (!raid || raid.over || !raid.weapon) return;
  raid.ammo = raid.magSize;
  raid.log.push('换弹完成');
  renderRaidHUD();
}

function searchBox(obj){
  if (!obj || obj.searched || !raid || raid.over) return;
  const dist = Math.hypot(obj.x - playerPos.x, obj.y - playerPos.y);
  if (dist > 90){ raid.log.push('太远了，走近点'); renderRaidHUD(); return; }
  obj.searched = true;
  obj.el.classList.add('searched');
  const drop = rollLoot(obj.tpl.tier);
  if (drop){
    raid.backpack.push(drop);
    raid.lootValue += drop.price;
    raid.log.push(`获得 ${drop.name}（${fmt(drop.price)}）`);
  } else raid.log.push('空空如也');
  renderRaidHUD();
}

function useMed(i){
  if (!raid || raid.over) return;
  const item = G.equipment.meds[i];
  if (!item) return;
  const heal = item.heal * raid.maxHp;
  raid.hp = Math.min(raid.maxHp, raid.hp + heal);
  G.equipment.meds.splice(i, 1);
  save(); updateMedSlots(); renderRaidHUD();
  raid.log.push(`使用 ${item.name}，恢复 ${Math.round(heal)}`);
  renderRaidHUD();
}

function updateMedSlots(){
  $$('.med-slot').forEach((el, i) => {
    const med = G.equipment.meds[i];
    el.textContent = med ? med.icon : '➕';
    el.classList.toggle('filled', !!med);
  });
}

function tryExtract(){
  if (!raid || raid.over) return;
  const d = Math.hypot(raid.extract.x - playerPos.x, raid.extract.y - playerPos.y);
  if (d > 100){ raid.log.push('离撤离点太远'); renderRaidHUD(); return; }
  const nearEnemy = raid.enemies.some(e => e.alive && Math.random() < 0.3 &&
    Math.hypot(e.x - playerPos.x, e.y - playerPos.y) < 400);
  if (nearEnemy){ raid.log.push('附近有敌人，无法撤离！'); renderRaidHUD(); return; }
  endRaid(true);
}

function endRaid(success){
  if (raid.over) return;
  raid.over = true;
  clearInterval(raidTimer);
  clearInterval(gameLoopTimer);
  clearInterval(bulletsTimer);
  clearInterval(fireInterval);
  G.stats.raids++;
  if (success){
    G.stats.extracts++;
    raid.backpack.forEach(addToWarehouse);
    updateQuest('extract');
  } else {
    G.stats.deaths++;
    G.equipment = { weapon:null, melee:null, armor:null, helmet:null, meds:[] };
  }
  save();
  showResult(success);
}

function showResult(success){
  const overlay = $('#result-overlay');
  overlay.classList.remove('hidden');
  $('#result-title').textContent = success ? '撤离成功' : '任务失败 · 装备丢失';
  const body = $('#result-body');
  if (success){
    body.innerHTML = `<p>带回 ${raid.backpack.length} 件物资，总价值 ${fmt(raid.lootValue)} 柯恩币。</p>
      <p>击杀：${raid.kills}</p>`;
  } else {
    body.innerHTML = `<p>你在 ${MAPS[raid.mapId].name} 倒下了。</p>
      <p>装备全部丢失，仓库物资安全。</p>`;
  }
  renderTopbar();
}

function renderRaidHUD(){
  if (!raid) return;
  $('#raid-loot').textContent = fmt(raid.lootValue);
  $('#raid-kills').textContent = raid.kills;
  const m = String(Math.floor(raid.timeLeft/60)).padStart(2,'0');
  const s = String(raid.timeLeft % 60).padStart(2,'0');
  if (raid.weapon){
    $('#raid-timer').textContent = `${m}:${s}  🔫 ${raid.ammo}/${raid.magSize}`;
  } else {
    $('#raid-timer').textContent = `${m}:${s}  🔪 ${raid.melee.name}`;
  }
  const hpPct = raid.hp / raid.maxHp * 100;
  const fill = $('#hp-fill');
  fill.style.width = hpPct + '%';
  fill.classList.toggle('low', hpPct < 30);
  $('#hp-text').textContent = `${Math.round(raid.hp)} / ${raid.maxHp}`;
  const log = $('#raid-log');
  log.innerHTML = raid.log.slice(-5).map(l => '· ' + l).join('<br>');
}

function drawMinimap(){
  const c = $('#minimap'); if (!c) return;
  const ctx = c.getContext('2d');
  const W = c.width, H = c.height;
  ctx.fillStyle = 'rgba(13,15,12,0.85)';
  ctx.fillRect(0,0,W,H);
  const scale = W / 3000;
  // 敌人
  raid.enemies.forEach(e => {
    if (!e.alive) return;
    ctx.fillStyle = e.tpl.id === 'BOSS' ? '#ffd700' : '#ff3b3b';
    ctx.beginPath();
    ctx.arc(e.x*scale, e.y*scale, 3, 0, Math.PI*2);
    ctx.fill();
  });
  // 容器
  ctx.fillStyle = '#c8742a';
  raid.boxes.forEach(b => {
    if (b.searched) return;
    ctx.fillRect(b.x*scale-2, b.y*scale-2, 3, 3);
  });
  // 撤离点
  if (raid.extract){
    ctx.fillStyle = '#4caf50';
    ctx.beginPath();
    ctx.arc(raid.extract.x*scale, raid.extract.y*scale, 5, 0, Math.PI*2);
    ctx.fill();
  }
  // 玩家
  ctx.fillStyle = '#ffd700';
  ctx.beginPath();
  ctx.arc(playerPos.x*scale, playerPos.y*scale, 4, 0, Math.PI*2);
  ctx.fill();
}

/* ================= 启动 ================= */
function bindEvents(){
  $$('#bottomnav button').forEach(btn => {
    btn.onclick = () => go(btn.dataset.go);
  });
  $$('.tabs button').forEach(btn => {
    btn.onclick = () => renderMarket(btn.dataset.tab);
  });
  window.addEventListener('resize', checkOrientation);
  window.addEventListener('orientationchange', checkOrientation);
}
function checkOrientation(){
  const tip = $('#rotate-tip');
  if (!tip) return;
  tip.style.display = (window.innerHeight > window.innerWidth) ? 'flex' : 'none';
}
function boot(){
  load();
  bindEvents();
  checkOrientation();
  renderTopbar();
  go('warehouse');
}
window.addEventListener('DOMContentLoaded', boot);
if (document.readyState !== 'loading') boot();