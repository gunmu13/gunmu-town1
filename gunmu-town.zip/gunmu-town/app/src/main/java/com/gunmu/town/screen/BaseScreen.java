package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

public class BaseScreen {
    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    public BaseScreen(MainActivity a){ act=a; ctx=a; s=a.state; }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), "据点",
                "💰 " + UI.fmt(s.money)));
        ScrollView sc = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12));
        for (GameData.BaseUpgrade u : GameData.BASE_UPGRADES) list.addView(buildCard(u));
        sc.addView(list);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private View buildCard(final GameData.BaseUpgrade u) {
        int lv = s.baseLevel(u.id);
        boolean max = lv >= u.maxLevel;
        int cost = max ? 0 : s.upgradeCost(u.id);

        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14));
        card.setBackground(UI.round(UI.PANEL,
                max ? 0xFF4CAF50 : UI.BORDER, UI.dp(ctx,2), UI.dp(ctx,6)));

        card.addView(UI.tv(ctx, u.name + "  Lv." + lv + "/" + u.maxLevel, 16, UI.GOLD));
        card.addView(UI.tv(ctx, u.desc, 12, UI.GRAY));

        if (max) {
            card.addView(UI.tv(ctx, "✅ 已满级", 12, 0xFF4CAF50));
        } else {
            card.addView(UI.tv(ctx, "升级价格：" + UI.fmt(cost) + " 币", 12, UI.ORANGE));
            Button b = UI.primaryBtn(ctx, "升级");
            b.setOnClickListener(v -> {
                if (s.money < cost) {
                    new AlertDialog.Builder(ctx).setMessage("柯恩币不足")
                            .setPositiveButton("好", null).show();
                    return;
                }
                s.money -= cost;
                s.baseLevels.put(u.id, s.baseLevel(u.id) + 1);
                Save.save(ctx, s);
                act.showScreen(getView());
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = UI.dp(ctx,8);
            b.setLayoutParams(lp);
            card.addView(b);
        }

        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.bottomMargin = UI.dp(ctx,10);
        card.setLayoutParams(clp);
        return card;
    }
}