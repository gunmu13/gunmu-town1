package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

public class AuctionScreen {
    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    public AuctionScreen(MainActivity a){ act=a; ctx=a; s=a.state; }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), "交易行",
                "💰 " + UI.fmt(s.money)));

        ScrollView sc = new ScrollView(ctx);
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12));

        // 我的挂单
        content.addView(UI.tv(ctx, "我的挂单（按 90% 售价挂出，有概率被抢购）", 13, UI.ORANGE));
        boolean has = false;
        for (int i = 0; i < s.auctions.size(); i++) {
            final GameState.Auction a = s.auctions.get(i);
            if (a.sold) continue;
            has = true;
            content.addView(buildAuctionRow(a, i));
        }
        if (!has) {
            TextView empty = UI.tv(ctx, "暂无挂单", 12, UI.GRAY);
            empty.setPadding(0, UI.dp(ctx,6), 0, UI.dp(ctx,12));
            content.addView(empty);
        }

        // 仓库可挂单
        content.addView(UI.tv(ctx, "仓库中的变卖物（点击挂单）", 13, UI.ORANGE));
        for (final GameState.Item it : new java.util.ArrayList<>(s.warehouse)) {
            if (!"loot".equals(it.type)) continue;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(UI.dp(ctx,10), UI.dp(ctx,8), UI.dp(ctx,10), UI.dp(ctx,8));
            row.setBackground(UI.round(UI.PANEL, UI.BORDER, UI.dp(ctx,1), UI.dp(ctx,4)));
            row.addView(UI.tv(ctx, it.icon + " " + it.name, 12, UI.TEXT));
            TextView price = UI.tv(ctx, "  " + UI.fmt(it.price) + " 币", 11, UI.GOLD);
            price.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            row.addView(price);
            Button sell = UI.smallBtn(ctx, "挂单 " + UI.fmt((int)(it.price * 0.9)));
            sell.setOnClickListener(v -> {
                GameState.Auction a = new GameState.Auction();
                a.itemUid = it.uid;
                a.itemName = it.name;
                a.itemIcon = it.icon;
                a.itemCls = it.cls;
                a.itemLevel = it.level;
                a.itemPrice = it.price;
                a.askPrice = (int)(it.price * 0.9);
                a.listedAt = System.currentTimeMillis();
                a.sold = false;
                s.auctions.add(a);
                s.removeFromWarehouse(it.uid);
                Save.save(ctx, s);
                act.showScreen(getView());
            });
            row.addView(sell);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.bottomMargin = UI.dp(ctx,4);
            row.setLayoutParams(rlp);
            content.addView(row);
        }

        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private View buildAuctionRow(final GameState.Auction a, final int idx) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(UI.dp(ctx,10), UI.dp(ctx,8), UI.dp(ctx,10), UI.dp(ctx,8));
        row.setBackground(UI.round(UI.PANEL, 0xFFFFD700, UI.dp(ctx,1), UI.dp(ctx,4)));
        row.addView(UI.tv(ctx, (a.itemIcon != null ? a.itemIcon : "📦") + " " + a.itemName,
                12, UI.TEXT));
        TextView price = UI.tv(ctx, "  " + UI.fmt(a.askPrice) + " 币", 11, UI.GOLD);
        price.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(price);
        Button undo = UI.smallBtn(ctx, "撤回");
        undo.setOnClickListener(v -> {
            GameState.Item it = new GameState.Item();
            it.uid = a.itemUid;
            it.type = "loot";
            it.name = a.itemName;
            it.icon = a.itemIcon;
            it.cls = a.itemCls;
            it.level = a.itemLevel;
            it.price = a.itemPrice;
            s.warehouse.add(it);
            s.auctions.remove(idx);
            Save.save(ctx, s);
            act.showScreen(getView());
        });
        row.addView(undo);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.bottomMargin = UI.dp(ctx,4);
        row.setLayoutParams(rlp);
        return row;
    }
}