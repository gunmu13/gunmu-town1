package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

/** 市场 */
public class MarketScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private String tab = "buy-weapon";

    public MarketScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        root.addView(UI.topbar(ctx, () -> act.showLobby(), "市场",
                "💰 " + UI.fmt(s.money)));

        // 分类标签
        ScrollView tabScroll = new ScrollView(ctx);
        tabScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tabRow = new LinearLayout(ctx);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8));
        addTab(tabRow, "枪械", "buy-weapon");
        addTab(tabRow, "刀具", "buy-melee");
        addTab(tabRow, "护甲", "buy-armor");
        addTab(tabRow, "药品", "buy-med");
        addTab(tabRow, "弹药", "buy-ammo");
        addTab(tabRow, "配件", "buy-part");
        addTab(tabRow, "出售", "sell");
        tabScroll.addView(tabRow);
        root.addView(tabScroll);

        // 列表
        ScrollView scroll = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx, 8), 0, UI.dp(ctx, 8), UI.dp(ctx, 8));

        if ("buy-weapon".equals(tab)) {
            for (GameData.Weapon w : GameData.WEAPONS) list.addView(
                    marketRow("🔫", w.name, "伤害 " + w.dmg + " · 射速 " + w.rate
                            + " · 弹匣 " + w.mag, w.price, () -> buyWeapon(w)));
        } else if ("buy-melee".equals(tab)) {
            for (GameData.Melee m : GameData.MELEES) list.addView(
                    marketRow("🔪", m.name, "伤害 " + m.dmg + " · 攻速 " + m.rate,
                            m.price, () -> buyMelee(m)));
        } else if ("buy-armor".equals(tab)) {
            for (GameData.Armor a : GameData.ARMORS) list.addView(
                    marketRow("🛡️", a.name, a.tier + " 级甲 · 耐久 " + a.dur
                            + " · 减伤 " + (int)(a.red*100) + "%", a.price, () -> buyArmor(a, false)));
            for (GameData.Armor h : GameData.HELMETS) list.addView(
                    marketRow("⛑️", h.name, h.tier + " 级盔 · 耐久 " + h.dur
                            + " · 减伤 " + (int)(h.red*100) + "%", h.price, () -> buyArmor(h, true)));
        } else if ("buy-med".equals(tab)) {
            for (GameData.Med m : GameData.MEDS) list.addView(
                    marketRow(m.icon, m.name, "恢复 " + (int)(m.heal*100) + "%",
                            m.price, () -> buyMed(m)));
        } else if ("buy-ammo".equals(tab)) {
            for (GameData.Ammo a : GameData.AMMO_TYPES) list.addView(
                    marketRow(a.icon, a.name + " ×30", "伤害 ×" + a.dmgMul,
                            a.price * 30, () -> buyAmmo(a, 30)));
        } else if ("buy-part".equals(tab)) {
            for (GameData.Part p : GameData.PARTS) list.addView(
                    marketRow("🔧", p.name, p.eff + " · " + p.slot,
                            p.price, () -> buyPart(p)));
        } else if ("sell".equals(tab)) {
            boolean any = false;
            for (GameState.Item it : s.warehouse) {
                if (!"loot".equals(it.type)) continue;
                any = true;
                final GameState.Item item = it;
                list.addView(marketRow(it.icon, it.name,
                        "Lv" + it.level + " · 售价 " + UI.fmt((int)(it.price*0.8)),
                        (int)(it.price*0.8), () -> sellLoot(item)));
            }
            if (!any) {
                TextView e = UI.tv(ctx, "没有可卖出的变卖物", 14, UI.GRAY);
                e.setGravity(Gravity.CENTER);
                e.setPadding(0, UI.dp(ctx, 60), 0, 0);
                list.addView(e);
            }
        }

        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private void addTab(LinearLayout parent, String label, String key) {
        Button b = UI.smallBtn(ctx, label);
        boolean active = tab.equals(key);
        b.setBackground(UI.round(active ? UI.ORANGE : UI.PANEL,
                UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 4)));
        b.setTextColor(active ? UI.BG : UI.TEXT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = UI.dp(ctx, 6);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> { tab = key; act.showScreen(getView()); });
        parent.addView(b);
    }

    private LinearLayout marketRow(String icon, String name, String sub, int price, Runnable action) {
        LinearLayout card = UI.card(ctx);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout left = new LinearLayout(ctx);
        left.setOrientation(LinearLayout.VERTICAL);
        left.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));

        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView ico = UI.tv(ctx, icon, 22, UI.TEXT);
        titleRow.addView(ico);
        TextView nm = UI.tv(ctx, "  " + name, 14, UI.GOLD);
        titleRow.addView(nm);
        left.addView(titleRow);

        TextView sb = UI.tv(ctx, sub, 11, UI.GRAY);
        left.addView(sb);

        TextView pr = UI.tv(ctx, "💰 " + UI.fmt(price), 13, UI.ORANGE);
        left.addView(pr);

        card.addView(left);

        Button act = UI.smallBtn(ctx, "购买");
        act.setOnClickListener(v -> action.run());
        card.addView(act);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 6);
        card.setLayoutParams(lp);
        return card;
    }

    private void buyWeapon(GameData.Weapon w) {
        if (s.money < w.price) { alert("柯恩币不足"); return; }
        s.money -= w.price;
        s.addToWarehouse(newItem(w.id, "weapon", w.name, w.price, "🔫", w.dmg, w.rate, w.mag, w.range, w.bs));
        Save.save(ctx, s);
        alert("购买成功：" + w.name);
    }
    private void buyMelee(GameData.Melee m) {
        if (s.money < m.price) { alert("柯恩币不足"); return; }
        s.money -= m.price;
        s.addToWarehouse(newItem(m.id, "melee", m.name, m.price, "🔪", m.dmg, m.rate, 0, m.range, 0));
        Save.save(ctx, s);
        alert("购买成功：" + m.name);
    }
    private void buyArmor(GameData.Armor a, boolean helmet) {
        if (s.money < a.price) { alert("柯恩币不足"); return; }
        s.money -= a.price;
        GameState.Item it = newItem(a.id, helmet ? "helmet" : "armor", a.name, a.price,
                helmet ? "⛑️" : "🛡️", 0, 0, 0, 0, 0);
        it.dur = a.dur; it.red = a.red; it.level = a.tier;
        s.addToWarehouse(it);
        Save.save(ctx, s);
        alert("购买成功：" + a.name);
    }
    private void buyMed(GameData.Med m) {
        if (s.money < m.price) { alert("柯恩币不足"); return; }
        s.money -= m.price;
        GameState.Item it = newItem(m.id, "med", m.name, m.price, m.icon, 0, 0, 0, 0, 0);
        it.heal = m.heal;
        s.addToWarehouse(it);
        Save.save(ctx, s);
        alert("购买成功：" + m.name);
    }
    private void buyAmmo(GameData.Ammo a, int count) {
        int total = a.price * count;
        if (s.money < total) { alert("柯恩币不足"); return; }
        s.money -= total;
        GameState.Item it = newItem(a.id, "ammo", a.name, a.price, a.icon, 0, 0, 0, 0, 0);
        it.ammoId = a.id; it.count = count; it.dmgMul = a.dmgMul;
        s.addToWarehouse(it);
        Save.save(ctx, s);
        alert("购买 " + a.name + " ×" + count);
    }
    private void buyPart(GameData.Part p) {
        if (s.money < p.price) { alert("柯恩币不足"); return; }
        s.money -= p.price;
        GameState.Item it = newItem(p.id, "part", p.name, p.price, "🔧", 0, 0, 0, 0, 0);
        it.slot = p.slot; it.eff = p.eff;
        s.addToWarehouse(it);
        Save.save(ctx, s);
        alert("购买成功：" + p.name);
    }
    private void sellLoot(GameState.Item it) {
        s.money += (int)(it.price * 0.8);
        s.removeFromWarehouse(it.uid);
        Save.save(ctx, s);
        act.showScreen(getView());
    }

    private GameState.Item newItem(String id, String type, String name, int price,
                                   String icon, int dmg, int rate, int mag, int range, int bs) {
        GameState.Item it = new GameState.Item();
        it.uid = "U" + System.nanoTime();
        it.id = id; it.type = type; it.name = name; it.price = price;
        it.icon = icon; it.dmg = dmg; it.rate = rate; it.mag = mag;
        it.range = range; it.bs = bs;
        return it;
    }

    private void alert(String msg) {
        new AlertDialog.Builder(ctx).setMessage(msg)
                .setPositiveButton("好", (d, w) -> act.showScreen(getView()))
                .setCancelable(false)
                .show();
    }
}