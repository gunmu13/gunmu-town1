package com.gunmu.town.data;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Save {
    private static final String KEY = "gunmu_save_v9";

    public static void save(Context ctx, GameState s) {
        try {
            JSONObject o = toJson(s);
            ctx.getSharedPreferences("gunmu", Context.MODE_PRIVATE)
               .edit().putString(KEY, o.toString()).apply();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static GameState load(Context ctx) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("gunmu", Context.MODE_PRIVATE);
            String raw = sp.getString(KEY, null);
            if (raw == null) return GameState.createNew();
            return fromJson(new JSONObject(raw));
        } catch (Exception e) {
            return GameState.createNew();
        }
    }

    private static JSONObject toJson(GameState s) throws Exception {
        JSONObject o = new JSONObject();
        o.put("money", s.money);
        o.put("raids", s.raids); o.put("extracts", s.extracts);
        o.put("deaths", s.deaths); o.put("kills", s.kills);
        o.put("bestLoot", s.bestLoot); o.put("totalKills", s.totalKills);
        o.put("totalLoot", s.totalLoot);
        o.put("meleeKills", s.meleeKills); o.put("gunKills", s.gunKills);
        o.put("grenadeKills", s.grenadeKills); o.put("bossKills", s.bossKills);
        o.put("mods", s.mods);
        o.put("level", s.level); o.put("exp", s.exp); o.put("rankPoints", s.rankPoints);
        o.put("lastCheckin", s.lastCheckin);
        o.put("checkinStreak", s.checkinStreak);
        o.put("ammo", s.ammo); o.put("ammoType", s.ammoType);
        o.put("sfx", s.sfx); o.put("autoMed", s.autoMed); o.put("aimAssist", s.aimAssist);
        o.put("dropRateLevel", s.dropRateLevel);
        o.put("devMode", s.devMode);
        o.put("currentOperator", s.currentOperator);
        o.put("safeBoxId", s.safeBoxId);
        if (s.activeContractId != null) o.put("activeContractId", s.activeContractId);
        o.put("activeContractProgress", s.activeContractProgress);
        o.put("currentTitle", s.currentTitle);
        o.put("thirst", s.thirst);
        o.put("hunger", s.hunger);
        o.put("fatigue", s.fatigue);
        o.put("radiation", s.radiation);
        o.put("poison", s.poison);
        o.put("temperature", s.temperature);
        o.put("brokenLeg", s.brokenLeg);
        o.put("auctionFee", s.auctionFee);
        o.put("insuranceCount", s.insuranceCount);
        o.put("lastDailyReset", s.lastDailyReset);

        JSONArray wh = new JSONArray();
        for (GameState.Item it : s.warehouse) wh.put(itemJson(it));
        o.put("warehouse", wh);

        JSONArray meds = new JSONArray();
        for (GameState.Item it : s.meds) meds.put(itemJson(it));
        o.put("meds", meds);

        JSONArray sb = new JSONArray();
        for (GameState.Item it : s.safeBox) sb.put(itemJson(it));
        o.put("safeBox", sb);

        JSONArray tacs = new JSONArray();
        for (GameState.Item it : s.tacticals) tacs.put(itemJson(it));
        o.put("tacticals", tacs);

        JSONArray ops = new JSONArray();
        for (String op : s.ownedOperators) ops.put(op);
        o.put("ownedOperators", ops);

        JSONArray tarr = new JSONArray();
        for (String t : s.ownedTitles) tarr.put(t);
        o.put("ownedTitles", tarr);

        JSONArray varr = new JSONArray();
        for (String v : s.ownedVehicles) varr.put(v);
        o.put("ownedVehicles", varr);

        JSONArray lw = new JSONArray();
        for (String w : s.lockedWeapons) lw.put(w);
        o.put("lockedWeapons", lw);

        JSONArray dex = new JSONArray();
        for (String d : s.dexEntries) dex.put(d);
        o.put("dexEntries", dex);

        JSONArray asl = new JSONArray();
        for (String a : s.autoSellList) asl.put(a);
        o.put("autoSellList", asl);

        if (s.weapon != null) o.put("weapon", itemJson(s.weapon));
        if (s.melee != null) o.put("melee", itemJson(s.melee));
        if (s.armor != null) o.put("armor", itemJson(s.armor));
        if (s.helmet != null) o.put("helmet", itemJson(s.helmet));
        if (s.backpack != null) o.put("backpack", itemJson(s.backpack));

        JSONArray qs = new JSONArray();
        for (GameState.Quest q : s.quests) {
            JSONObject qo = new JSONObject();
            qo.put("id", q.id); qo.put("name", q.name); qo.put("desc", q.desc);
            qo.put("target", q.target); qo.put("progress", q.progress);
            qo.put("reward", q.reward); qo.put("done", q.done);
            qs.put(qo);
        }
        o.put("quests", qs);

        JSONArray ach = new JSONArray();
        for (String k : s.achievements.keySet()) if (s.achievements.get(k)) ach.put(k);
        o.put("achievements", ach);

        JSONArray mails = new JSONArray();
        for (GameState.Mail m : s.mails) {
            JSONObject mo = new JSONObject();
            mo.put("title", m.title); mo.put("time", m.time);
            mo.put("money", m.money); mo.put("itemType", m.itemType);
            mo.put("read", m.read);
            mails.put(mo);
        }
        o.put("mails", mails);

        JSONArray days = new JSONArray();
        for (int d : s.checkinDays) days.put(d);
        o.put("checkinDays", days);

        JSONArray logs = new JSONArray();
        for (GameState.BattleRecord r : s.questLog) {
            JSONObject ro = new JSONObject();
            ro.put("success", r.success); ro.put("map", r.map);
            ro.put("kills", r.kills); ro.put("loot", r.loot);
            logs.put(ro);
        }
        o.put("questLog", logs);

        JSONArray maps = new JSONArray();
        for (String m : s.unlockedMaps) maps.put(m);
        o.put("unlockedMaps", maps);

        JSONObject parts = new JSONObject();
        for (String gunUid : s.gunParts.keySet()) {
            JSONObject p = new JSONObject();
            for (String slot : s.gunParts.get(gunUid).keySet())
                p.put(slot, s.gunParts.get(gunUid).get(slot));
            parts.put(gunUid, p);
        }
        o.put("gunParts", parts);

        JSONObject bases = new JSONObject();
        for (String k : s.baseLevels.keySet()) bases.put(k, s.baseLevels.get(k));
        o.put("baseLevels", bases);

        JSONObject prof = new JSONObject();
        for (String k : s.proficiency.keySet()) prof.put(k, s.proficiency.get(k));
        o.put("proficiency", prof);

        JSONObject daily = new JSONObject();
        for (String k : s.dailyProgress.keySet()) daily.put(k, s.dailyProgress.get(k));
        o.put("dailyProgress", daily);

        JSONArray auc = new JSONArray();
        for (GameState.Auction a : s.auctions) {
            JSONObject ao = new JSONObject();
            ao.put("itemUid", a.itemUid); ao.put("itemName", a.itemName);
            ao.put("itemIcon", a.itemIcon); ao.put("itemCls", a.itemCls);
            ao.put("itemLevel", a.itemLevel); ao.put("itemPrice", a.itemPrice);
            ao.put("askPrice", a.askPrice); ao.put("listedAt", a.listedAt);
            ao.put("sold", a.sold);
            auc.put(ao);
        }
        o.put("auctions", auc);

        return o;
    }

    private static JSONObject itemJson(GameState.Item it) throws Exception {
        JSONObject j = new JSONObject();
        j.put("uid", it.uid); j.put("type", it.type);
        j.put("id", it.id); j.put("name", it.name);
        j.put("icon", it.icon); j.put("cls", it.cls);
        j.put("level", it.level); j.put("price", it.price);
        j.put("count", it.count);
        j.put("dmg", it.dmg); j.put("rate", it.rate);
        j.put("mag", it.mag); j.put("range", it.range); j.put("bs", it.bs);
        j.put("dur", it.dur); j.put("red", it.red);
        j.put("heal", it.heal);
        j.put("ammoId", it.ammoId); j.put("dmgMul", it.dmgMul);
        j.put("slot", it.slot); j.put("eff", it.eff);
        j.put("combo", it.combo);
        return j;
    }

    private static GameState.Item itemFromJson(JSONObject j) throws Exception {
        GameState.Item it = new GameState.Item();
        it.uid = j.optString("uid", null);
        it.type = j.optString("type", null);
        it.id = j.optString("id", null);
        it.name = j.optString("name", null);
        it.icon = j.optString("icon", null);
        it.cls = j.optString("cls", null);
        it.level = j.optInt("level", 0);
        it.price = j.optInt("price", 0);
        it.count = j.optInt("count", 1);
        it.dmg = j.optInt("dmg", 0);
        it.rate = j.optInt("rate", 0);
        it.mag = j.optInt("mag", 0);
        it.range = j.optInt("range", 0);
        it.bs = j.optInt("bs", 0);
        it.dur = j.optInt("dur", 0);
        it.red = j.optDouble("red", 0);
        it.heal = j.optDouble("heal", 0);
        it.ammoId = j.optString("ammoId", null);
        it.dmgMul = j.optDouble("dmgMul", 0);
        it.slot = j.optString("slot", null);
        it.eff = j.optString("eff", null);
        it.combo = j.optInt("combo", 1);
        return it;
    }

    private static GameState fromJson(JSONObject o) throws Exception {
        GameState s = new GameState();
        s.money = o.optInt("money", 500000);
        s.raids = o.optInt("raids"); s.extracts = o.optInt("extracts");
        s.deaths = o.optInt("deaths"); s.kills = o.optInt("kills");
        s.bestLoot = o.optInt("bestLoot"); s.totalKills = o.optInt("totalKills");
        s.totalLoot = o.optInt("totalLoot");
        s.meleeKills = o.optInt("meleeKills"); s.gunKills = o.optInt("gunKills");
        s.grenadeKills = o.optInt("grenadeKills"); s.bossKills = o.optInt("bossKills");
        s.mods = o.optInt("mods");
        s.level = o.optInt("level", 1);
        s.exp = o.optInt("exp"); s.rankPoints = o.optInt("rankPoints");
        s.lastCheckin = o.optString("lastCheckin", "");
        s.checkinStreak = o.optInt("checkinStreak");
        s.ammo = o.optInt("ammo");
        s.ammoType = o.optString("ammoType", "AM1");
        s.sfx = o.optBoolean("sfx", true);
        s.autoMed = o.optBoolean("autoMed", true);
        s.aimAssist = o.optBoolean("aimAssist", true);
        s.dropRateLevel = o.optInt("dropRateLevel", 1);
        s.devMode = o.optBoolean("devMode", false);
        s.currentOperator = o.optString("currentOperator", "OP1");
        s.safeBoxId = o.optString("safeBoxId", "S1");
        s.activeContractId = o.optString("activeContractId", null);
        if ("null".equals(s.activeContractId)) s.activeContractId = null;
        s.activeContractProgress = o.optInt("activeContractProgress", 0);
        s.currentTitle = o.optString("currentTitle", "TI1");
        s.thirst = o.optInt("thirst", 100);
        s.hunger = o.optInt("hunger", 100);
        s.fatigue = o.optInt("fatigue", 0);
        s.radiation = o.optInt("radiation", 0);
        s.poison = o.optInt("poison", 0);
        s.temperature = o.optInt("temperature", 37);
        s.brokenLeg = o.optBoolean("brokenLeg", false);
        s.auctionFee = o.optInt("auctionFee", 0);
        s.insuranceCount = o.optInt("insuranceCount", 0);
        s.lastDailyReset = o.optString("lastDailyReset", "");

        JSONArray wh = o.optJSONArray("warehouse");
        if (wh != null) for (int i = 0; i < wh.length(); i++)
            s.warehouse.add(itemFromJson(wh.getJSONObject(i)));

        JSONArray meds = o.optJSONArray("meds");
        if (meds != null) for (int i = 0; i < meds.length(); i++)
            s.meds.add(itemFromJson(meds.getJSONObject(i)));

        JSONArray sb = o.optJSONArray("safeBox");
        if (sb != null) for (int i = 0; i < sb.length(); i++)
            s.safeBox.add(itemFromJson(sb.getJSONObject(i)));

        JSONArray tacs = o.optJSONArray("tacticals");
        if (tacs != null) for (int i = 0; i < tacs.length(); i++)
            s.tacticals.add(itemFromJson(tacs.getJSONObject(i)));

        s.ownedOperators.clear();
        JSONArray ops2 = o.optJSONArray("ownedOperators");
        if (ops2 != null) for (int i = 0; i < ops2.length(); i++)
            s.ownedOperators.add(ops2.getString(i));
        if (s.ownedOperators.isEmpty()) s.ownedOperators.add("OP1");

        s.ownedTitles.clear();
        JSONArray tarr2 = o.optJSONArray("ownedTitles");
        if (tarr2 != null) for (int i = 0; i < tarr2.length(); i++)
            s.ownedTitles.add(tarr2.getString(i));
        if (s.ownedTitles.isEmpty()) s.ownedTitles.add("TI1");

        s.ownedVehicles.clear();
        JSONArray varr2 = o.optJSONArray("ownedVehicles");
        if (varr2 != null) for (int i = 0; i < varr2.length(); i++)
            s.ownedVehicles.add(varr2.getString(i));

        s.lockedWeapons.clear();
        JSONArray lw2 = o.optJSONArray("lockedWeapons");
        if (lw2 != null) for (int i = 0; i < lw2.length(); i++)
            s.lockedWeapons.add(lw2.getString(i));

        s.dexEntries.clear();
        JSONArray dex2 = o.optJSONArray("dexEntries");
        if (dex2 != null) for (int i = 0; i < dex2.length(); i++)
            s.dexEntries.add(dex2.getString(i));

        s.autoSellList.clear();
        JSONArray asl2 = o.optJSONArray("autoSellList");
        if (asl2 != null) for (int i = 0; i < asl2.length(); i++)
            s.autoSellList.add(asl2.getString(i));

        if (o.has("weapon")) s.weapon = itemFromJson(o.getJSONObject("weapon"));
        if (o.has("melee")) s.melee = itemFromJson(o.getJSONObject("melee"));
        if (o.has("armor")) s.armor = itemFromJson(o.getJSONObject("armor"));
        if (o.has("helmet")) s.helmet = itemFromJson(o.getJSONObject("helmet"));
        if (o.has("backpack")) s.backpack = itemFromJson(o.getJSONObject("backpack"));
        if (s.backpack == null) {
            GameState.Item bk = new GameState.Item();
            bk.uid = "BkDefault"; bk.id = "B0"; bk.type = "backpack";
            bk.name = "帆布小包"; bk.icon = "🎒"; bk.slot = "4"; bk.count = 1;
            s.backpack = bk;
        }

        JSONArray qs = o.optJSONArray("quests");
        if (qs != null) for (int i = 0; i < qs.length(); i++) {
            JSONObject qo = qs.getJSONObject(i);
            GameState.Quest q = new GameState.Quest();
            q.id = qo.optString("id"); q.name = qo.optString("name");
            q.desc = qo.optString("desc");
            q.target = qo.optInt("target"); q.progress = qo.optInt("progress");
            q.reward = qo.optInt("reward"); q.done = qo.optBoolean("done");
            s.quests.add(q);
        }

        JSONArray ach = o.optJSONArray("achievements");
        if (ach != null) for (int i = 0; i < ach.length(); i++)
            s.achievements.put(ach.getString(i), true);

        JSONArray mails = o.optJSONArray("mails");
        if (mails != null) for (int i = 0; i < mails.length(); i++) {
            JSONObject mo = mails.getJSONObject(i);
            GameState.Mail m = new GameState.Mail("", 0, null);
            m.title = mo.optString("title"); m.time = mo.optString("time");
            m.money = mo.optInt("money"); m.itemType = mo.optString("itemType", null);
            m.read = mo.optBoolean("read");
            s.mails.add(m);
        }

        JSONArray days = o.optJSONArray("checkinDays");
        if (days != null) for (int i = 0; i < days.length(); i++)
            s.checkinDays.add(days.getInt(i));

        JSONArray logs = o.optJSONArray("questLog");
        if (logs != null) for (int i = 0; i < logs.length(); i++) {
            JSONObject ro = logs.getJSONObject(i);
            GameState.BattleRecord r = new GameState.BattleRecord();
            r.success = ro.optBoolean("success");
            r.map = ro.optString("map");
            r.kills = ro.optInt("kills"); r.loot = ro.optInt("loot");
            s.questLog.add(r);
        }

        JSONArray maps = o.optJSONArray("unlockedMaps");
        if (maps != null) for (int i = 0; i < maps.length(); i++)
            s.unlockedMaps.add(maps.getString(i));
        if (s.unlockedMaps.isEmpty()) {
            s.unlockedMaps.add("town");
            s.unlockedMaps.add("mine");
            s.unlockedMaps.add("facility");
        }

        JSONObject parts = o.optJSONObject("gunParts");
        if (parts != null) {
            java.util.Iterator<String> it = parts.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject p = parts.getJSONObject(k);
                Map<String,String> m = new HashMap<>();
                java.util.Iterator<String> it2 = p.keys();
                while (it2.hasNext()) {
                    String k2 = it2.next();
                    m.put(k2, p.getString(k2));
                }
                s.gunParts.put(k, m);
            }
        }

        JSONObject bases = o.optJSONObject("baseLevels");
        if (bases != null) {
            java.util.Iterator<String> it = bases.keys();
            while (it.hasNext()) {
                String k = it.next();
                s.baseLevels.put(k, bases.getInt(k));
            }
        }
        for (GameData.BaseUpgrade u : GameData.BASE_UPGRADES) {
            if (!s.baseLevels.containsKey(u.id)) s.baseLevels.put(u.id, 0);
        }

        JSONObject prof = o.optJSONObject("proficiency");
        if (prof != null) {
            java.util.Iterator<String> it = prof.keys();
            while (it.hasNext()) {
                String k = it.next();
                s.proficiency.put(k, prof.getInt(k));
            }
        }

        JSONObject daily = o.optJSONObject("dailyProgress");
        if (daily != null) {
            java.util.Iterator<String> it = daily.keys();
            while (it.hasNext()) {
                String k = it.next();
                s.dailyProgress.put(k, daily.getInt(k));
            }
        }

        JSONArray auc = o.optJSONArray("auctions");
        if (auc != null) for (int i = 0; i < auc.length(); i++) {
            JSONObject ao = auc.getJSONObject(i);
            GameState.Auction a = new GameState.Auction();
            a.itemUid = ao.optString("itemUid");
            a.itemName = ao.optString("itemName");
            a.itemIcon = ao.optString("itemIcon");
            a.itemCls = ao.optString("itemCls");
            a.itemLevel = ao.optInt("itemLevel");
            a.itemPrice = ao.optInt("itemPrice");
            a.askPrice = ao.optInt("askPrice");
            a.listedAt = ao.optLong("listedAt");
            a.sold = ao.optBoolean("sold");
            s.auctions.add(a);
        }

        return s;
    }
}