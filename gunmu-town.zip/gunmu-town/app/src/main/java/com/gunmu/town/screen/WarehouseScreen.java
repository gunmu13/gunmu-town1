package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

/** 仓库 */
public class WarehouseScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private String filter = "all";

    public WarehouseScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        // 标题栏
        root.addView(UI.topbar(ctx, () -> act.showLobby(),
                "仓库", s.warehouse.size() + " 件"));

        // 过滤按钮
        ScrollView filtScroll = new ScrollView(ctx);
        filtScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout filtRow = new LinearLayout(ctx);
        filtRow.setOrientation(LinearLayout.HORIZONTAL);
        filtRow.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8));
        addFilter(filtRow, "全部", "all");
        addFilter(filtRow, "变卖物", "loot");
        addFilter(filtRow, "枪械", "weapon");
        addFilter(filtRow, "刀具", "melee");
        addFilter(filtRow, "护甲", "armor");
        addFilter(filtRow, "头盔", "helmet");
        addFilter(filtRow, "药品", "med");
        addFilter(filtRow, "弹药", "ammo");
        addFilter(filtRow, "配件", "part");
        filtScroll.addView(filtRow);
        root.addView(filtScroll);

        // 网格
        ScrollView scroll = new ScrollView(ctx);
        GridLayout grid = new GridLayout(ctx);
        grid.setColumnCount(6);
        grid.setPadding(UI.dp(ctx, 8), 0, UI.dp(ctx, 8), UI.dp(ctx, 8));

        boolean empty = true;
        for (GameState.Item it : s.warehouse) {
            if (!filter.equals("all") && !filter.equals(it.type)) continue;
            empty = false;
            grid.addView(buildCell(it), cellParams());
        }

        if (empty) {
            TextView e = UI.tv(ctx, "这个分类下没有物品", 14, UI.GRAY);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, UI.dp(ctx, 60), 0, 0);
            scroll.addView(e);
        } else {
            scroll.addView(grid);
        }
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private GridLayout.LayoutParams cellParams() {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = UI.dp(ctx, 78);
        lp.height = UI.dp(ctx, 78);
        lp.setMargins(UI.dp(ctx, 4), UI.dp(ctx, 4), UI.dp(ctx, 4), UI.dp(ctx, 4));
        return lp;
    }

    private void addFilter(LinearLayout parent, String label, String key) {
        Button b = UI.smallBtn(ctx, label);
        boolean active = filter.equals(key);
        b.setBackground(UI.round(active ? UI.ORANGE : UI.PANEL,
                UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 4)));
        b.setTextColor(active ? UI.BG : UI.TEXT);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.rightMargin = UI.dp(ctx, 6);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            filter = key;
            act.showScreen(getView());
        });
        parent.addView(b);
    }

    private LinearLayout buildCell(GameState.Item it) {
        LinearLayout cell = new LinearLayout(ctx);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setBackground(UI.round(UI.PANEL, colorOf(it), UI.dp(ctx, 2), UI.dp(ctx, 4)));

        TextView icon = UI.tv(ctx, it.icon != null ? it.icon : "❔", 24, UI.TEXT);
        icon.setGravity(Gravity.CENTER);
        cell.addView(icon);

        TextView name = UI.tv(ctx, it.name, 9, UI.TEXT);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        cell.addView(name);

        if (it.count > 1) {
            TextView c = UI.tv(ctx, "×" + it.count, 9, UI.GOLD);
            c.setGravity(Gravity.CENTER);
            cell.addView(c);
        }

        cell.setOnClickListener(v -> showDetail(it));
        return cell;
    }

    private int colorOf(GameState.Item it) {
        if (it.level == 7) return UI.GOLD;
        switch (it.level) {
            case 6: return 0xFFFF3B3B;
            case 5: return 0xFFFF8C2A;
            case 4: return 0xFFA45CFF;
            case 3: return 0xFF3D8BFD;
            case 2: return 0xFF4CAF50;
            default: return UI.BORDER;
        }
    }

    private void showDetail(GameState.Item it) {
        StringBuilder sb = new StringBuilder();
        sb.append("类型：").append(typeName(it.type)).append("\n");
        if (it.level > 0) sb.append("等级：Lv").append(it.level).append("\n");
        if ("weapon".equals(it.type)) sb.append("伤害：").append(it.dmg)
                .append(" · 射速：").append(it.rate).append(" · 弹匣：").append(it.mag).append("\n");
        if ("melee".equals(it.type)) sb.append("伤害：").append(it.dmg)
                .append(" · 攻速：").append(it.rate).append("\n");
        if ("armor".equals(it.type) || "helmet".equals(it.type))
            sb.append("减伤：").append((int)(it.red*100)).append("% · 耐久：").append(it.dur).append("\n");
        if ("med".equals(it.type)) sb.append("恢复：").append((int)(it.heal*100)).append("%\n");
        if ("ammo".equals(it.type)) sb.append("数量：").append(it.count).append("\n");
        if ("part".equals(it.type)) sb.append("效果：").append(it.eff).append("\n");
        sb.append("估价：").append(UI.fmt(it.price)).append("\n");
        sb.append("出售可得：").append(UI.fmt((int)(it.price * 0.8)));

        AlertDialog.Builder b = new AlertDialog.Builder(ctx);
        b.setTitle(it.name);
        b.setMessage(sb.toString());

        final boolean canEquip = !"loot".equals(it.type) && !"part".equals(it.type);
        b.setPositiveButton("出售", (d, w) -> sell(it, 1));
        if (canEquip) b.setNeutralButton("装备", (d, w) -> equip(it));
        b.setNegativeButton("关闭", null);
        b.show();
    }

    private void sell(GameState.Item it, int count) {
        if (it.count > 1) {
            int take = Math.min(count, it.count);
            s.money += (int)(it.price * 0.8) * take;
            it.count -= take;
            if (it.count <= 0) s.removeFromWarehouse(it.uid);
        } else {
            s.money += (int)(it.price * 0.8);
            s.removeFromWarehouse(it.uid);
        }
        Save.save(ctx, s);
        act.showScreen(getView());
    }

    private void equip(GameState.Item it) {
        if ("med".equals(it.type)) {
            if (s.meds.size() >= 3) { alert("药品已满"); return; }
            s.removeFromWarehouse(it.uid);
            s.meds.add(it);
        } else if ("ammo".equals(it.type)) {
            s.ammo += it.count;
            s.ammoType = it.ammoId;
            s.removeFromWarehouse(it.uid);
        } else {
            GameState.Item old = null;
            if ("weapon".equals(it.type)) old = s.weapon;
            else if ("melee".equals(it.type)) old = s.melee;
            else if ("armor".equals(it.type)) old = s.armor;
            else if ("helmet".equals(it.type)) old = s.helmet;

            if (old != null) s.addToWarehouse(old);
            s.removeFromWarehouse(it.uid);
            if ("weapon".equals(it.type)) s.weapon = it;
            else if ("melee".equals(it.type)) s.melee = it;
            else if ("armor".equals(it.type)) s.armor = it;
            else if ("helmet".equals(it.type)) s.helmet = it;
        }
        Save.save(ctx, s);
        act.showScreen(getView());
    }

    private String typeName(String t) {
        if ("loot".equals(t)) return "变卖物";
        if ("weapon".equals(t)) return "枪械";
        if ("melee".equals(t)) return "刀具";
        if ("armor".equals(t)) return "护甲";
        if ("helmet".equals(t)) return "头盔";
        if ("med".equals(t)) return "药品";
        if ("ammo".equals(t)) return "弹药";
        if ("part".equals(t)) return "配件";
        return "未知";
    }

    private void alert(String msg) {
        new AlertDialog.Builder(ctx).setMessage(msg)
                .setPositiveButton("好", null).show();
    }
}