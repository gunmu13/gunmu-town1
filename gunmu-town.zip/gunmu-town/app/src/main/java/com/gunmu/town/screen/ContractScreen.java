package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

public class ContractScreen {
    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    public ContractScreen(MainActivity a){ act=a; ctx=a; s=a.state; }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), "合同任务",
                "💰 " + UI.fmt(s.money)));
        ScrollView sc = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12));
        for (GameData.Contract c : GameData.CONTRACTS) list.addView(buildCard(c));
        sc.addView(list);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private View buildCard(final GameData.Contract c) {
        boolean active = c.id.equals(s.activeContractId);
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14));
        card.setBackground(UI.round(UI.PANEL,
                active ? 0xFFFFD700 : UI.BORDER, UI.dp(ctx,2), UI.dp(ctx,6)));
        card.addView(UI.tv(ctx, c.name, 16, UI.GOLD));
        card.addView(UI.tv(ctx, c.desc, 12, UI.GRAY));
        card.addView(UI.tv(ctx, "目标：" + c.target + " · 奖励："
                + UI.fmt(c.reward) + " 币", 12, UI.ORANGE));
        if (active) {
            card.addView(UI.tv(ctx, "进度：" + s.activeContractProgress
                    + " / " + c.target, 12, 0xFF4CAF50));
        }
        Button b = UI.smallBtn(ctx, active ? "放弃合同" : "接受合同");
        b.setOnClickListener(v -> {
            if (active) {
                s.activeContractId = null;
                s.activeContractProgress = 0;
                Save.save(ctx, s);
                act.showScreen(getView());
            } else {
                if (s.activeContractId != null) {
                    new AlertDialog.Builder(ctx).setMessage("已有进行中的合同")
                            .setPositiveButton("好", null).show();
                    return;
                }
                s.activeContractId = c.id;
                s.activeContractProgress = 0;
                Save.save(ctx, s);
                act.showScreen(getView());
            }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = UI.dp(ctx,8);
        b.setLayoutParams(lp);
        card.addView(b);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.bottomMargin = UI.dp(ctx,10);
        card.setLayoutParams(clp);
        return card;
    }
}