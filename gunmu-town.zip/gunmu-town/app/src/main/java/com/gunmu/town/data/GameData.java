package com.gunmu.town.data;

import java.util.ArrayList;
import java.util.List;

/** 全量静态数据表 */
public class GameData {

    // ============ 变卖物 ============
    public static class Loot {
        public String id, name, icon, cls;
        public int level, price;
        public Loot(String id, String name, int level, int price, String icon, String cls) {
            this.id = id; this.name = name; this.level = level;
            this.price = price; this.icon = icon; this.cls = cls;
        }
    }

    private static final String[][] LOOT_NAMES = {
        // 1级 23个
        {"锈铁钉","破布条","空塑料瓶","旧电池","铜线圈","断扳手","黄胶带","油气打火机",
         "短铅笔","碎橡皮","铁螺丝","小弹簧","麻绳头","汽水瓶盖","湿纸板","塑料袋",
         "瘪铝罐","脏纱布","木楔子","橡皮筋","订书钉","弯回形针","半截牙签"},
        // 2级 21个
        {"医用绷带","压缩能量棒","打火机油","黄铜管","废电缆","铁皮工具箱","防水帆布",
         "旧手电","五号电池组","军用水壶","硬饼干","止血带","铁口哨","指南针",
         "裂镜放大镜","温度计","听诊器","手术刀片","注射器","氧气罐","滤毒罐芯"},
        // 3级 21个
        {"军用口粮","红外滤镜","加密U盘","SIM卡组","夜视仪镜片","消音器零件","四倍瞄准镜",
         "防弹插板","战术手套","军靴","头盔衬垫","水袋","GPS模块","短波电台","双筒望远镜",
         "红色信号弹","灰烟幕弹","闪光雷","破片手雷","燃烧瓶","C4塑胶炸药"},
        // 4级 23个
        {"金壳手表","金手镯","镀金手机","碎钻戒指","银质胸针","老式摄影机","矿卡显卡",
         "钯金线材","除颤器","宫廷银器","激光指示模块","液压扳手","掌上游戏机","黑胶唱片机",
         "古董打字机","维修手册","金豹小雕像","青花茶壶","宝石项链","胰岛素泵",
         "精密水平仪","鎏金酒杯","纯金小块"},
        // 5级 15个
        {"热成像模块","目标定位模块","碎纹花瓶","金狮雕像","盛宴雕塑","金魔方",
         "军用加密硬盘","卫星电话","夜视仪","防弹公文包","钛合金板","碳纤维布",
         "军用无人机","高级工具组","稀有化学品"},
        // 6级 7个
        {"理想国芯片","军用主控芯片","核废料样本","古代金币","陨石碎片","生物样本容器","量子处理器"},
        // 7级 1个
        {"机密文件"}
    };

    private static final int[][] LEVEL_PRICE = {
        {500,3000},{3000,8000},{8000,20000},{20000,60000},
        {60000,150000},{150000,400000},{800000,900000}
    };

    private static final String[] LEVEL_ICON = {"🔩","🧰","📦","💎","🏆","👑","🗂️"};

    public static final List<Loot> ALL_LOOT = new ArrayList<>();
    static {
        int uid = 1;
        for (int lv = 1; lv <= 7; lv++) {
            String[] names = LOOT_NAMES[lv - 1];
            int lo = LEVEL_PRICE[lv - 1][0];
            int hi = LEVEL_PRICE[lv - 1][1];
            for (int i = 0; i < names.length; i++) {
                double r = names.length == 1 ? 1 : (double) i / (names.length - 1);
                double base = lo + (hi - lo) * r;
                double j = base * (Math.random() * 0.3 - 0.15);
                int price = (int) (Math.round((base + j) / 100) * 100);
                ALL_LOOT.add(new Loot("L" + (uid++), names[i], lv, price,
                        LEVEL_ICON[lv - 1], "lv" + lv));
            }
        }
    }

    // ============ 枪械 ============
    public static class Weapon {
        public String id, name;
        public int price, dmg, rate, mag, range, bs;
        public Weapon(String id, String name, int price, int dmg, int rate, int mag, int range, int bs) {
            this.id = id; this.name = name; this.price = price; this.dmg = dmg;
            this.rate = rate; this.mag = mag; this.range = range; this.bs = bs;
        }
    }

    public static final Weapon[] WEAPONS = {
        new Weapon("W01","锈蜂 PDW-9",1000,15,900,30,600,14),
        new Weapon("W02","矿工 M870",3000,45,60,6,280,9),
        new Weapon("W03","夜莺 MP5",8000,20,800,30,650,14),
        new Weapon("W04","红壤 AK74N",15000,32,650,30,900,16),
        new Weapon("W05","铁砧 SKS",22000,38,300,10,1000,17),
        new Weapon("W06","峡谷 BM59",26000,42,350,20,1000,17),
        new Weapon("W07","远钟 M14",35000,55,250,20,1100,18),
        new Weapon("W08","白桦 Mosin",39000,85,40,5,1300,22),
        new Weapon("W09","沙狐 MDR",45000,40,700,30,900,15),
        new Weapon("W10","长枪管 M4A1",75000,35,800,30,950,16),
        new Weapon("W11","赤铁 AK-102",93000,38,650,30,950,16),
        new Weapon("W12","鹰眼 AUG",120000,40,750,30,1000,16),
        new Weapon("W13","大西洋 FAL",180000,52,630,20,1050,17),
        new Weapon("W14","幽灵 H416",280000,45,850,30,1000,17),
        new Weapon("W15","审判 MK14",450000,70,400,20,1200,19),
        new Weapon("W16","军刀 RPK",65000,36,600,60,900,16),
        new Weapon("W17","堡垒 SA58",220000,58,500,20,1000,17),
        new Weapon("W18","暗影 SR-25",380000,65,350,20,1150,18),
        new Weapon("W19","雷神 P90",160000,28,1000,50,700,15),
        new Weapon("W20","天罚 AWM",600000,120,30,5,1500,25)
    };

    // ============ 刀具 ============
    public static class Melee {
        public String id, name;
        public int price, dmg, rate, range;
        public Melee(String id, String name, int price, int dmg, int rate, int range) {
            this.id=id; this.name=name; this.price=price;
            this.dmg=dmg; this.rate=rate; this.range=range;
        }
    }

    public static final Melee[] MELEES = {
        new Melee("K01","生锈小刀",0,20,180,50),
        new Melee("K02","矿工匕首",500,35,200,55),
        new Melee("K03","军用战术刀",2500,55,220,60),
        new Melee("K04","猎刀",8000,80,200,65),
        new Melee("K05","消防斧",20000,120,150,70),
        new Melee("K06","碳纤维砍刀",60000,180,180,75),
        new Melee("K07","武士刀",200000,300,200,85)
    };

    // ============ 护甲 ============
    public static class Armor {
        public String id, name;
        public int price, dur, tier;
        public double red;
        public Armor(String id, String name, int price, int dur, double red, int tier) {
            this.id=id; this.name=name; this.price=price;
            this.dur=dur; this.red=red; this.tier=tier;
        }
    }
    public static final Armor[] ARMORS = {
        new Armor("A1","特勤防弹衣",2000,35,0.20,1),
        new Armor("A2","H-Tac 特勤甲",4500,45,0.30,2),
        new Armor("A3","KN 制式甲",30000,55,0.45,3),
        new Armor("A4","SEK 壁垒甲",100000,65,0.55,4),
        new Armor("A5","926 复合甲",200000,75,0.65,5),
        new Armor("A6","IMTV 武士甲",450000,90,0.75,6)
    };
    public static final Armor[] HELMETS = {
        new Armor("H1","工地安全帽",800,20,0.15,1),
        new Armor("H2","战术软帽",2500,28,0.25,2),
        new Armor("H3","KN 防弹盔",18000,38,0.40,3),
        new Armor("H4","SEK 重型盔",60000,50,0.52,4),
        new Armor("H5","926 复合盔",130000,62,0.62,5),
        new Armor("H6","IMTV 武士盔",280000,78,0.72,6)
    };

    // ============ 药品 ============
    public static class Med {
        public String id, name, icon;
        public int price;
        public double heal;
        public Med(String id, String name, int price, double heal, String icon) {
            this.id=id; this.name=name; this.price=price; this.heal=heal; this.icon=icon;
        }
    }
    public static final Med[] MEDS = {
        new Med("M1","简易急救包",800,0.33,"🩹"),
        new Med("M2","军用急救包",2500,0.50,"💉"),
        new Med("M3","白色医疗箱",8000,1.00,"🧰")
    };

    // ============ 弹药 ============
    public static class Ammo {
        public String id, name, icon;
        public int price;
        public double dmgMul;
        public Ammo(String id, String name, int price, double mul, String icon) {
            this.id=id; this.name=name; this.price=price; this.dmgMul=mul; this.icon=icon;
        }
    }
    public static final Ammo[] AMMO_TYPES = {
        new Ammo("AM1","手枪弹",2,1.0,"🔸"),
        new Ammo("AM2","步枪弹",4,1.1,"🔶"),
        new Ammo("AM3","穿甲弹",12,1.4,"💥")
    };

    // ============ 配件 ============
    public static class Part {
        public String id, name, slot, eff;
        public int price;
        public Part(String id, String name, int price, String slot, String eff) {
            this.id=id; this.name=name; this.price=price; this.slot=slot; this.eff=eff;
        }
    }
    public static final Part[] PARTS = {
        new Part("P01","红点瞄准镜",5000,"scope","+15%命中"),
        new Part("P02","四倍镜",20000,"scope","+30%命中"),
        new Part("P03","消音器",15000,"muzzle","-敌人警戒"),
        new Part("P04","补偿器",8000,"muzzle","+10%伤害"),
        new Part("P05","扩容弹匣",12000,"mag","+10发弹匣"),
        new Part("P06","快拔枪托",6000,"stock","-20%后坐力"),
        new Part("P07","垂直握把",4000,"grip","+15%稳定性"),
        new Part("P08","激光指示器",9000,"grip","+10%腰射")
    };

    // ============ 敌人 ============
    public static class Enemy {
        public String id, name, dropTier, icon;
        public int hp, dmg, exp;
        public Enemy(String id, String name, int hp, int dmg, String tier, String icon, int exp) {
            this.id=id; this.name=name; this.hp=hp; this.dmg=dmg;
            this.dropTier=tier; this.icon=icon; this.exp=exp;
        }
    }
    public static final Enemy[] ENEMIES = {
        new Enemy("E01","流浪拾荒者",60,8,"low","🧟",5),
        new Enemy("E02","武装匪徒",90,15,"low","🥷",10),
        new Enemy("E03","巡逻哨兵",80,12,"low","💂",8),
        new Enemy("E04","精英斥候",110,20,"mid","🕵️",20),
        new Enemy("E05","重装守卫",150,18,"mid","🛡️",25),
        new Enemy("E06","屋顶狙击手",70,35,"mid","🎯",22),
        new Enemy("E07","废墟突击兵",100,22,"mid","🔫",18),
        new Enemy("E08","爆破专家",95,28,"high","💣",35),
        new Enemy("E09","随队医疗兵",85,10,"high","⛑️",30),
        new Enemy("E10","精英指挥官",130,25,"high","🎖️",45),
        new Enemy("E11","暗影刺客",80,30,"high","🥷",40),
        new Enemy("E12","钢铁重装",200,22,"high","🦾",55),
        new Enemy("E13","火焰兵",120,26,"high","🔥",50),
        new Enemy("E14","电磁技师",100,24,"mid","⚡",35),
        new Enemy("E15","战场指挥官",180,30,"high","⭐",70)
    };

    public static final Enemy BOSS =
        new Enemy("BOSS","“棍母”镇长",500,40,"boss","👺",200);

    // ============ 容器 ============
    public static class Container {
        public String id, name, tier, icon;
        public Container(String id, String name, String tier, String icon) {
            this.id=id; this.name=name; this.tier=tier; this.icon=icon;
        }
    }
    public static final Container[] CONTAINERS = {
        new Container("C01","军用保险箱","low","🗄️"),
        new Container("C02","加密集装箱","low","📦"),
        new Container("C03","医疗空投","low","🚁"),
        new Container("C04","武器箱","low","🔫"),
        new Container("C05","电子保险箱","low","💻"),
        new Container("C06","军用背包","mid","🎒"),
        new Container("C07","弹药箱","mid","📦"),
        new Container("C08","工具箱","mid","🧰"),
        new Container("C09","旅行箱","mid","🧳"),
        new Container("C10","抽屉","mid","🗃️"),
        new Container("C11","普通补给箱","high","📮"),
        new Container("C12","散落物资点","high","🧷"),
        new Container("C13","衣柜","high","🚪"),
        new Container("C14","废弃车辆","high","🚗")
    };

    // ============ 爆率 ============
    public static double[][] DROP_RATE = {
        // low, mid, high, boss → 7 个等级的爆率
        {0.05,0.10,0.20,0.35,0.20,0.08,0.02},
        {0.15,0.25,0.30,0.20,0.08,0.02,0.00},
        {0.40,0.35,0.20,0.05,0.00,0.00,0.00},
        {0.00,0.05,0.10,0.25,0.35,0.20,0.05}
    };

    public static int tierIndex(String tier) {
        if ("low".equals(tier)) return 0;
        if ("mid".equals(tier)) return 1;
        if ("high".equals(tier)) return 2;
        return 3; // boss
    }

    // ============ 地图 ============
    public static class MapDef {
        public String id, name, desc;
        public double lootMul, enMul;
        public MapDef(String id, String name, String desc, double lootMul, double enMul) {
            this.id=id; this.name=name; this.desc=desc;
            this.lootMul=lootMul; this.enMul=enMul;
        }
    }
    public static final MapDef[] MAPS = {
        new MapDef("town","棍母小镇","废弃矿区旁的居民点",1.0,1.0),
        new MapDef("mine","废弃矿洞","塌方频发，矿脉里全是宝",1.4,1.3),
        new MapDef("facility","旧军事设施","危险最高，机密出没",1.9,1.6)
    };

    // ============ 难度 ============
    public static class Difficulty {
        public String id, name;
        public int eMin, eMax, minValue;
        public double luck;
        public boolean boss;
        public Difficulty(String id,String name,int eMin,int eMax,double luck,boolean boss,int minValue){
            this.id=id; this.name=name; this.eMin=eMin; this.eMax=eMax;
            this.luck=luck; this.boss=boss; this.minValue=minValue;
        }
    }
    public static final Difficulty[] DIFFICULTY = {
        new Difficulty("normal","普通",5,8,1.0,false,0),
        new Difficulty("hard","困难",8,12,1.5,false,50000),
        new Difficulty("lockdown","封锁",12,15,2.5,true,150000)
    };

    // ============ 段位 ============
    public static class Rank {
        public String name, icon;
        public int min;
        public Rank(String name, int min, String icon){ this.name=name; this.min=min; this.icon=icon; }
    }
    public static final Rank[] RANKS = {
        new Rank("青铜III",0,"🥉"), new Rank("青铜II",50,"🥉"), new Rank("青铜I",100,"🥉"),
        new Rank("白银III",200,"🥈"), new Rank("白银II",300,"🥈"), new Rank("白银I",450,"🥈"),
        new Rank("黄金III",600,"🥇"), new Rank("黄金II",800,"🥇"), new Rank("黄金I",1000,"🥇"),
        new Rank("铂金III",1300,"💠"), new Rank("铂金II",1600,"💠"), new Rank("铂金I",2000,"💠"),
        new Rank("钻石III",2500,"💎"), new Rank("钻石II",3000,"💎"), new Rank("钻石I",4000,"💎"),
        new Rank("传奇",5000,"👑")
    };

    // ============ 成就 ============
    public static class Achievement {
        public String id, name, desc, type;
        public int target, reward;
        public Achievement(String id,String name,String desc,int target,String type,int reward){
            this.id=id; this.name=name; this.desc=desc;
            this.target=target; this.type=type; this.reward=reward;
        }
    }
    public static final Achievement[] ACHIEVEMENTS = {
        new Achievement("a01","初次行动","完成第一次突袭",1,"raid",5000),
        new Achievement("a02","首战告捷","首次成功撤离",1,"extract",10000),
        new Achievement("a03","小有积蓄","存款达到10万",100000,"money",5000),
        new Achievement("a04","富甲一方","存款达到100万",1000000,"money",50000),
        new Achievement("a05","大富翁","存款达到500万",5000000,"money",200000),
        new Achievement("a06","猎人","累计击杀10人",10,"kill",5000),
        new Achievement("a07","屠夫","累计击杀50人",50,"kill",20000),
        new Achievement("a08","战神","累计击杀200人",200,"kill",100000),
        new Achievement("a09","常客","完成10次突袭",10,"raid",10000),
        new Achievement("a10","老手","完成50次突袭",50,"raid",50000),
        new Achievement("a11","生存大师","成功撤离20次",20,"extract",30000),
        new Achievement("a12","不死鸟","成功撤离100次",100,"extract",200000),
        new Achievement("a13","掘金者","累计带出50万物资",500000,"loot",20000),
        new Achievement("a14","宝藏猎人","累计带出500万物资",5000000,"loot",300000),
        new Achievement("a15","镇长终结者","击败镇长",1,"boss",100000),
        new Achievement("a16","跑刀专家","近战击杀10人",10,"melee",20000),
        new Achievement("a17","神枪手","枪械击杀50人",50,"gun",30000),
        new Achievement("a18","爆破大师","手雷击杀5人",5,"grenade",25000),
        new Achievement("a19","孤胆英雄","单人击杀Boss",1,"boss",150000),
        new Achievement("a20","装备齐全","装备所有槽位",1,"fullEquip",10000),
        new Achievement("a21","军火商","仓库10把枪",10,"haveGuns",30000),
        new Achievement("a22","收藏家","5件5级以上物品",5,"haveHigh",50000),
        new Achievement("a23","传说猎人","获得机密文件",1,"haveLegendary",500000),
        new Achievement("a24","资深指挥官","达到Lv10",10,"level",50000),
        new Achievement("a25","精英指挥官","达到Lv30",30,"level",300000),
        new Achievement("a26","连续签到3天","签到3天",3,"checkin",15000),
        new Achievement("a27","连续签到7天","签到7天",7,"checkin",80000),
        new Achievement("a28","改装大师","改装10把枪",10,"modGun",50000),
        new Achievement("a29","百战老兵","完成100次突袭",100,"raid",300000),
        new Achievement("a30","棍母传奇","达成所有成就",29,"allAch",1000000)
    };

    // ============ 签到 ============
    public static class DailyReward {
        public int day, money;
        public String itemId;
        public DailyReward(int day, int money, String itemId){
            this.day=day; this.money=money; this.itemId=itemId;
        }
    }
    public static final DailyReward[] DAILY_REWARDS = {
        new DailyReward(1,10000,null),
        new DailyReward(2,20000,null),
        new DailyReward(3,30000,"M1"),
        new DailyReward(4,50000,null),
        new DailyReward(5,80000,"K03"),
        new DailyReward(6,120000,null),
        new DailyReward(7,300000,"A3")
    };

    // ============ 工具 ============
    public static Loot rollLoot(String tier, double luck) {
        int idx = tierIndex(tier);
        double[] rates = DROP_RATE[idx];
        double total = 0;
        double[] weights = new double[7];
        for (int i = 0; i < 7; i++) {
            weights[i] = rates[i] * (i >= 4 ? luck : 1);
            total += weights[i];
        }
        double r = Math.random() * total;
        int lv = 1;
        double acc = 0;
        for (int i = 0; i < 7; i++) {
            acc += weights[i];
            if (r < acc) { lv = i + 1; break; }
        }
        List<Loot> pool = new ArrayList<>();
        for (Loot l : ALL_LOOT) if (l.level == lv) pool.add(l);
        return pool.isEmpty() ? null : pool.get((int)(Math.random() * pool.size()));
    }

    public static Weapon findWeapon(String id) {
        for (Weapon w : WEAPONS) if (w.id.equals(id)) return w;
        return null;
    }
    public static Melee findMelee(String id) {
        for (Melee m : MELEES) if (m.id.equals(id)) return m;
        return null;
    }
    public static Armor findArmor(String id) {
        for (Armor a : ARMORS) if (a.id.equals(id)) return a;
        return null;
    }
    public static Armor findHelmet(String id) {
        for (Armor h : HELMETS) if (h.id.equals(id)) return h;
        return null;
    }
    public static Med findMed(String id) {
        for (Med m : MEDS) if (m.id.equals(id)) return m;
        return null;
    }
    public static Ammo findAmmo(String id) {
        for (Ammo a : AMMO_TYPES) if (a.id.equals(id)) return a;
        return null;
    }
    public static Part findPart(String id) {
        for (Part p : PARTS) if (p.id.equals(id)) return p;
        return null;
    }
}