package com.gunmu.town;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.screen.LobbyScreen;

import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends Activity {

    public static MainActivity instance;
    public GameState state;
    private FrameLayout root;
    private static final String CRASH_PREF = "gunmu_crash";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // 全局异常捕获（在 super 之前注册）
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                getSharedPreferences(CRASH_PREF, MODE_PRIVATE)
                        .edit()
                        .putString("last_crash", sw.toString())
                        .apply();
            } catch (Exception ignored) {}
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(10);
        });

        super.onCreate(savedInstanceState);
        instance = this;

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();

        state = Save.load(this);

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0A0D08);
        setContentView(root);

        // 显示上次崩溃日志
        showLastCrashIfAny();

        initFirstMails();
        showLobby();
    }

    private void showLastCrashIfAny() {
        try {
            SharedPreferences sp = getSharedPreferences(CRASH_PREF, MODE_PRIVATE);
            String crash = sp.getString("last_crash", null);
            if (crash != null && !crash.isEmpty()) {
                sp.edit().clear().apply();
                ScrollView sv = new ScrollView(this);
                TextView tv = new TextView(this);
                tv.setText("上次崩溃：\n\n" + crash);
                tv.setTextSize(11);
                tv.setPadding(30, 30, 30, 30);
                sv.addView(tv);
                new AlertDialog.Builder(this)
                        .setTitle("崩溃日志（截图发我）")
                        .setView(sv)
                        .setPositiveButton("知道了", null)
                        .show();
            }
        } catch (Exception ignored) {}
    }

    public void showLobby() {
        root.removeAllViews();
        LobbyScreen lobby = new LobbyScreen(this);
        root.addView(lobby.getView());
    }

    public void showScreen(View v) {
        root.removeAllViews();
        root.addView(v);
    }

    private void hideSystemUI() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { Save.save(this, state); } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try { Save.save(this, state); } catch (Exception ignored) {}
    }

    @Override
    public void onBackPressed() {
        showLobby();
    }

    private void initFirstMails() {
        try {
            if (state.mails == null || state.mails.isEmpty()) {
                state.mails.add(new GameState.Mail("欢迎来到棍母小镇", 100000, null));
                state.mails.add(new GameState.Mail("新手礼包", 0, "starter"));
                state.mails.add(new GameState.Mail("开服补偿", 50000, null));
                Save.save(this, state);
            }
        } catch (Exception ignored) {}
    }
}