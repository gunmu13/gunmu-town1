package com.gunmu.town;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.screen.LobbyScreen;

public class MainActivity extends Activity {

    public static MainActivity instance;
    public GameState state;
    private FrameLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;

        // 全屏 + 常亮
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUI();

        // 读取存档
        state = Save.load(this);

        // 根容器
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0A0D08);
        setContentView(root);

        // 首次发邮件
        initFirstMails();

        // 进入大厅
        showLobby();
    }

    /** 进入大厅 */
    public void showLobby() {
        root.removeAllViews();
        LobbyScreen lobby = new LobbyScreen(this);
        root.addView(lobby.getView());
    }

    /** 通用切换：替换整个 root */
    public void showScreen(View v) {
        root.removeAllViews();
        root.addView(v);
    }

    /** 隐藏系统 UI（沉浸式横屏） */
    private void hideSystemUI() {
        View decor = getWindow().getDecorView();
        decor.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
              | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_FULLSCREEN
              | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
              | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
              | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        );
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Save.save(this, state);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Save.save(this, state);
    }

    @Override
    public void onBackPressed() {
        // 返回键直接回大厅
        showLobby();
    }

    /** 初始化新手邮件 */
    private void initFirstMails() {
        if (state.mails == null || state.mails.isEmpty()) {
            state.mails.add(new GameState.Mail("欢迎来到棍母小镇", 100000, null));
            state.mails.add(new GameState.Mail("新手礼包", 0, "starter"));
            state.mails.add(new GameState.Mail("开服补偿", 50000, null));
            Save.save(this, state);
        }
    }
}