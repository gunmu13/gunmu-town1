package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.util.UI;

/** 地图选择 */
public class MapScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;

    public MapScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        root.addView(UI.topbar(ctx, () -> act.showLobby(), "选择地图",
                "携带价值 " + UI.fmt(s.equipValue())));

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12));

        for (GameData.MapDef m : GameData.MAPS) {
            list.addView(buildMapCard(m));
        }

        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private View buildMapCard(GameData.MapDef m) {
        boolean locked = !s.unlockedMaps.contains(m.id);
        LobbyScreen.MapTheme theme = LobbyScreen.getTheme(m.id);

        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(UI.round(theme.bg, theme.accent, UI.dp(ctx, 3), UI.dp(ctx, 8)));
        card.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 20), UI.dp(ctx, 16), UI.dp(ctx, 20));

        MapCardTitleView titleView = new MapCardTitleView(ctx, theme, m.desc, locked);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 140));
        card.addView(titleView, tlp);

        if (!locked) {
            LinearLayout btnRow = new LinearLayout(ctx);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            brp.topMargin = UI.dp(ctx, 14);
            btnRow.setLayoutParams(brp);
            addDiffBtn(btnRow, m, "normal", "普通 ×1.0", theme);
            addDiffBtn(btnRow, m, "hard", "困难 ×1.5", theme);
            addDiffBtn(btnRow, m, "lockdown", "封锁 ×2.5", theme);
            card.addView(btnRow);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 14);
        card.setLayoutParams(lp);

        if (locked) card.setAlpha(0.4f);
        return card;
    }

    private void addDiffBtn(LinearLayout row, GameData.MapDef map,
                            String diff, String label, LobbyScreen.MapTheme theme) {
        GameData.Difficulty d = findDiff(diff);
        boolean locked = s.equipValue() < d.minValue;

        Button b = new Button(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(locked ? 0xFF666666 : theme.bright);
        b.setBackground(UI.round(theme.bg, locked ? UI.BORDER : theme.accent,
                UI.dp(ctx, 2), UI.dp(ctx, 4)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            if (s.equipValue() < d.minValue) {
                new AlertDialog.Builder(ctx)
                        .setMessage(d.name + " 难度需携带价值 ≥ " + UI.fmt(d.minValue))
                        .setPositiveButton("好", null).show();
                return;
            }
            act.showScreen(new RaidScreen(act, map, d).getView());
        });
        row.addView(b);
    }

    private GameData.Difficulty findDiff(String id) {
        for (GameData.Difficulty d : GameData.DIFFICULTY) if (d.id.equals(id)) return d;
        return GameData.DIFFICULTY[0];
    }

    /** 地图卡标题（每个地图不同风格） */
    static class MapCardTitleView extends View {
        private final LobbyScreen.MapTheme theme;
        private final String desc;
        private final boolean locked;
        private Paint titleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint decoP = new Paint(Paint.ANTI_ALIAS_FLAG);

        public MapCardTitleView(Context c, LobbyScreen.MapTheme t, String d, boolean l) {
            super(c);
            theme = t; desc = d; locked = l;
            titleP.setTextAlign(Paint.Align.CENTER);
            titleP.setFakeBoldText(true);
            subP.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int W = getWidth(), H = getHeight();
            float cy = H / 2f;

            decoP.setColor((theme.accent & 0x00FFFFFF) | 0x30000000);
            if (theme.style == 1) {
                Path path = new Path();
                path.moveTo(0, H);
                for (int x = 0; x <= W; x += 60) {
                    path.lineTo(x + 30, H - 40 - (x % 120 == 0 ? 30 : 0));
                    path.lineTo(x + 60, H);
                }
                c.drawPath(path, decoP);
            } else if (theme.style == 2) {
                decoP.setStrokeWidth(3);
                for (int i = -H; i < W + H; i += 24) {
                    c.drawLine(i, H, i + H, 0, decoP);
                }
            } else {
                decoP.setColor((theme.accent & 0x00FFFFFF) | 0x20000000);
                for (int x = 20; x < W - 40; x += 80) {
                    c.drawRect(x, H - 30, x + 50, H, decoP);
                    c.drawRect(x + 10, H - 45, x + 40, H - 30, decoP);
                }
            }

            titleP.setColor(theme.bright);
            titleP.setTextSize(W / 12f);
            titleP.setShadowLayer(15, 0, 0, theme.accent);
            c.drawText(theme.title, W / 2f, cy - 5, titleP);
            titleP.setShadowLayer(0, 0, 0, 0);

            subP.setColor(theme.subtitle);
            subP.setTextSize(W / 34f);
            c.drawText(desc + (locked ? " · 未解锁" : ""), W / 2f, cy + 30, subP);

            decoP.setColor(theme.accent);
            decoP.setStrokeWidth(2);
            float lineW = W * 0.25f;
            c.drawLine(W / 2f - lineW, cy - 40, W / 2f + lineW, cy - 40, decoP);
            c.drawLine(W / 2f - lineW, cy + 50, W / 2f + lineW, cy + 50, decoP);
        }
    }
}