package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.util.UI;

public class MapScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;

    public MapScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        root.addView(UI.topbar(ctx, () -> act.showLobby(), "选择地图",
                "战备价值 " + UI.fmt(s.equipValue())));

        // 顶部提示
        TextView hint = UI.tv(ctx,
                "战备值 = 携带装备总价 · 难度越高要求越高",
                11, UI.GRAY);
        hint.setPadding(UI.dp(ctx, 14), UI.dp(ctx, 6), UI.dp(ctx, 14), UI.dp(ctx, 6));
        root.addView(hint);

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 6), UI.dp(ctx, 12), UI.dp(ctx, 12));

        for (GameData.MapDef m : GameData.MAPS) {
            list.addView(buildMapCard(m));
        }

        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private View buildMapCard(GameData.MapDef m) {
        // 不再有解锁检查，所有地图都能进
        LobbyScreen.MapTheme theme = LobbyScreen.getTheme(m.id);

        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(UI.round(theme.bg, theme.accent, UI.dp(ctx, 3), UI.dp(ctx, 8)));
        card.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 20), UI.dp(ctx, 16), UI.dp(ctx, 20));

        MapCardTitleView titleView = new MapCardTitleView(ctx, theme, m.desc);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 140));
        card.addView(titleView, tlp);

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brp.topMargin = UI.dp(ctx, 14);
        btnRow.setLayoutParams(brp);
        addDiffBtn(btnRow, m, "normal", "普通 ×1.0", theme, 0);
        addDiffBtn(btnRow, m, "hard", "困难 ×1.5", theme, 50000);
        addDiffBtn(btnRow, m, "lockdown", "封锁 ×2.5", theme, 150000);
        card.addView(btnRow);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 14);
        card.setLayoutParams(lp);

        return card;
    }

    private void addDiffBtn(LinearLayout row, GameData.MapDef map,
                            String diff, String label,
                            LobbyScreen.MapTheme theme, int needValue) {
        GameData.Difficulty d = findDiff(diff);
        boolean locked = s.equipValue() < needValue;

        Button b = new Button(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(locked ? 0xFF888888 : theme.bright);
        b.setBackground(UI.round(theme.bg, locked ? UI.BORDER : theme.accent,
                UI.dp(ctx, 2), UI.dp(ctx, 4)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> {
            if (s.equipValue() < needValue) {
                new AlertDialog.Builder(ctx)
                        .setTitle("战备不足")
                        .setMessage("进入 " + d.name + " 难度\n需要战备价值 ≥ "
                                + UI.fmt(needValue) + "\n当前：" + UI.fmt(s.equipValue()))
                        .setPositiveButton("好", null).show();
                return;
            }
            act.showScreen(new RaidScreen(act, map, d).getView());
        });
        row.addView(b);
    }

    private GameData.Difficulty findDiff(String id) {
        for (GameData.Difficulty d : GameData.DIFFICULTY) if (d.id.equals(id)) return d;
        return GameData.DIFFICULTY[0];
    }

    static class MapCardTitleView extends View {
        private final LobbyScreen.MapTheme theme;
        private final String desc;
        private Paint titleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint decoP = new Paint(Paint.ANTI_ALIAS_FLAG);

        public MapCardTitleView(Context c, LobbyScreen.MapTheme t, String d) {
            super(c);
            theme = t; desc = d;
            titleP.setTextAlign(Paint.Align.CENTER);
            titleP.setFakeBoldText(true);
            subP.setTextAlign(Paint.Align.CENTER);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            int W = getWidth(), H = getHeight();
            float cy = H / 2f;

            decoP.setColor((theme.accent & 0x00FFFFFF) | 0x30000000);
            if (theme.style == 1) {
                Path path = new Path();
                path.moveTo(0, H);
                for (int x = 0; x <= W; x += 60) {
                    path.lineTo(x + 30, H - 40 - (x % 120 == 0 ? 30 : 0));
                    path.lineTo(x + 60, H);
                }
                c.drawPath(path, decoP);
            } else if (theme.style == 2) {
                decoP.setStrokeWidth(3);
                for (int i = -H; i < W + H; i += 24) {
                    c.drawLine(i, H, i + H, 0, decoP);
                }
            } else {
                decoP.setColor((theme.accent & 0x00FFFFFF) | 0x20000000);
                for (int x = 20; x < W - 40; x += 80) {
                    c.drawRect(x, H - 30, x + 50, H, decoP);
                    c.drawRect(x + 10, H - 45, x + 40, H - 30, decoP);
                }
            }

            titleP.setColor(theme.bright);
            titleP.setTextSize(W / 12f);
            titleP.setShadowLayer(15, 0, 0, theme.accent);
            c.drawText(theme.title, W / 2f, cy - 5, titleP);
            titleP.setShadowLayer(0, 0, 0, 0);

            subP.setColor(theme.subtitle);
            subP.setTextSize(W / 34f);
            c.drawText(desc, W / 2f, cy + 30, subP);

            decoP.setColor(theme.accent);
            decoP.setStrokeWidth(2);
            float lineW = W * 0.25f;
            c.drawLine(W / 2f - lineW, cy - 40, W / 2f + lineW, cy - 40, decoP);
            c.drawLine(W / 2f - lineW, cy + 50, W / 2f + lineW, cy + 50, decoP);
        }
    }
}