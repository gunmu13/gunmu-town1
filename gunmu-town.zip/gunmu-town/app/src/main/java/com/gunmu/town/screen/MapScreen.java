package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.util.UI;

/** 地图选择 */
public class MapScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;

    public MapScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        root.addView(UI.topbar(ctx, () -> act.showLobby(), "选择地图",
                "携带价值 " + UI.fmt(s.equipValue())));

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12));

        for (GameData.MapDef m : GameData.MAPS) {
            list.addView(buildMapCard(m));
        }

        scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private LinearLayout buildMapCard(GameData.MapDef m) {
        boolean locked = !s.unlockedMaps.contains(m.id);

        LinearLayout card = UI.card(ctx);
        card.setBackground(UI.round(UI.PANEL, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));

        TextView name = UI.tv(ctx, m.name, 24, UI.ORANGE);
        name.setGravity(Gravity.CENTER);
        card.addView(name);

        TextView desc = UI.tv(ctx, m.desc + (locked ? " · 未解锁" : ""), 12, UI.GRAY);
        desc.setGravity(Gravity.CENTER);
        card.addView(desc);

        if (!locked) {
            LinearLayout btnRow = new LinearLayout(ctx);
            btnRow.setOrientation(LinearLayout.HORIZONTAL);
            btnRow.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            brp.topMargin = UI.dp(ctx, 12);
            btnRow.setLayoutParams(brp);

            addDiffBtn(btnRow, m, "normal", "普通 ×1.0");
            addDiffBtn(btnRow, m, "hard", "困难 ×1.5");
            addDiffBtn(btnRow, m, "lockdown", "封锁 ×2.5");

            card.addView(btnRow);
        }

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 12);
        card.setLayoutParams(lp);

        if (locked) card.setAlpha(0.4f);
        return card;
    }

    private void addDiffBtn(LinearLayout row, GameData.MapDef map, String diff, String label) {
        GameData.Difficulty d = findDiff(diff);
        boolean locked = s.equipValue() < d.minValue;

        Button b = new Button(ctx);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(locked ? 0xFF666666 : UI.ORANGE);
        b.setBackground(UI.round(UI.BG, locked ? UI.BORDER : UI.ORANGE,
                UI.dp(ctx, 1), UI.dp(ctx, 4)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        b.setLayoutParams(lp);

        b.setOnClickListener(v -> {
            if (s.equipValue() < d.minValue) {
                new AlertDialog.Builder(ctx)
                        .setMessage(d.name + " 难度需携带价值 ≥ " + UI.fmt(d.minValue))
                        .setPositiveButton("好", null).show();
                return;
            }
            act.showScreen(new RaidScreen(act, map, d).getView());
        });

        row.addView(b);
    }

    private GameData.Difficulty findDiff(String id) {
        for (GameData.Difficulty d : GameData.DIFFICULTY) if (d.id.equals(id)) return d;
        return GameData.DIFFICULTY[0];
    }
}