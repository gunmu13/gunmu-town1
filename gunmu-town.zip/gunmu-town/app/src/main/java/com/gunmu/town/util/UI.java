package com.gunmu.town.util;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gunmu.town.MainActivity;

/** 通用 UI 工具 */
public class UI {

    public static final int BG = 0xFF0A0D08;
    public static final int PANEL = 0xFF141A10;
    public static final int ORANGE = 0xFFC8742A;
    public static final int GOLD = 0xFFFFD700;
    public static final int GREEN = 0xFF4CAF50;
    public static final int RED = 0xFFFF3B3B;
    public static final int GRAY = 0xFF8A8578;
    public static final int TEXT = 0xFFD8D4C4;
    public static final int BORDER = 0xFF444444;

    public static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable round(int fill, int stroke, int strokeW, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        if (strokeW > 0) d.setStroke(strokeW, stroke);
        d.setCornerRadius(radius);
        return d;
    }

    public static TextView tv(Context c, String text, float size, int color) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    public static Button btn(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(BG);
        b.setBackground(round(ORANGE, 0, 0, dp(c, 4)));
        return b;
    }

    public static Button smallBtn(Context c, String text) {
        Button b = btn(c, text);
        b.setTextSize(12);
        b.setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6));
        return b;
    }

    /** 顶部标题栏 */
    public static LinearLayout topbar(Context c, Runnable onBack, String title, String right) {
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(c, 12), dp(c, 8), dp(c, 12), dp(c, 8));
        bar.setBackgroundColor(0xFF1A201A);

        Button back = smallBtn(c, "◀ 返回");
        back.setOnClickListener(v -> { if (onBack != null) onBack.run(); });
        bar.addView(back);

        TextView t = tv(c, title, 18, ORANGE);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tp.leftMargin = dp(c, 12);
        t.setLayoutParams(tp);
        t.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(t);

        if (right != null) bar.addView(tv(c, right, 12, GOLD));
        return bar;
    }

    /** 主按钮 */
    public static Button primaryBtn(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(BG);
        b.setBackground(round(GREEN, 0, 0, dp(c, 4)));
        return b;
    }

    /** 危险按钮 */
    public static Button dangerBtn(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setBackground(round(0xFFC62828, 0, 0, dp(c, 4)));
        return b;
    }

    /** 空心按钮 */
    public static Button outlineBtn(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(ORANGE);
        b.setBackground(round(PANEL, ORANGE, dp(c, 1), dp(c, 4)));
        return b;
    }

    /** 卡片 */
    public static LinearLayout card(Context c) {
        LinearLayout ll = new LinearLayout(c);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12));
        ll.setBackground(round(PANEL, BORDER, dp(c, 1), dp(c, 6)));
        return ll;
    }

    /** 刷新顶栏 */
    public static void refreshTopbar(TextView money, TextView wh, TextView lvl,
                                     TextView kills, TextView rank) {
        GameState s = MainActivity.instance.state;
        if (money != null) money.setText(fmt(s.money));
        if (wh != null) wh.setText(String.valueOf(s.warehouse.size()));
        if (lvl != null) lvl.setText("Lv." + s.level + " · EXP " + s.exp + "/"
                + GameState.expToNext(s.level));
        if (kills != null) kills.setText(String.valueOf(s.totalKills));
        if (rank != null) rank.setText(s.rankName());
    }

    public static String fmt(int n) {
        return String.format(java.util.Locale.US, "%,d", n);
    }
}