package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

import java.util.ArrayList;
import java.util.List;

public class RaidScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private final GameData.MapDef map;
    private final GameData.Difficulty diff;

    private GameView gameView;
    private FrameLayout root;
    private FrameLayout searchOverlay;
    private FrameLayout bagOverlay;
    private TextView timerView, lootView, killView, ammoView, hpText;
    private View hpFill;
    private LinearLayout medRow;
    private boolean over = false;

    public RaidScreen(MainActivity a, GameData.MapDef m, GameData.Difficulty d) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
        this.map = m;
        this.diff = d;
    }

    public View getView() {
        if (s.weapon == null && s.melee == null) {
            GameData.Melee k = GameData.MELEES[0];
            GameState.Item it = new GameState.Item();
            it.uid = "U" + System.nanoTime();
            it.id = k.id; it.type = "melee"; it.name = k.name;
            it.price = k.price; it.icon = "🔪";
            it.dmg = k.dmg; it.rate = k.rate; it.range = k.range;
            s.melee = it;
        }

        root = new FrameLayout(ctx);
        root.setBackgroundColor(0xFF0A0D08);

        gameView = new GameView(ctx);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout topBar = new LinearLayout(ctx);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 8), UI.dp(ctx, 12), UI.dp(ctx, 8));
        topBar.setBackgroundColor(0x80000000);
        timerView = UI.tv(ctx, "05:00", 14, UI.ORANGE); topBar.addView(timerView);
        lootView = UI.tv(ctx, "  🪙 0", 14, UI.GOLD); topBar.addView(lootView);
        killView = UI.tv(ctx, "  🎯 0", 14, UI.RED); topBar.addView(killView);
        ammoView = UI.tv(ctx, "  🔫 0/0", 14, UI.ORANGE); topBar.addView(ammoView);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
        tlp.topMargin = UI.dp(ctx, 8);
        root.addView(topBar, tlp);

        Button bagBtn = UI.smallBtn(ctx, "🎒 背包");
        bagBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        bagBtn.setTextColor(UI.ORANGE);
        bagBtn.setOnClickListener(v -> openBag());
        FrameLayout.LayoutParams blp2 = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp2.gravity = Gravity.LEFT | Gravity.TOP;
        blp2.leftMargin = UI.dp(ctx, 12);
        blp2.topMargin = UI.dp(ctx, 56);
        root.addView(bagBtn, blp2);

        LinearLayout bottomCenter = new LinearLayout(ctx);
        bottomCenter.setOrientation(LinearLayout.VERTICAL);
        bottomCenter.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout hpBar = new FrameLayout(ctx);
        hpBar.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 12)));
        hpBar.setLayoutParams(new LinearLayout.LayoutParams(UI.dp(ctx, 240), UI.dp(ctx, 22)));
        hpFill = new View(ctx);
        hpFill.setBackground(UI.round(UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpFill.setLayoutParams(new FrameLayout.LayoutParams(UI.dp(ctx, 240), UI.dp(ctx, 22)));
        hpBar.addView(hpFill);
        hpText = UI.tv(ctx, "100 / 100", 12, Color.WHITE);
        hpText.setGravity(Gravity.CENTER);
        hpBar.addView(hpText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bottomCenter.addView(hpBar);
        medRow = new LinearLayout(ctx);
        medRow.setOrientation(LinearLayout.HORIZONTAL);
        medRow.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = UI.dp(ctx, 6);
        medRow.setLayoutParams(mlp);
        bottomCenter.addView(medRow);
        refreshMeds();
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = UI.dp(ctx, 24);
        root.addView(bottomCenter, blp);

        Button exBtn = UI.primaryBtn(ctx, "🚁 撤离");
        exBtn.setBackground(UI.round(0xE64CAF50, 0, 0, UI.dp(ctx, 8)));
        exBtn.setOnClickListener(v -> gameView.tryExtract());
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.gravity = Gravity.RIGHT | Gravity.TOP;
        elp.rightMargin = UI.dp(ctx, 16);
        elp.topMargin = UI.dp(ctx, 60);
        root.addView(exBtn, elp);

        Button rBtn = UI.smallBtn(ctx, "R 换弹");
        rBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        rBtn.setTextColor(UI.ORANGE);
        rBtn.setOnClickListener(v -> gameView.reload());
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 240);
        rlp.bottomMargin = UI.dp(ctx, 40);
        root.addView(rBtn, rlp);

        gameView.setListener(new GameView.Listener() {
            @Override
            public void onHud(int hp, int maxHp, int loot, int kills,
                              int magAmmo, int magSize, int ammo, int timeLeft) {
                updateHud(hp, maxHp, loot, kills, magAmmo, magSize, ammo, timeLeft);
            }
            @Override
            public void onEnd(boolean success) { endRaid(success); }
            @Override
            public void onMedChanged() { refreshMeds(); }
            @Override
            public void onOpenContainer(GameView.Box box) { showSearchPanel(box); }
        });

        return root;
    }

    private int backpackSlots() {
        if (s.backpack == null) return 4;
        try { return Integer.parseInt(s.backpack.slot); } catch (Exception e) { return 4; }
    }

    private int usedSlots() {
        int used = 0;
        for (GameState.Item it : gameView.backpack) used += GameData.lootSize(it.level);
        return used;
    }

    private void refreshMeds() {
        if (medRow == null) return;
        medRow.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = UI.tv(ctx, i < s.meds.size() ? s.meds.get(i).icon : "➕", 22, UI.GOLD);
            tv.setGravity(Gravity.CENTER);
            tv.setBackground(UI.round(0xCC0D0F0C,
                    i < s.meds.size() ? UI.ORANGE : UI.BORDER,
                    UI.dp(ctx, 2), UI.dp(ctx, 8)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
            lp.leftMargin = UI.dp(ctx, 4); lp.rightMargin = UI.dp(ctx, 4);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> gameView.useMed(idx));
            medRow.addView(tv);
        }
    }

    private void updateHud(int hp, int maxHp, int loot, int kills,
                           int magAmmo, int magSize, int ammo, int timeLeft) {
        if (timerView == null) return;
        int m = timeLeft / 60, sec = timeLeft % 60;
        timerView.setText(String.format("%02d:%02d", m, sec));
        lootView.setText("  🪙 " + UI.fmt(loot));
        killView.setText("  🎯 " + kills);
        if (s.weapon != null) ammoView.setText("  🔫 " + magAmmo + "/" + magSize + " (" + ammo + ")");
        else ammoView.setText("  🔪");
        int hpPct = maxHp > 0 ? (int)(hp * 100.0 / maxHp) : 0;
        if (hpPct < 0) hpPct = 0; if (hpPct > 100) hpPct = 100;
        FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) hpFill.getLayoutParams();
        flp.width = (int)(UI.dp(ctx, 240) * hpPct / 100.0);
        hpFill.setLayoutParams(flp);
        hpFill.setBackground(UI.round(hpPct < 30 ? UI.RED : UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpText.setText(hp + " / " + maxHp);
    }

    private void openBag() {
        if (bagOverlay != null) return;
        gameView.pauseMovement();

        bagOverlay = new FrameLayout(ctx);
        bagOverlay.setBackgroundColor(0xCC000000);
        bagOverlay.setClickable(true);

        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(UI.round(0x1A201A, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        panel.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 560), ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER;
        panel.setLayoutParams(plp);

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        int slots = backpackSlots();
        int used = usedSlots();
        TextView title = UI.tv(ctx,
                (s.backpack != null ? s.backpack.icon + " " + s.backpack.name : "🎒 背包")
                        + "  (" + used + "/" + slots + " 格)", 18, UI.GOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        header.addView(title);
        TextView closeTv = UI.tv(ctx, "✕ 关闭", 14, UI.ORANGE);
        closeTv.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 6), UI.dp(ctx, 10), UI.dp(ctx, 6));
        closeTv.setOnClickListener(v -> closeBag());
        header.addView(closeTv);
        panel.addView(header);

        View line = new View(ctx);
        line.setBackgroundColor(UI.ORANGE);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 2));
        llp.topMargin = UI.dp(ctx, 8); llp.bottomMargin = UI.dp(ctx, 8);
        line.setLayoutParams(llp);
        panel.addView(line);

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout contentWrapper = new LinearLayout(ctx);
        contentWrapper.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(contentWrapper);

        if (gameView.backpack.isEmpty()) {
            TextView empty = UI.tv(ctx, "背包是空的", 14, UI.GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, UI.dp(ctx, 40), 0, UI.dp(ctx, 40));
            contentWrapper.addView(empty);
        } else {
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            int usedCol = 0;
            for (final GameState.Item it : gameView.backpack) {
                int size = GameData.lootSize(it.level);
                LinearLayout cell = new LinearLayout(ctx);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setBackground(UI.round(UI.PANEL, colorOf(it), UI.dp(ctx, 2), UI.dp(ctx, 4)));
                cell.addView(UI.tv(ctx, it.icon != null ? it.icon : "❔", 22, UI.TEXT));
                TextView nm = UI.tv(ctx, it.name, 9, UI.TEXT);
                nm.setGravity(Gravity.CENTER);
                nm.setSingleLine(true);
                cell.addView(nm);
                cell.addView(UI.tv(ctx, size + "格", 9, UI.GOLD));

                int cellW = (int)(UI.dp(ctx, 72) * size + UI.dp(ctx, 6) * (size - 1));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cellW, UI.dp(ctx, 72));
                lp.setMargins(UI.dp(ctx, 3), UI.dp(ctx, 3), UI.dp(ctx, 3), UI.dp(ctx, 3));
                cell.setLayoutParams(lp);

                cell.setOnClickListener(v -> {
                    new AlertDialog.Builder(ctx)
                            .setTitle("丢弃 " + it.name + "？")
                            .setPositiveButton("丢弃", (d, w) -> {
                                gameView.backpack.remove(it);
                                gameView.lootValue -= it.price;
                                gameView.notifyHud();
                                closeBag();
                                openBag();
                            })
                            .setNegativeButton("取消", null)
                            .show();
                });

                row.addView(cell);
                usedCol += size;
                if (usedCol >= 6) {
                    contentWrapper.addView(row);
                    row = new LinearLayout(ctx);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    usedCol = 0;
                }
            }
            if (row.getChildCount() > 0) contentWrapper.addView(row);
        }

        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 300)));

        bagOverlay.addView(panel);
        root.addView(bagOverlay);
    }

    private void closeBag() {
        if (bagOverlay != null) {
            root.removeView(bagOverlay);
            bagOverlay = null;
            gameView.resumeMovement();
        }
    }

    private int colorOf(GameState.Item it) {
        if (it.level == 7) return UI.GOLD;
        switch (it.level) {
            case 6: return 0xFFFF3B3B;
            case 5: return 0xFFFF8C2A;
            case 4: return 0xFFA45CFF;
            case 3: return 0xFF3D8BFD;
            case 2: return 0xFF4CAF50;
            default: return UI.BORDER;
        }
    }

    private void showSearchPanel(GameView.Box box) {
        if (searchOverlay != null) return;
        gameView.pauseMovement();

        searchOverlay = new FrameLayout(ctx);
        searchOverlay.setBackgroundColor(0xCC000000);
        searchOverlay.setClickable(true);

        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(UI.round(0x1A201A, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        panel.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 520), ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER;
        panel.setLayoutParams(plp);

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        int slots = backpackSlots();
        int used = usedSlots();
        TextView title = UI.tv(ctx, box.tpl.icon + " " + box.tpl.name
                + "  (背包 " + used + "/" + slots + ")", 18, UI.GOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        header.addView(title);
        TextView closeTv = UI.tv(ctx, "✕ 关闭", 14, UI.ORANGE);
        closeTv.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 6), UI.dp(ctx, 10), UI.dp(ctx, 6));
        closeTv.setOnClickListener(v -> closeSearchPanel());
        header.addView(closeTv);
        panel.addView(header);

        View line = new View(ctx);
        line.setBackgroundColor(UI.ORANGE);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 2));
        llp.topMargin = UI.dp(ctx, 8); llp.bottomMargin = UI.dp(ctx, 8);
        line.setLayoutParams(llp);
        panel.addView(line);

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout itemList = new LinearLayout(ctx);
        itemList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(itemList);

        if (box.lootItems == null || box.lootItems.isEmpty()) {
            TextView empty = UI.tv(ctx, "空空如也...", 14, UI.GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, UI.dp(ctx, 40), 0, UI.dp(ctx, 40));
            itemList.addView(empty);
        } else {
            for (int i = 0; i < box.lootItems.size(); i++) {
                itemList.addView(buildLootRow(box.lootItems.get(i), box));
            }
        }

        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 260)));

        LinearLayout footer = new LinearLayout(ctx);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams flp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp2.topMargin = UI.dp(ctx, 10);
        footer.setLayoutParams(flp2);

        Button takeAll = UI.primaryBtn(ctx, "全部拾取");
        takeAll.setOnClickListener(v -> {
            if (box.lootItems != null) {
                for (int i = box.lootItems.size() - 1; i >= 0; i--) {
                    GameState.Item it = box.lootItems.get(i);
                    if (gameView.tryPickup(it)) box.lootItems.remove(i);
                }
                closeSearchPanel();
            }
        });
        footer.addView(takeAll);
        panel.addView(footer);

        searchOverlay.addView(panel);
        root.addView(searchOverlay);
    }

    private LinearLayout buildLootRow(final GameState.Item it, final GameView.Box box) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 10), UI.dp(ctx, 12), UI.dp(ctx, 10));
        row.setBackground(UI.round(0xFF141A10, UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 4)));
        row.addView(UI.tv(ctx, it.icon != null ? it.icon : "❔", 24, UI.TEXT));
        LinearLayout info = new LinearLayout(ctx);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        info.addView(UI.tv(ctx, it.name, 14, UI.GOLD));
        info.addView(UI.tv(ctx, "Lv" + it.level + " · " + GameData.lootSize(it.level)
                + " 格 · " + UI.fmt(it.price) + " 币", 11, UI.GRAY));
        row.addView(info);
        Button take = UI.smallBtn(ctx, "拾取");
        take.setOnClickListener(v -> {
            if (gameView.tryPickup(it)) {
                box.lootItems.remove(it);
                closeSearchPanel();
                showSearchPanel(box);
            }
        });
        row.addView(take);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 6);
        row.setLayoutParams(lp);
        return row;
    }

    private void closeSearchPanel() {
        if (searchOverlay != null) {
            root.removeView(searchOverlay);
            searchOverlay = null;
            gameView.resumeMovement();
        }
    }

    private void endRaid(boolean success) {
        if (over) return;
        over = true;
        closeSearchPanel();
        closeBag();
        s.raids++;
        s.totalLoot += gameView.lootValue;
        GameState.BattleRecord r = new GameState.BattleRecord();
        r.success = success; r.map = map.name;
        r.kills = gameView.kills; r.loot = gameView.lootValue;

        if (success) {
            s.extracts++;
            s.rankPoints += 10;
            for (GameState.Item it : gameView.backpack) s.addToWarehouse(it);
            if (gameView.lootValue > s.bestLoot) s.bestLoot = gameView.lootValue;
            for (GameState.Quest q : s.quests) {
                if (q.done) continue;
                if ("q1".equals(q.id)) q.progress = Math.min(q.target, q.progress + 1);
                if (q.progress >= q.target) {
                    q.done = true; s.money += q.reward;
                    if ("q1".equals(q.id) && !s.unlockedMaps.contains("mine"))
                        s.unlockedMaps.add("mine");
                }
            }
        } else {
            s.deaths++;
            s.rankPoints = Math.max(0, s.rankPoints - 5);
            s.weapon = null; s.melee = null; s.armor = null; s.helmet = null;
            s.meds.clear(); s.ammo = 0;
        }
        s.questLog.add(r);
        if (s.questLog.size() > 50) s.questLog.remove(0);
        Save.save(ctx, s);

        AlertDialog.Builder b = new AlertDialog.Builder(ctx);
        b.setTitle(success ? "✅ 撤离成功" : "❌ 任务失败");
        String msg = success
                ? "带回 " + gameView.backpack.size() + " 件物资\n总价值：" + UI.fmt(gameView.lootValue) + "\n击杀：" + gameView.kills
                : "你在 " + map.name + " 倒下了\n本次击杀：" + gameView.kills;
        b.setMessage(msg);
        b.setCancelable(false);
        b.setPositiveButton("返回大厅", (d, w) -> act.showLobby());
        b.show();
    }

    public class GameView extends View {

        public interface Listener {
            void onHud(int hp, int maxHp, int loot, int kills, int magAmmo, int magSize, int ammo, int timeLeft);
            void onEnd(boolean success);
            void onMedChanged();
            void onOpenContainer(Box box);
        }

        private static final int WORLD = 2400;
        private static final float BOUND_R = 1100f;

        public float px = WORLD / 2f, py = WORLD / 2f;
        public int hp = 100, maxHp = 100;
        public int magAmmo, magSize, ammo = s.ammo;
        public int timeLeft = 300;
        public int lootValue = 0, kills = 0;
        public List<GameState.Item> backpack = new ArrayList<>();
        public boolean success = false;
        private float outTimer = 0f;
        private boolean outOfBounds = false;

        public class Enemy {
            public GameData.Enemy tpl;
            public float x, y;
            public int hp;
            public boolean alive = true;
            public long lastShoot = 0;
            public boolean alert = false;
        }
        public class Box {
            public GameData.Container tpl;
            public float x, y;
            public boolean searched = false;
            public List<GameState.Item> lootItems;
        }
        public class Bullet {
            public float x, y, vx, vy, life;
        }
        public class Wall {
            public float x, y, w, h;
        }
        public class Ray {
            public float x1, y1, x2, y2;
            public float life;
        }
        public class Decor {
            public int type;
            public float x, y;
        }

        public List<Enemy> enemies = new ArrayList<>();
        public List<Box> boxes = new ArrayList<>();
        public List<Bullet> bullets = new ArrayList<>();
        public List<Wall> walls = new ArrayList<>();
        public List<Ray> rays = new ArrayList<>();
        public List<Decor> decors = new ArrayList<>();
        public float ex = WORLD / 2f, ey = 200f;

        private float moveCx = 0, moveCy = 0;
        private float moveDx = 0, moveDy = 0;
        private float aimCx = 0, aimCy = 0;
        private float aimDx = 0, aimDy = 0;
        private float fireCx = 0, fireCy = 0, fireR = 0;
        private boolean firing = false;
        private float facingX = 1, facingY = 0;
        private float camX = 0, camY = 0;
        private boolean inited = false;
        private boolean paused = false;

        private Listener listener;
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Handler handler = new Handler(Looper.getMainLooper());

        private long lastTick = 0, lastSecond = 0, lastFire = 0;
        private boolean running = false;
        private Runnable ticker;

        public GameView(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(UI.dp(c, 3));
            textP.setColor(Color.WHITE);
            textP.setTextSize(UI.dp(c, 20));
            textP.setTextAlign(Paint.Align.CENTER);
            initWorld();
        }

        public void setListener(Listener l) {
            this.listener = l;
            running = true;
            lastTick = System.nanoTime();
            ticker = new Runnable() {
                @Override
                public void run() {
                    if (!running) return;
                    long now = System.nanoTime();
                    float dt = (now - lastTick) / 1_000_000_000f;
                    lastTick = now;
                    if (dt > 0.1f) dt = 0.1f;
                    try {
                        if (!paused) update(dt);
                        invalidate();
                    } catch (Exception e) { e.printStackTrace(); }
                    handler.postDelayed(this, 16);
                }
            };
            handler.post(ticker);
        }

        public void pauseMovement() { paused = true; moveDx = 0; moveDy = 0; firing = false; }
        public void resumeMovement() { paused = false; }
        public void notifyHud() {
            if (listener != null) listener.onHud(hp, maxHp, lootValue, kills, magAmmo, magSize, s.ammo, timeLeft);
        }

        public boolean tryPickup(GameState.Item it) {
            int slots = backpackSlots();
            int used = 0;
            for (GameState.Item x : backpack) used += GameData.lootSize(x.level);
            int size = GameData.lootSize(it.level);
            if (used + size > slots) {
                new AlertDialog.Builder(ctx)
                        .setMessage("背包已满！(" + used + "/" + slots + ")")
                        .setPositiveButton("好", null)
                        .show();
                return false;
            }
            backpack.add(it);
            lootValue += it.price;
            notifyHud();
            return true;
        }

        public void pickupItem(GameState.Item it) { tryPickup(it); }

        private void initWorld() {
            try {
                px = WORLD / 2f; py = WORLD / 2f;
                ex = WORLD / 2f; ey = 200f;
                buildHouse(400, 400, 400, 300);
                buildHouse(1600, 400, 400, 300);
                buildHouse(400, 1700, 400, 300);
                buildHouse(1600, 1700, 400, 300);
                for (int i = 0; i < 60; i++) {
                    Decor d = new Decor();
                    d.type = 0;
                    d.x = 100 + (float)(Math.random() * (WORLD - 200));
                    d.y = 100 + (float)(Math.random() * (WORLD - 200));
                    if (insideAnyHouse(d.x, d.y)) continue;
                    decors.add(d);
                }
                for (int i = 0; i < 30; i++) {
                    Decor d = new Decor();
                    d.type = 1;
                    d.x = 100 + (float)(Math.random() * (WORLD - 200));
                    d.y = 100 + (float)(Math.random() * (WORLD - 200));
                    if (insideAnyHouse(d.x, d.y)) continue;
                    decors.add(d);
                }
                int cnt = diff.eMin + (int) (Math.random() * (diff.eMax - diff.eMin + 1));
                cnt = (int) (cnt * map.enMul);
                for (int i = 0; i < cnt; i++) {
                    Enemy e = new Enemy();
                    e.tpl = GameData.ENEMIES[(int) (Math.random() * GameData.ENEMIES.length)];
                    for (int tries = 0; tries < 20; tries++) {
                        e.x = 150 + (float)(Math.random() * (WORLD - 300));
                        e.y = 150 + (float)(Math.random() * (WORLD - 300));
                        if (!hitsWall(e.x, e.y, 20)) break;
                    }
                    e.hp = e.tpl.hp;
                    enemies.add(e);
                }
                if (diff.boss) {
                    Enemy e = new Enemy();
                    e.tpl = GameData.BOSS;
                    e.x = 1200; e.y = 800;
                    e.hp = e.tpl.hp;
                    enemies.add(e);
                }
                addBoxAt(500, 500); addBoxAt(700, 500); addBoxAt(500, 620); addBoxAt(700, 620);
                addBoxAt(1700, 500); addBoxAt(1900, 500); addBoxAt(1700, 620); addBoxAt(1900, 620);
                addBoxAt(500, 1800); addBoxAt(700, 1800); addBoxAt(500, 1920); addBoxAt(700, 1920);
                addBoxAt(1700, 1800); addBoxAt(1900, 1800); addBoxAt(1700, 1920); addBoxAt(1900, 1920);
                addBoxAt(1200, 500); addBoxAt(1200, 1900);
                addBoxAt(500, 1200); addBoxAt(1900, 1200); addBoxAt(1200, 1200);
                addBoxAt(800, 800); addBoxAt(1600, 800); addBoxAt(800, 1600); addBoxAt(1600, 1600);
                if (s.weapon != null) { magSize = s.weapon.mag; magAmmo = magSize; }
            } catch (Exception e) { e.printStackTrace(); }
        }

        private void addBoxAt(float x, float y) {
            Box b = new Box();
            b.tpl = GameData.CONTAINERS[(int) (Math.random() * GameData.CONTAINERS.length)];
            b.x = x; b.y = y;
            b.lootItems = new ArrayList<>();
            int n = 2 + (int)(Math.random() * 3);
            for (int j = 0; j < n; j++) {
                GameData.Loot drop = GameData.rollLoot(b.tpl.tier, map.lootMul);
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime() + j;
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    b.lootItems.add(it);
                }
            }
            boxes.add(b);
        }

        private void buildHouse(float hx, float hy, float hw, float hh) {
            float t = 20f;
            Wall w1 = new Wall(); w1.x = hx; w1.y = hy; w1.w = 150; w1.h = t; walls.add(w1);
            Wall w2 = new Wall(); w2.x = hx + 250; w2.y = hy; w2.w = hw - 250; w2.h = t; walls.add(w2);
            Wall w3 = new Wall(); w3.x = hx; w3.y = hy + hh - t; w3.w = hw; w3.h = t; walls.add(w3);
            Wall w4 = new Wall(); w4.x = hx; w4.y = hy; w4.w = t; w4.h = hh; walls.add(w4);
            Wall w5 = new Wall(); w5.x = hx + hw - t; w5.y = hy; w5.w = t; w5.h = hh; walls.add(w5);
        }

        private boolean insideAnyHouse(float x, float y) {
            float[][] houses = {{400,400},{1600,400},{400,1700},{1600,1700}};
            for (float[] h : houses) {
                if (x > h[0] && x < h[0] + 400 && y > h[1] && y < h[1] + 300) return true;
            }
            return false;
        }

        private boolean hitsWall(float x, float y, float r) {
            for (Wall w : walls) {
                if (x + r > w.x && x - r < w.x + w.w && y + r > w.y && y - r < w.y + w.h) return true;
            }
            return false;
        }

        private boolean hitsEntity(float x, float y, float r, Enemy self) {
            for (Enemy e : enemies) {
                if (e == self || !e.alive) continue;
                if (Math.hypot(e.x - x, e.y - y) < r * 2) return true;
            }
            return false;
        }

        public void reload() {
            if (s.weapon == null || s.ammo <= 0) return;
            int need = magSize - magAmmo;
            int take = Math.min(need, s.ammo);
            magAmmo += take; s.ammo -= take;
            notifyHud();
        }

        public void useMed(int idx) {
            if (idx < 0 || idx >= s.meds.size()) return;
            GameState.Item it = s.meds.get(idx);
            int heal = (int) (it.heal * maxHp);
            hp = Math.min(maxHp, hp + heal);
            s.meds.remove(idx);
            Save.save(ctx, s);
            if (listener != null) listener.onMedChanged();
            notifyHud();
        }

        public void tryExtract() {
            float d = (float) Math.hypot(ex - px, ey - py);
            if (d > 150) return;
            success = true;
            endGame();
        }

        private void update(float dt) {
            long now = System.currentTimeMillis();
            if (now - lastSecond >= 1000) {
                lastSecond = now;
                timeLeft--;
                if (timeLeft <= 0) { success = false; endGame(); return; }
                notifyHud();
            }
            float speed = (s.weapon == null) ? 220 : 180;
            float nx = px + moveDx * speed * dt;
            float ny = py + moveDy * speed * dt;
            if (!hitsWall(nx, py, 18)) px = nx;
            if (!hitsWall(px, ny, 18)) py = ny;
            px = Math.max(30, Math.min(WORLD - 30, px));
            py = Math.max(30, Math.min(WORLD - 30, py));

            float distFromCenter = (float) Math.hypot(px - WORLD/2f, py - WORLD/2f);
            if (distFromCenter > BOUND_R) {
                outOfBounds = true; outTimer += dt;
                if (outTimer >= 5f) { success = false; endGame(); return; }
            } else {
                outOfBounds = false; outTimer = 0f;
            }

            camX = px - getWidth() / 2f;
            camY = py - getHeight() / 2f;

            for (int i = bullets.size() - 1; i >= 0; i--) {
                Bullet b = bullets.get(i);
                float bx2 = b.x + b.vx * dt;
                float by2 = b.y + b.vy * dt;
                if (hitsWall(bx2, by2, 4)) { bullets.remove(i); continue; }
                b.x = bx2; b.y = by2;
                b.life -= dt;
                if (b.life <= 0) bullets.remove(i);
            }
            for (int i = rays.size() - 1; i >= 0; i--) {
                rays.get(i).life -= dt;
                if (rays.get(i).life <= 0) rays.remove(i);
            }

            for (Enemy e : enemies) {
                if (!e.alive) continue;
                float dx = px - e.x, dy = py - e.y;
                float d = (float) Math.hypot(dx, dy);
                if (d < 1500 && d > 0.1f) {
                    e.alert = true;
                    if (d > 120) {
                        float sdx = dx / d * 90 * dt;
                        float sdy = dy / d * 90 * dt;
                        float nex = e.x + sdx;
                        float ney = e.y + sdy;
                        if (!hitsWall(nex, e.y, 18) && !hitsEntity(nex, e.y, 18, e)) e.x = nex;
                        if (!hitsWall(e.x, ney, 18) && !hitsEntity(e.x, ney, 18, e)) e.y = ney;
                    }
                    if (d < 450 && now - e.lastShoot > 1500) {
                        e.lastShoot = now;
                        Ray r = new Ray();
                        r.x1 = e.x; r.y1 = e.y;
                        r.x2 = px; r.y2 = py;
                        r.life = 0.2f;
                        rays.add(r);
                        if (Math.random() < 0.8) {
                            int dmg = e.tpl.dmg;
                            double red = 0;
                            if (s.armor != null) red += s.armor.red;
                            if (s.helmet != null) red += s.helmet.red * 0.5;
                            dmg = (int) (dmg * (1 - Math.min(red, 0.85)));
                            hp -= dmg;
                            if (hp < maxHp * 0.3 && s.autoMed && !s.meds.isEmpty()) useMed(0);
                            if (hp <= 0) { hp = 0; success = false; endGame(); return; }
                            notifyHud();
                        }
                    }
                } else {
                    e.alert = false;
                }
            }

            if (firing) doFire(now);
        }

        private void doFire(long now) {
            if (s.weapon != null) {
                long interval = Math.max(60, 60000 / s.weapon.rate);
                if (now - lastFire < interval) return;
                lastFire = now;
                if (magAmmo <= 0) { reload(); return; }
                if (s.ammo <= 0 && magAmmo <= 0) return;
                magAmmo--;
                float bx = px + facingX * 40;
                float by = py + facingY * 40;
                Bullet b = new Bullet();
                b.x = bx; b.y = by;
                b.vx = facingX * 900;
                b.vy = facingY * 900;
                b.life = s.weapon.range / 900f;
                bullets.add(b);
                Enemy target = null;
                float best = Float.MAX_VALUE;
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float dx = e.x - bx, dy = e.y - by;
                    float d = (float) Math.hypot(dx, dy);
                    if (d > s.weapon.range) continue;
                    float dot = dx * facingX + dy * facingY;
                    if (dot < 0) continue;
                    float perp = Math.abs(dx * facingY - dy * facingX);
                    if (perp < 40 && d < best) { best = d; target = e; }
                }
                if (target != null) hitEnemy(target, s.weapon.dmg);
                notifyHud();
            } else {
                long interval = 400;
                if (now - lastFire < interval) return;
                lastFire = now;
                float bx = px + facingX * 40;
                float by = py + facingY * 40;
                int dmg = (s.melee != null) ? s.melee.dmg : 15;
                float range = (s.melee != null) ? s.melee.range : 60;
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float d = (float) Math.hypot(e.x - bx, e.y - by);
                    if (d < range + 30) { hitEnemy(e, dmg); break; }
                }
                notifyHud();
            }
        }

        private void hitEnemy(Enemy e, int dmg) {
            e.hp -= dmg;
            if (e.hp <= 0) {
                e.alive = false;
                kills++;
                s.kills++; s.totalKills++;
                GameData.Loot drop = GameData.rollLoot(e.tpl.dropTier, map.lootMul);
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    tryPickup(it);
                }
                if (e.tpl.id.equals("BOSS") && Math.random() < 0.7) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = "L-SP1"; it.type = "loot"; it.name = "镇长的金印章";
                    it.level = 6; it.price = 520000; it.icon = "🔱";
                    tryPickup(it);
                }
            }
        }

        private void endGame() {
            running = false;
            handler.removeCallbacks(ticker);
            if (listener != null) listener.onEnd(success);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            try {
                int W = getWidth(), H = getHeight();
                if (W <= 0 || H <= 0) return;
                c.drawColor(0xFF3A5A2A);
                float cx = WORLD / 2f - camX, cy = WORLD / 2f - camY;
                stroke.setColor(0x44FF0000);
                stroke.setStrokeWidth(UI.dp(ctx, 6));
                c.drawCircle(cx, cy, BOUND_R, stroke);
                for (Wall w : walls) {
                    float wx = w.x - camX, wy = w.y - camY;
                    if (wx < -100 || wx > W + 100 || wy < -100 || wy > H + 100) continue;
                    p.setColor(0xFF6A4A2A);
                    c.drawRect(wx, wy, wx + w.w, wy + w.h, p);
                    stroke.setColor(0xFF4A2A0A);
                    stroke.setStrokeWidth(UI.dp(ctx, 1));
                    c.drawRect(wx, wy, wx + w.w, wy + w.h, stroke);
                }
                float[][] houses = {{400,400},{1600,400},{400,1700},{1600,1700}};
                for (float[] h : houses) {
                    float wx = h[0] - camX, wy = h[1] - camY;
                    if (wx + 400 < -100 || wx > W + 100) continue;
                    p.setColor(0xFF8A6A4A);
                    c.drawRect(wx + 20, wy + 20, wx + 380, wy + 280, p);
                }
                for (Decor d : decors) {
                    float dx = d.x - camX, dy = d.y - camY;
                    if (dx < -60 || dx > W + 60 || dy < -60 || dy > H + 60) continue;
                    if (d.type == 0) {
                        p.setColor(0xFF1A3A1A); c.drawCircle(dx + 8, dy + 8, 24, p);
                        p.setColor(0xFF2E5A2E); c.drawCircle(dx, dy, 22, p);
                        p.setColor(0xFF4A7A3A); c.drawCircle(dx - 6, dy - 6, 14, p);
                    } else {
                        p.setColor(0xFF6A6A6A); c.drawCircle(dx, dy, 16, p);
                        p.setColor(0xFF8A8A8A); c.drawCircle(dx - 4, dy - 4, 8, p);
                    }
                }
                float sx = ex - camX, sy = ey - camY;
                p.setColor(0x304CAF50); c.drawCircle(sx, sy, 80, p);
                stroke.setColor(0xFF4CAF50); stroke.setStrokeWidth(UI.dp(ctx, 4));
                c.drawCircle(sx, sy, 80, stroke);
                textP.setColor(0xFF4CAF50); textP.setTextSize(UI.dp(ctx, 18));
                c.drawText("撤离", sx, sy + 6, textP);
                textP.setTextSize(UI.dp(ctx, 22));
                for (Box b : boxes) {
                    if (b.searched) continue;
                    float bx = b.x - camX, by = b.y - camY;
                    if (bx < -60 || bx > W + 60 || by < -60 || by > H + 60) continue;
                    p.setColor(0xFF2A2A1A);
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, p);
                    stroke.setColor(UI.ORANGE); stroke.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, stroke);
                    textP.setColor(Color.WHITE);
                    c.drawText(b.tpl.icon, bx, by + 8, textP);
                }
                for (Ray r : rays) {
                    p.setColor(0xFF8B0000); p.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawLine(r.x1 - camX, r.y1 - camY, r.x2 - camX, r.y2 - camY, p);
                    p.setColor(0xFFFF0000); p.setStrokeWidth(UI.dp(ctx, 1));
                    c.drawLine(r.x1 - camX, r.y1 - camY, r.x2 - camX, r.y2 - camY, p);
                }
                for (Bullet b : bullets) {
                    float bx = b.x - camX, by = b.y - camY;
                    if (bx < -50 || bx > W + 50 || by < -50 || by > H + 50) continue;
                    p.setColor(0x88FFD700); p.setStrokeWidth(UI.dp(ctx, 3));
                    c.drawLine(bx - b.vx * 0.04f, by - b.vy * 0.04f, bx, by, p);
                    p.setColor(0xFFFFF7C0);
                    c.drawCircle(bx, by, 4, p);
                }
                textP.setTextSize(UI.dp(ctx, 22));
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float ex2 = e.x - camX, ey2 = e.y - camY;
                    if (ex2 < -80 || ex2 > W + 80 || ey2 < -80 || ey2 > H + 80) continue;
                    p.setColor(e.tpl.id.equals("BOSS") ? 0xFFFFD700 : 0xFFFF3B3B);
                    c.drawCircle(ex2, ey2, 22, p);
                    p.setColor(0xFF300000);
                    c.drawRect(ex2 - 22, ey2 - 34, ex2 + 22, ey2 - 28, p);
                    p.setColor(0xFFFF3B3B);
                    c.drawRect(ex2 - 22, ey2 - 34, ex2 - 22 + 44f * e.hp / e.tpl.hp, ey2 - 28, p);
                    textP.setColor(Color.WHITE);
                    c.drawText(e.tpl.icon, ex2, ey2 + 8, textP);
                    if (e.alert) {
                        textP.setColor(0xFFFF3B3B);
                        c.drawText("!", ex2, ey2 - 44, textP);
                    }
                }
                float px2 = px - camX, py2 = py - camY;
                p.setColor(0xFFFFD700); c.drawCircle(px2, py2, 22, p);
                textP.setColor(Color.WHITE);
                c.drawText("🧍", px2, py2 + 8, textP);
                stroke.setColor(0xFFFFD700); stroke.setStrokeWidth(UI.dp(ctx, 3));
                c.drawLine(px2, py2, px2 + facingX * 45, py2 + facingY * 45, stroke);
                if (moveCx > 0) {
                    float mr = UI.dp(ctx, 60);
                    p.setColor(0x30000000); c.drawCircle(moveCx, moveCy, mr, p);
                    stroke.setColor(0xFFC8742A); stroke.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawCircle(moveCx, moveCy, mr, stroke);
                    p.setColor(0xFFC8742A);
                    c.drawCircle(moveCx + moveDx * mr, moveCy + moveDy * mr, UI.dp(ctx, 25), p);
                    p.setColor(0x30000000); c.drawCircle(aimCx, aimCy, mr, p);
                    stroke.setColor(0xFFFF5252);
                    c.drawCircle(aimCx, aimCy, mr, stroke);
                    p.setColor(0xFFFF5252);
                    c.drawCircle(aimCx + aimDx * mr, aimCy + aimDy * mr, UI.dp(ctx, 25), p);
                    p.setColor(firing ? 0xFFFF3B3B : 0xCC8A1A1A);
                    c.drawCircle(fireCx, fireCy, fireR, p);
                    stroke.setColor(0xFFFF3B3B);
                    c.drawCircle(fireCx, fireCy, fireR, stroke);
                    textP.setColor(0xFFFFEB3B);
                    textP.setTextSize(UI.dp(ctx, 28));
                    c.drawText("🔥", fireCx, fireCy + 10, textP);
                    textP.setTextSize(UI.dp(ctx, 12));
                    textP.setColor(0xFFFF5252);
                    c.drawText(s.weapon != null ? "开火" : "挥刀", fireCx, fireCy + fireR + 14, textP);
                }
                if (outOfBounds) {
                    p.setColor(0x66FF0000);
                    c.drawRect(0, 0, W, H, p);
                    textP.setColor(0xFFFFFFFF);
                    textP.setTextSize(UI.dp(ctx, 32));
                    textP.setShadowLayer(4, 2, 2, Color.BLACK);
                    c.drawText("⚠ 越界 " + String.format("%.1f", 5f - outTimer) + " 秒后死亡",
                            W / 2f, H / 2f, textP);
                    textP.setShadowLayer(0, 0, 0, 0);
                }
            } catch (Exception e) { e.printStackTrace(); }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            try {
                if (paused) return true;
                if (!inited) {
                    int W = getWidth(), H = getHeight();
                    if (W > 0 && H > 0) {
                        moveCx = UI.dp(ctx, 100);
                        moveCy = H - UI.dp(ctx, 100);
                        aimCx = W - UI.dp(ctx, 100);
                        aimCy = H - UI.dp(ctx, 100);
                        fireCx = W - UI.dp(ctx, 100);
                        fireCy = H - UI.dp(ctx, 240);
                        fireR = UI.dp(ctx, 46);
                        inited = true;
                    }
                }
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE
                        || action == MotionEvent.ACTION_POINTER_DOWN) {
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        float x = event.getX(i), y = event.getY(i);
                        float mr = UI.dp(ctx, 60);
                        if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 20)) {
                            firing = true;
                        } else if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 90)) {
                            float dx = x - moveCx, dy = y - moveCy;
                            float len = (float) Math.hypot(dx, dy);
                            if (len > mr) { dx = dx / len * mr; dy = dy / len * mr; }
                            moveDx = dx / mr; moveDy = dy / mr;
                        } else if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 90)) {
                            float dx = x - aimCx, dy = y - aimCy;
                            float len = (float) Math.hypot(dx, dy);
                            if (len > mr) { dx = dx / len * mr; dy = dy / len * mr; }
                            aimDx = dx / mr; aimDy = dy / mr;
                            float nlen = (float) Math.hypot(dx, dy);
                            if (nlen > 12) { facingX = dx / nlen; facingY = dy / nlen; }
                        }
                    }
                } else if (action == MotionEvent.ACTION_UP
                        || action == MotionEvent.ACTION_POINTER_UP
                        || action == MotionEvent.ACTION_CANCEL) {
                    int idx = event.getActionIndex();
                    float x = event.getX(idx), y = event.getY(idx);
                    if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 120)) { moveDx = 0; moveDy = 0; }
                    if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 120)) { aimDx = 0; aimDy = 0; }
                    if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 40)) firing = false;
                    float wx = x + camX, wy = y + camY;
                    for (Box b : boxes) {
                        if (b.searched) continue;
                        if (Math.hypot(b.x - wx, b.y - wy) < 50 && Math.hypot(b.x - px, b.y - py) < 120) {
                            b.searched = true;
                            if (listener != null) listener.onOpenContainer(b);
                            break;
                        }
                    }
                }
                return true;
            } catch (Exception e) { e.printStackTrace(); return true; }
        }
    }
}