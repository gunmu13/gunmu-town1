package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

import java.util.ArrayList;
import java.util.List;

public class RaidScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private final GameData.MapDef map;
    private final GameData.Difficulty diff;

    private GameView gameView;
    private TextView timerView, lootView, killView, ammoView, hpText;
    private View hpFill;
    private LinearLayout medRow;
    private boolean over = false;

    public RaidScreen(MainActivity a, GameData.MapDef m, GameData.Difficulty d) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
        this.map = m;
        this.diff = d;
    }

    public View getView() {
        if (s.weapon == null && s.melee == null) {
            GameData.Melee k = GameData.MELEES[0];
            GameState.Item it = new GameState.Item();
            it.uid = "U" + System.nanoTime();
            it.id = k.id; it.type = "melee"; it.name = k.name;
            it.price = k.price; it.icon = "🔪";
            it.dmg = k.dmg; it.rate = k.rate; it.range = k.range;
            s.melee = it;
        }

        FrameLayout root = new FrameLayout(ctx);
        root.setBackgroundColor(0xFF0A0D08);

        gameView = new GameView(ctx);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout topBar = new LinearLayout(ctx);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 8), UI.dp(ctx, 12), UI.dp(ctx, 8));
        topBar.setBackgroundColor(0x80000000);
        timerView = UI.tv(ctx, "05:00", 14, UI.ORANGE); topBar.addView(timerView);
        lootView = UI.tv(ctx, "  🪙 0", 14, UI.GOLD); topBar.addView(lootView);
        killView = UI.tv(ctx, "  🎯 0", 14, UI.RED); topBar.addView(killView);
        ammoView = UI.tv(ctx, "  🔫 0/0", 14, UI.ORANGE); topBar.addView(ammoView);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
        tlp.topMargin = UI.dp(ctx, 8);
        root.addView(topBar, tlp);

        LinearLayout bottomCenter = new LinearLayout(ctx);
        bottomCenter.setOrientation(LinearLayout.VERTICAL);
        bottomCenter.setGravity(Gravity.CENTER_HORIZONTAL);

        FrameLayout hpBar = new FrameLayout(ctx);
        hpBar.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 12)));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 240), UI.dp(ctx, 22));
        hpBar.setLayoutParams(hlp);

        hpFill = new View(ctx);
        hpFill.setBackground(UI.round(UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpFill.setLayoutParams(new FrameLayout.LayoutParams(UI.dp(ctx, 240), UI.dp(ctx, 22)));
        hpBar.addView(hpFill);

        hpText = UI.tv(ctx, "100 / 100", 12, Color.WHITE);
        hpText.setGravity(Gravity.CENTER);
        hpBar.addView(hpText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bottomCenter.addView(hpBar);

        medRow = new LinearLayout(ctx);
        medRow.setOrientation(LinearLayout.HORIZONTAL);
        medRow.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = UI.dp(ctx, 6);
        medRow.setLayoutParams(mlp);
        bottomCenter.addView(medRow);
        refreshMeds();

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = UI.dp(ctx, 24);
        root.addView(bottomCenter, blp);

        Button exBtn = UI.primaryBtn(ctx, "🚁 撤离");
        exBtn.setBackground(UI.round(0xE64CAF50, 0, 0, UI.dp(ctx, 8)));
        exBtn.setOnClickListener(v -> gameView.tryExtract());
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
        elp.rightMargin = UI.dp(ctx, 16);
        root.addView(exBtn, elp);

        Button rBtn = UI.smallBtn(ctx, "R 换弹");
        rBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        rBtn.setTextColor(UI.ORANGE);
        rBtn.setOnClickListener(v -> gameView.reload());
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 240);
        rlp.bottomMargin = UI.dp(ctx, 40);
        root.addView(rBtn, rlp);

        gameView.setListener(new GameView.Listener() {
            @Override
            public void onHud(int hp, int maxHp, int loot, int kills,
                              int magAmmo, int magSize, int ammo, int timeLeft) {
                updateHud(hp, maxHp, loot, kills, magAmmo, magSize, ammo, timeLeft);
            }
            @Override
            public void onEnd(boolean success) {
                endRaid(success);
            }
            @Override
            public void onMedChanged() {
                refreshMeds();
            }
        });

        return root;
    }

    private void refreshMeds() {
        if (medRow == null) return;
        medRow.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = UI.tv(ctx, i < s.meds.size() ? s.meds.get(i).icon : "➕", 22, UI.GOLD);
            tv.setGravity(Gravity.CENTER);
            tv.setBackground(UI.round(0xCC0D0F0C,
                    i < s.meds.size() ? UI.ORANGE : UI.BORDER,
                    UI.dp(ctx, 2), UI.dp(ctx, 8)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    UI.dp(ctx, 44), UI.dp(ctx, 44));
            lp.leftMargin = UI.dp(ctx, 4);
            lp.rightMargin = UI.dp(ctx, 4);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> gameView.useMed(idx));
            medRow.addView(tv);
        }
    }

    private void updateHud(int hp, int maxHp, int loot, int kills,
                           int magAmmo, int magSize, int ammo, int timeLeft) {
        if (timerView == null) return;
        int m = timeLeft / 60, sec = timeLeft % 60;
        timerView.setText(String.format("%02d:%02d", m, sec));
        lootView.setText("  🪙 " + UI.fmt(loot));
        killView.setText("  🎯 " + kills);
        if (s.weapon != null) {
            ammoView.setText("  🔫 " + magAmmo + "/" + magSize + " (" + ammo + ")");
        } else {
            ammoView.setText("  🔪");
        }
        int hpPct = maxHp > 0 ? (int)(hp * 100.0 / maxHp) : 0;
        if (hpPct < 0) hpPct = 0;
        if (hpPct > 100) hpPct = 100;
        FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) hpFill.getLayoutParams();
        flp.width = (int)(UI.dp(ctx, 240) * hpPct / 100.0);
        hpFill.setLayoutParams(flp);
        hpFill.setBackground(UI.round(hpPct < 30 ? UI.RED : UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpText.setText(hp + " / " + maxHp);
    }

    private void endRaid(boolean success) {
        if (over) return;
        over = true;
        s.raids++;
        s.totalLoot += gameView.lootValue;

        GameState.BattleRecord r = new GameState.BattleRecord();
        r.success = success; r.map = map.name;
        r.kills = gameView.kills; r.loot = gameView.lootValue;

        if (success) {
            s.extracts++;
            s.rankPoints += 10;
            for (GameState.Item it : gameView.backpack) s.addToWarehouse(it);
            if (gameView.lootValue > s.bestLoot) s.bestLoot = gameView.lootValue;
            for (GameState.Quest q : s.quests) {
                if (q.done) continue;
                if ("q1".equals(q.id)) q.progress = Math.min(q.target, q.progress + 1);
                if (q.progress >= q.target) {
                    q.done = true; s.money += q.reward;
                    if ("q1".equals(q.id) && !s.unlockedMaps.contains("mine"))
                        s.unlockedMaps.add("mine");
                }
            }
        } else {
            s.deaths++;
            s.rankPoints = Math.max(0, s.rankPoints - 5);
            s.weapon = null; s.melee = null; s.armor = null; s.helmet = null;
            s.meds.clear(); s.ammo = 0;
        }
        s.questLog.add(r);
        if (s.questLog.size() > 50) s.questLog.remove(0);
        Save.save(ctx, s);

        AlertDialog.Builder b = new AlertDialog.Builder(ctx);
        b.setTitle(success ? "✅ 撤离成功" : "❌ 任务失败");
        String msg = success
                ? "带回 " + gameView.backpack.size() + " 件物资\n总价值：" + UI.fmt(gameView.lootValue) + "\n击杀：" + gameView.kills
                : "你在 " + map.name + " 倒下了\n本次击杀：" + gameView.kills;
        b.setMessage(msg);
        b.setCancelable(false);
        b.setPositiveButton("返回大厅", (d, w) -> act.showLobby());
        b.show();
    }

    public class GameView extends View {
        public interface Listener {
            void onHud(int hp, int maxHp, int loot, int kills, int magAmmo, int magSize, int ammo, int timeLeft);
            void onEnd(boolean success);
            void onMedChanged();
        }

        private static final int WORLD = 4000;
        public float px = 2000, py = 2000;
        public int hp = 100, maxHp = 100;
        public int magAmmo, magSize, ammo = s.ammo;
        public int timeLeft = 300;
        public int lootValue = 0, kills = 0;
        public List<GameState.Item> backpack = new ArrayList<>();
        public boolean success = false;

        public class Enemy {
            public GameData.Enemy tpl;
            public float x, y;
            public int hp;
            public boolean alive = true;
            public long lastShoot = 0;
            public boolean alert = false;
        }
        public class Box {
            public GameData.Container tpl;
            public float x, y;
            public boolean searched = false;
        }
        public List<Enemy> enemies = new ArrayList<>();
        public List<Box> boxes = new ArrayList<>();
        public float ex = 0, ey = 0;

        private float moveCx = 0, moveCy = 0, moveDx = 0, moveDy = 0;
        private float aimCx = 0, aimCy = 0, aimDx = 0, aimDy = 0;
        private float fireCx = 0, fireCy = 0;
        private float fireR = 0;
        private boolean firing = false;
        private float facingX = 1, facingY = 0;
        private float camX = 0, camY = 0;
        private boolean inited = false;

        private Listener listener;
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Handler handler = new Handler(Looper.getMainLooper());

        private long lastTick = 0, lastSecond = 0, lastFire = 0;
        private boolean running = false;
        private Runnable ticker;

        public GameView(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(UI.dp(c, 3));
            textP.setColor(Color.WHITE);
            textP.setTextSize(UI.dp(c, 20));
            textP.setTextAlign(Paint.Align.CENTER);
            initWorld();
        }

        public void setListener(Listener l) {
            this.listener = l;
            running = true;
            lastTick = System.nanoTime();
            ticker = new Runnable() {
                @Override
                public void run() {
                    if (!running) return;
                    long now = System.nanoTime();
                    float dt = (now - lastTick) / 1_000_000_000f;
                    lastTick = now;
                    if (dt > 0.1f) dt = 0.1f;
                    try {
                        update(dt);
                        invalidate();
                    } catch (Exception e) { e.printStackTrace(); }
                    handler.postDelayed(this, 16);
                }
            };
            handler.post(ticker);
        }

        private void initWorld() {
            try {
                int cnt = diff.eMin + (int) (Math.random() * (diff.eMax - diff.eMin + 1));
                cnt = (int) (cnt * map.enMul);
                for (int i = 0; i < cnt; i++) {
                    Enemy e = new Enemy();
                    e.tpl = GameData.ENEMIES[(int) (Math.random() * GameData.ENEMIES.length)];
                    e.x = 300 + (float) (Math.random() * (WORLD - 600));
                    e.y = 300 + (float) (Math.random() * (WORLD - 600));
                    e.hp = e.tpl.hp;
                    enemies.add(e);
                }
                if (diff.boss) {
                    Enemy e = new Enemy();
                    e.tpl = GameData.BOSS;
                    e.x = 500 + (float) (Math.random() * (WORLD - 1000));
                    e.y = 500 + (float) (Math.random() * (WORLD - 1000));
                    e.hp = e.tpl.hp;
                    enemies.add(e);
                }
                int bc = (int) (20 * map.lootMul);
                for (int i = 0; i < bc; i++) {
                    Box b = new Box();
                    b.tpl = GameData.CONTAINERS[(int) (Math.random() * GameData.CONTAINERS.length)];
                    b.x = 200 + (float) (Math.random() * (WORLD - 400));
                    b.y = 200 + (float) (Math.random() * (WORLD - 400));
                    boxes.add(b);
                }
                ex = 400 + (float) (Math.random() * (WORLD - 800));
                ey = 400 + (float) (Math.random() * (WORLD - 800));
                if (s.weapon != null) { magSize = s.weapon.mag; magAmmo = magSize; }
            } catch (Exception e) { e.printStackTrace(); }
        }

        public void reload() {
            if (s.weapon == null || s.ammo <= 0) return;
            int need = magSize - magAmmo;
            int take = Math.min(need, s.ammo);
            magAmmo += take;
            s.ammo -= take;
            notifyHud();
        }

        public void useMed(int idx) {
            if (idx < 0 || idx >= s.meds.size()) return;
            GameState.Item it = s.meds.get(idx);
            int heal = (int) (it.heal * maxHp);
            hp = Math.min(maxHp, hp + heal);
            s.meds.remove(idx);
            Save.save(ctx, s);
            if (listener != null) listener.onMedChanged();
            notifyHud();
        }

        public void tryExtract() {
            float d = (float) Math.hypot(ex - px, ey - py);
            if (d > 150) return;
            success = true;
            endGame();
        }

        private void notifyHud() {
            if (listener != null) listener.onHud(hp, maxHp, lootValue, kills, magAmmo, magSize, s.ammo, timeLeft);
        }

        private void update(float dt) {
            long now = System.currentTimeMillis();
            if (now - lastSecond >= 1000) {
                lastSecond = now;
                timeLeft--;
                if (timeLeft <= 0) { success = false; endGame(); return; }
                notifyHud();
            }

            float speed = (s.weapon == null) ? 420 : 330;
            px += moveDx * speed * dt;
            py += moveDy * speed * dt;
            px = Math.max(30, Math.min(WORLD - 30, px));
            py = Math.max(30, Math.min(WORLD - 30, py));

            camX = px - getWidth() / 2f;
            camY = py - getHeight() / 2f;

            for (Enemy e : enemies) {
                if (!e.alive) continue;
                float dx = px - e.x, dy = py - e.y;
                float d = (float) Math.hypot(dx, dy);
                if (d < 700 && d > 0.1f) {
                    e.alert = true;
                    if (d > 90) {
                        e.x += dx / d * 90 * dt * 3;
                        e.y += dy / d * 90 * dt * 3;
                    }
                    if (d < 500 && now - e.lastShoot > 1400) {
                        e.lastShoot = now;
                        int dmg = e.tpl.dmg;
                        double red = 0;
                        if (s.armor != null) red += s.armor.red;
                        if (s.helmet != null) red += s.helmet.red * 0.5;
                        dmg = (int) (dmg * (1 - Math.min(red, 0.85)));
                        hp -= dmg;
                        if (hp < maxHp * 0.3 && s.autoMed && !s.meds.isEmpty()) useMed(0);
                        if (hp <= 0) { hp = 0; success = false; endGame(); return; }
                        notifyHud();
                    }
                } else {
                    e.alert = false;
                }
            }

            if (firing && s.weapon != null) doFire(now);
        }

        private void doFire(long now) {
            long interval = Math.max(60, 60000 / s.weapon.rate);
            if (now - lastFire < interval) return;
            lastFire = now;
            if (magAmmo <= 0) { reload(); return; }
            magAmmo--;

            float bx = px + facingX * 40;
            float by = py + facingY * 40;
            Enemy target = null;
            float best = Float.MAX_VALUE;
            for (Enemy e : enemies) {
                if (!e.alive) continue;
                float dx = e.x - bx, dy = e.y - by;
                float d = (float) Math.hypot(dx, dy);
                if (d > s.weapon.range) continue;
                float dot = dx * facingX + dy * facingY;
                if (dot < 0) continue;
                float perp = Math.abs(dx * facingY - dy * facingX);
                if (perp < 40 && d < best) { best = d; target = e; }
            }
            if (target != null) hitEnemy(target, s.weapon.dmg);
            notifyHud();
        }

        private void hitEnemy(Enemy e, int dmg) {
            e.hp -= dmg;
            if (e.hp <= 0) {
                e.alive = false;
                kills++;
                s.kills++; s.totalKills++;
                GameData.Loot drop = GameData.rollLoot(e.tpl.dropTier, map.lootMul);
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    backpack.add(it);
                    lootValue += drop.price;
                }
                if (e.tpl.id.equals("BOSS") && Math.random() < 0.7) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = "L-SP1"; it.type = "loot"; it.name = "镇长的金印章";
                    it.level = 6; it.price = 520000; it.icon = "🔱";
                    backpack.add(it);
                    lootValue += 520000;
                }
            }
        }

        private void endGame() {
            running = false;
            handler.removeCallbacks(ticker);
            if (listener != null) listener.onEnd(success);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            try {
                c.drawColor(0xFF0F1408);
                int W = getWidth(), H = getHeight();
                if (W <= 0 || H <= 0) return;

                p.setColor(0xFF1A201A);
                p.setStrokeWidth(2);
                int gs = 60;
                int startX = (int) (camX / gs) * gs;
                int startY = (int) (camY / gs) * gs;
                for (int x = startX; x < camX + W; x += gs) c.drawLine(x - camX, 0, x - camX, H, p);
                for (int y = startY; y < camY + H; y += gs) c.drawLine(0, y - camY, W, y - camY, p);

                float sx = ex - camX, sy = ey - camY;
                stroke.setColor(0xFF4CAF50);
                c.drawCircle(sx, sy, 80, stroke);
                textP.setColor(0xFF4CAF50);
                textP.setTextSize(UI.dp(ctx, 14));
                c.drawText("撤离", sx, sy + 6, textP);

                textP.setTextSize(UI.dp(ctx, 22));
                for (Box b : boxes) {
                    if (b.searched) continue;
                    float bx = b.x - camX, by = b.y - camY;
                    if (bx < -60 || bx > W + 60 || by < -60 || by > H + 60) continue;
                    p.setColor(0xFF2A2A1A);
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, p);
                    stroke.setColor(UI.ORANGE);
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, stroke);
                    textP.setColor(Color.WHITE);
                    c.drawText(b.tpl.icon, bx, by + 8, textP);
                }

                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float ex2 = e.x - camX, ey2 = e.y - camY;
                    if (ex2 < -80 || ex2 > W + 80 || ey2 < -80 || ey2 > H + 80) continue;
                    p.setColor(e.tpl.id.equals("BOSS") ? 0xFFFFD700 : 0xFFFF3B3B);
                    c.drawCircle(ex2, ey2, 22, p);
                    p.setColor(0xFF300000);
                    c.drawRect(ex2 - 22, ey2 - 34, ex2 + 22, ey2 - 28, p);
                    p.setColor(0xFFFF3B3B);
                    c.drawRect(ex2 - 22, ey2 - 34, ex2 - 22 + 44f * e.hp / e.tpl.hp, ey2 - 28, p);
                    textP.setColor(Color.WHITE);
                    c.drawText(e.tpl.icon, ex2, ey2 + 8, textP);
                    if (e.alert) {
                        textP.setColor(0xFFFF3B3B);
                        c.drawText("!", ex2, ey2 - 44, textP);
                    }
                }

                float px2 = px - camX, py2 = py - camY;
                p.setColor(0xFFFFD700);
                c.drawCircle(px2, py2, 22, p);
                textP.setColor(Color.WHITE);
                c.drawText("🧍", px2, py2 + 8, textP);
                stroke.setColor(0xFFFFD700);
                c.drawLine(px2, py2, px2 + facingX * 45, py2 + facingY * 45, stroke);

                if (moveCx > 0) {
                    p.setColor(0x30000000); c.drawCircle(moveCx, moveCy, UI.dp(ctx, 60), p);
                    stroke.setColor(0xFFC8742A); c.drawCircle(moveCx, moveCy, UI.dp(ctx, 60), stroke);
                    p.setColor(0xFFC8742A); c.drawCircle(moveCx + moveDx, moveCy + moveDy, UI.dp(ctx, 25), p);

                    p.setColor(0x30000000); c.drawCircle(aimCx, aimCy, UI.dp(ctx, 60), p);
                    stroke.setColor(0xFFFF5252); c.drawCircle(aimCx, aimCy, UI.dp(ctx, 60), stroke);
                    p.setColor(0xFFFF5252); c.drawCircle(aimCx + aimDx, aimCy + aimDy, UI.dp(ctx, 25), p);

                    p.setColor(firing ? 0xFFFF3B3B : 0xCC8A1A1A);
                    c.drawCircle(fireCx, fireCy, fireR, p);
                    stroke.setColor(0xFFFF3B3B);
                    c.drawCircle(fireCx, fireCy, fireR, stroke);
                    textP.setColor(0xFFFFEB3B);
                    textP.setTextSize(UI.dp(ctx, 28));
                    c.drawText("🔥", fireCx, fireCy + 10, textP);
                }
            } catch (Exception e) { e.printStackTrace(); }
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            try {
                if (!inited) {
                    int W = getWidth(), H = getHeight();
                    if (W > 0 && H > 0) {
                        moveCx = UI.dp(ctx, 100);
                        moveCy = H - UI.dp(ctx, 100);
                        aimCx = W - UI.dp(ctx, 100);
                        aimCy = H - UI.dp(ctx, 100);
                        fireCx = W - UI.dp(ctx, 190);
                        fireCy = H - UI.dp(ctx, 190);
                        fireR = UI.dp(ctx, 46);
                        inited = true;
                    }
                }
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE
                        || action == MotionEvent.ACTION_POINTER_DOWN) {
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        float x = event.getX(i), y = event.getY(i);
                        if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 90)) {
                            float dx = x - moveCx, dy = y - moveCy;
                            float len = (float) Math.hypot(dx, dy), max = UI.dp(ctx, 60);
                            if (len > max) { dx = dx / len * max; dy = dy / len * max; }
                            moveDx = dx; moveDy = dy;
                        } else if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 90)) {
                            float dx = x - aimCx, dy = y - aimCy;
                            float len = (float) Math.hypot(dx, dy), max = UI.dp(ctx, 60);
                            if (len > max) { dx = dx / len * max; dy = dy / len * max; }
                            aimDx = dx; aimDy = dy;
                            float nlen = (float) Math.hypot(dx, dy);
                            if (nlen > 12) { facingX = dx / nlen; facingY = dy / nlen; }
                        } else if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 20)) {
                            firing = true;
                        }
                    }
                } else if (action == MotionEvent.ACTION_UP
                        || action == MotionEvent.ACTION_POINTER_UP
                        || action == MotionEvent.ACTION_CANCEL) {
                    int idx = event.getActionIndex();
                    float x = event.getX(idx), y = event.getY(idx);
                    if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 120)) { moveDx = 0; moveDy = 0; }
                    if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 120)) { aimDx = 0; aimDy = 0; }
                    if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 40)) firing = false;

                    float wx = x + camX, wy = y + camY;
                    for (Box b : boxes) {
                        if (b.searched) continue;
                        if (Math.hypot(b.x - wx, b.y - wy) < 50 && Math.hypot(b.x - px, b.y - py) < 120) {
                            b.searched = true;
                            GameData.Loot drop = GameData.rollLoot(b.tpl.tier, map.lootMul);
                            if (drop != null) {
                                GameState.Item it = new GameState.Item();
                                it.uid = "U" + System.nanoTime();
                                it.id = drop.id; it.type = "loot"; it.name = drop.name;
                                it.level = drop.level; it.price = drop.price;
                                it.icon = drop.icon; it.cls = drop.cls;
                                backpack.add(it);
                                lootValue += drop.price;
                                notifyHud();
                            }
                        }
                    }
                }
                return true;
            } catch (Exception e) { e.printStackTrace(); return true; }
        }
    }
}