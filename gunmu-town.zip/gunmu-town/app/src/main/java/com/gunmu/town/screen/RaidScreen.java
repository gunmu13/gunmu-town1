package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

import java.util.ArrayList;
import java.util.List;

public class RaidScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private final GameData.MapDef map;
    private final GameData.Difficulty diff;

    private GameView gameView;
    private FrameLayout root;
    private FrameLayout searchOverlay;
    private FrameLayout bagOverlay;
    private TextView timerView, lootView, killView, ammoView, hpText, stamText, weatherView, eventView;
    private View hpFill, stamFill;
    private LinearLayout medRow;
    private boolean over = false;

    public RaidScreen(MainActivity a, GameData.MapDef m, GameData.Difficulty d) {
        this.act = a; this.ctx = a; this.s = a.state;
        this.map = m; this.diff = d;
    }

    public View getView() {
        if (s.weapon == null && s.melee == null) {
            GameData.Melee k = GameData.MELEES[0];
            GameState.Item it = new GameState.Item();
            it.uid = "U" + System.nanoTime();
            it.id = k.id; it.type = "melee"; it.name = k.name;
            it.price = k.price; it.icon = "🔪";
            it.dmg = k.dmg; it.rate = k.rate; it.range = k.range;
            s.melee = it;
        }

        int extraAmmo = s.baseLevel("U5") * 15;
        if (extraAmmo > 0) s.ammo += extraAmmo;

        root = new FrameLayout(ctx);
        root.setBackgroundColor(0xFF0A0D08);

        gameView = new GameView(ctx);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout topBar = new LinearLayout(ctx);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 8), UI.dp(ctx, 12), UI.dp(ctx, 8));
        topBar.setBackgroundColor(0x80000000);
        timerView = UI.tv(ctx, "05:00", 13, UI.ORANGE); topBar.addView(timerView);
        lootView = UI.tv(ctx, "  🪙 0", 13, UI.GOLD); topBar.addView(lootView);
        killView = UI.tv(ctx, "  🎯 0", 13, UI.RED); topBar.addView(killView);
        ammoView = UI.tv(ctx, "  🔫 0/0", 13, UI.ORANGE); topBar.addView(ammoView);
        weatherView = UI.tv(ctx, "", 13, 0xFF64B5F6); topBar.addView(weatherView);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
        tlp.topMargin = UI.dp(ctx, 8);
        root.addView(topBar, tlp);

        eventView = UI.tv(ctx, "", 14, 0xFFFF5252);
        eventView.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams evp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        evp.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
        evp.topMargin = UI.dp(ctx, 46);
        root.addView(eventView, evp);

        Button bagBtn = UI.smallBtn(ctx, "🎒");
        bagBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        bagBtn.setTextColor(UI.ORANGE);
        bagBtn.setOnClickListener(v -> openBag());
        FrameLayout.LayoutParams blp2 = new FrameLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
        blp2.gravity = Gravity.LEFT | Gravity.TOP;
        blp2.leftMargin = UI.dp(ctx, 12);
        blp2.topMargin = UI.dp(ctx, 56);
        root.addView(bagBtn, blp2);

        Button safeBtn = UI.smallBtn(ctx, "🔒");
        safeBtn.setBackground(UI.round(0xCC0D0F0C, 0xFFFFD700, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        safeBtn.setTextColor(0xFFFFD700);
        safeBtn.setOnClickListener(v -> openSafeBox());
        FrameLayout.LayoutParams sfp = new FrameLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
        sfp.gravity = Gravity.LEFT | Gravity.TOP;
        sfp.leftMargin = UI.dp(ctx, 62);
        sfp.topMargin = UI.dp(ctx, 56);
        root.addView(safeBtn, sfp);

        Button skillBtn = UI.smallBtn(ctx, "⚡");
        skillBtn.setBackground(UI.round(0xCC0D0F0C, 0xFF64B5F6, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        skillBtn.setTextColor(0xFF64B5F6);
        skillBtn.setOnClickListener(v -> gameView.castSkill());
        FrameLayout.LayoutParams sklp = new FrameLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
        sklp.gravity = Gravity.LEFT | Gravity.TOP;
        sklp.leftMargin = UI.dp(ctx, 112);
        sklp.topMargin = UI.dp(ctx, 56);
        root.addView(skillBtn, sklp);

        LinearLayout bottomCenter = new LinearLayout(ctx);
        bottomCenter.setOrientation(LinearLayout.VERTICAL);
        bottomCenter.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout stamBar = new FrameLayout(ctx);
        stamBar.setBackground(UI.round(0xCC0D0F0C, 0xFF3399FF, UI.dp(ctx, 2), UI.dp(ctx, 10)));
        stamBar.setLayoutParams(new LinearLayout.LayoutParams(UI.dp(ctx, 220), UI.dp(ctx, 12)));
        stamFill = new View(ctx);
        stamFill.setBackground(UI.round(0xFF3399FF, 0, 0, UI.dp(ctx, 8)));
        stamFill.setLayoutParams(new FrameLayout.LayoutParams(UI.dp(ctx, 220), UI.dp(ctx, 12)));
        stamBar.addView(stamFill);
        stamText = UI.tv(ctx, "体力", 9, Color.WHITE);
        stamText.setGravity(Gravity.CENTER);
        stamBar.addView(stamText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bottomCenter.addView(stamBar);

        FrameLayout hpBar = new FrameLayout(ctx);
        hpBar.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 12)));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(UI.dp(ctx, 240), UI.dp(ctx, 22));
        hlp.topMargin = UI.dp(ctx, 6);
        hpBar.setLayoutParams(hlp);
        hpFill = new View(ctx);
        hpFill.setBackground(UI.round(UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpFill.setLayoutParams(new FrameLayout.LayoutParams(UI.dp(ctx, 240), UI.dp(ctx, 22)));
        hpBar.addView(hpFill);
        hpText = UI.tv(ctx, "100 / 100", 12, Color.WHITE);
        hpText.setGravity(Gravity.CENTER);
        hpBar.addView(hpText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bottomCenter.addView(hpBar);
        medRow = new LinearLayout(ctx);
        medRow.setOrientation(LinearLayout.HORIZONTAL);
        medRow.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = UI.dp(ctx, 6);
        medRow.setLayoutParams(mlp);
        bottomCenter.addView(medRow);
        refreshMeds();
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = UI.dp(ctx, 24);
        root.addView(bottomCenter, blp);

        Button exBtn = UI.primaryBtn(ctx, "🚁");
        exBtn.setBackground(UI.round(0xE64CAF50, 0, 0, UI.dp(ctx, 8)));
        exBtn.setOnClickListener(v -> gameView.tryExtract());
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(UI.dp(ctx, 56), UI.dp(ctx, 44));
        elp.gravity = Gravity.RIGHT | Gravity.TOP;
        elp.rightMargin = UI.dp(ctx, 16);
        elp.topMargin = UI.dp(ctx, 56);
        root.addView(exBtn, elp);

        Button devBtn = UI.smallBtn(ctx, "🔧");
        devBtn.setBackground(UI.round(0xCC0D0F0C, 0xFFFF9800, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        devBtn.setTextColor(0xFFFF9800);
        devBtn.setOnClickListener(v -> openDevPanel());
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
        dlp.gravity = Gravity.RIGHT | Gravity.TOP;
        dlp.rightMargin = UI.dp(ctx, 16);
        dlp.topMargin = UI.dp(ctx, 104);
        root.addView(devBtn, dlp);

        Button rBtn = UI.smallBtn(ctx, "R");
        rBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        rBtn.setTextColor(UI.ORANGE);
        rBtn.setOnClickListener(v -> gameView.reload());
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
        rlp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 240);
        rlp.bottomMargin = UI.dp(ctx, 40);
        root.addView(rBtn, rlp);

        gameView.setListener(new GameView.Listener() {
            @Override public void onHud(int hp, int maxHp, int loot, int kills,
                                        int magAmmo, int magSize, int ammo, int timeLeft,
                                        int stamina, String weather) {
                updateHud(hp, maxHp, loot, kills, magAmmo, magSize, ammo, timeLeft, stamina, weather);
            }
            @Override public void onEnd(boolean success) { endRaid(success); }
            @Override public void onMedChanged() { refreshMeds(); }
            @Override public void onOpenContainer(GameView.Box box) { showSearchPanel(box); }
            @Override public void onEvent(String text) {
                if (eventView != null) {
                    eventView.setText(text);
                    eventView.postDelayed(new Runnable() {
                        @Override public void run() { eventView.setText(""); }
                    }, 3000);
                }
            }
        });
        return root;
    }

    private int backpackSlots() {
        if (s.backpack == null) return 4;
        try { return Integer.parseInt(s.backpack.slot); } catch (Exception e) { return 4; }
    }

    private int usedSlots() {
        int u = 0;
        for (GameState.Item it : gameView.backpack) u += GameData.lootSize(it.level);
        return u;
    }

    private void refreshMeds() {
        if (medRow == null) return;
        medRow.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = UI.tv(ctx, i < s.meds.size() ? s.meds.get(i).icon : "➕", 22, UI.GOLD);
            tv.setGravity(Gravity.CENTER);
            tv.setBackground(UI.round(0xCC0D0F0C,
                    i < s.meds.size() ? UI.ORANGE : UI.BORDER, UI.dp(ctx, 2), UI.dp(ctx, 8)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UI.dp(ctx, 44), UI.dp(ctx, 44));
            lp.leftMargin = UI.dp(ctx, 4); lp.rightMargin = UI.dp(ctx, 4);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> gameView.useMed(idx));
            medRow.addView(tv);
        }
    }

    private void updateHud(int hp, int maxHp, int loot, int kills,
                           int magAmmo, int magSize, int ammo, int timeLeft,
                           int stamina, String weather) {
        if (timerView == null) return;
        timerView.setText(String.format("%02d:%02d", timeLeft / 60, timeLeft % 60));
        lootView.setText("  🪙 " + UI.fmt(loot));
        killView.setText("  🎯 " + kills);
        if (s.weapon != null) ammoView.setText("  🔫 " + magAmmo + "/" + magSize + " (" + ammo + ")");
        else ammoView.setText("  🔪");
        weatherView.setText("  " + weather);
        int hpPct = maxHp > 0 ? (int)(hp * 100.0 / maxHp) : 0;
        if (hpPct < 0) hpPct = 0;
        if (hpPct > 100) hpPct = 100;
        FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) hpFill.getLayoutParams();
        flp.width = (int)(UI.dp(ctx, 240) * hpPct / 100.0);
        hpFill.setLayoutParams(flp);
        hpFill.setBackground(UI.round(hpPct < 30 ? UI.RED : UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        hpText.setText(hp + " / " + maxHp);
        int sp = (int) Math.max(0f, Math.min(100f, (float) stamina));
        FrameLayout.LayoutParams slp = (FrameLayout.LayoutParams) stamFill.getLayoutParams();
        slp.width = UI.dp(ctx, 220) * sp / 100;
        stamFill.setLayoutParams(slp);
        stamFill.setBackground(UI.round(sp < 20 ? 0xFFFF5252 : 0xFF3399FF, 0, 0, UI.dp(ctx, 8)));
        stamText.setText("体力 " + sp + "%");
    }

    private void openSafeBox() {
        gameView.pauseMovement();
        final FrameLayout overlay = new FrameLayout(ctx);
        overlay.setBackgroundColor(0xCC000000);
        overlay.setClickable(true);
        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(UI.round(0x1A201A, 0xFFFFD700, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        panel.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 500), ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER;
        panel.setLayoutParams(plp);
        int max = s.safeBoxSize() * s.safeBoxSize();
        panel.addView(UI.tv(ctx, "🔒 保险箱  (" + s.safeBoxUsed() + "/" + max + " 格)", 18, 0xFFFFD700));
        panel.addView(UI.tv(ctx, "死亡时保险箱内物品不丢失", 11, UI.GRAY));

        View line = new View(ctx);
        line.setBackgroundColor(0xFFFFD700);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 2));
        llp.topMargin = UI.dp(ctx, 8); llp.bottomMargin = UI.dp(ctx, 8);
        line.setLayoutParams(llp);
        panel.addView(line);

        if (s.safeBox.isEmpty()) panel.addView(UI.tv(ctx, "保险箱空着", 12, UI.GRAY));
        else for (GameState.Item it : s.safeBox) {
            panel.addView(UI.tv(ctx, it.icon + " " + it.name, 12, UI.TEXT));
        }

        if (!gameView.backpack.isEmpty()) {
            panel.addView(UI.tv(ctx, "背包内（点击放入）", 12, UI.ORANGE));
            ScrollView sv = new ScrollView(ctx);
            LinearLayout box = new LinearLayout(ctx);
            box.setOrientation(LinearLayout.VERTICAL);
            sv.addView(box);
            for (final GameState.Item it : new ArrayList<>(gameView.backpack)) {
                LinearLayout r = new LinearLayout(ctx);
                r.setOrientation(LinearLayout.HORIZONTAL);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 6), UI.dp(ctx, 8), UI.dp(ctx, 6));
                r.addView(UI.tv(ctx, it.icon + " " + it.name, 12, UI.TEXT));
                Button put = UI.smallBtn(ctx, "放入");
                put.setOnClickListener(v -> {
                    int used = s.safeBoxUsed();
                    int size = GameData.lootSize(it.level);
                    if (used + size > max) {
                        new AlertDialog.Builder(ctx).setMessage("保险箱空间不足")
                                .setPositiveButton("好", null).show();
                        return;
                    }
                    s.safeBox.add(it);
                    gameView.backpack.remove(it);
                    gameView.lootValue -= it.price;
                    gameView.notifyHud();
                    Save.save(ctx, s);
                    root.removeView(overlay);
                    gameView.resumeMovement();
                    openSafeBox();
                });
                r.addView(put);
                box.addView(r);
            }
            sv.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 160)));
            panel.addView(sv);
        }

        Button close = UI.smallBtn(ctx, "关闭");
        close.setOnClickListener(v -> {
            root.removeView(overlay);
            gameView.resumeMovement();
        });
        panel.addView(close);
        overlay.addView(panel);
        root.addView(overlay);
    }

    private void openBag() {
        if (bagOverlay != null) return;
        gameView.pauseMovement();
        bagOverlay = new FrameLayout(ctx);
        bagOverlay.setBackgroundColor(0xCC000000);
        bagOverlay.setClickable(true);
        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(UI.round(0x1A201A, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        panel.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 600), ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER;
        panel.setLayoutParams(plp);
        int slots = backpackSlots();
        int used = usedSlots();

        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = UI.tv(ctx,
                (s.backpack != null ? s.backpack.icon + " " + s.backpack.name : "🎒 背包")
                        + "  (" + used + "/" + slots + " 格)", 18, UI.GOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        header.addView(title);
        TextView closeTv = UI.tv(ctx, "✕", 16, UI.ORANGE);
        closeTv.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 6), UI.dp(ctx, 10), UI.dp(ctx, 6));
        closeTv.setOnClickListener(v -> closeBag());
        header.addView(closeTv);
        panel.addView(header);

        View line = new View(ctx);
        line.setBackgroundColor(UI.ORANGE);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 2));
        llp.topMargin = UI.dp(ctx, 8); llp.bottomMargin = UI.dp(ctx, 8);
        line.setLayoutParams(llp);
        panel.addView(line);

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout wrapper = new LinearLayout(ctx);
        wrapper.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(wrapper);

        if (gameView.backpack.isEmpty()) {
            TextView empty = UI.tv(ctx, "背包是空的", 14, UI.GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, UI.dp(ctx, 40), 0, UI.dp(ctx, 40));
            wrapper.addView(empty);
        } else {
            final int CELLS_PER_ROW = 6;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            int col = 0;
            for (final GameState.Item it : gameView.backpack) {
                int size = GameData.lootSize(it.level);
                LinearLayout cell = new LinearLayout(ctx);
                cell.setOrientation(LinearLayout.VERTICAL);
                cell.setGravity(Gravity.CENTER);
                cell.setBackground(UI.round(UI.PANEL, colorOf(it), UI.dp(ctx, 2), UI.dp(ctx, 4)));
                cell.addView(UI.tv(ctx, it.icon != null ? it.icon : "❔", 20, UI.TEXT));
                TextView nm = UI.tv(ctx, it.name, 8, UI.TEXT);
                nm.setGravity(Gravity.CENTER); nm.setSingleLine(true);
                cell.addView(nm);
                cell.addView(UI.tv(ctx, size + "格", 8, UI.GOLD));
                int cellW = (int)(UI.dp(ctx, 60) * size) + UI.dp(ctx, 4) * (size - 1);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cellW, UI.dp(ctx, 64));
                lp.setMargins(UI.dp(ctx, 2), UI.dp(ctx, 2), UI.dp(ctx, 2), UI.dp(ctx, 2));
                cell.setLayoutParams(lp);
                cell.setOnClickListener(v -> {
                    new AlertDialog.Builder(ctx)
                            .setTitle("丢弃 " + it.name + "？")
                            .setPositiveButton("丢弃", (d, w) -> {
                                gameView.dropItemOnGround(it);
                                closeBag();
                                openBag();
                            })
                            .setNegativeButton("取消", null).show();
                });
                if (col + size > CELLS_PER_ROW) {
                    wrapper.addView(row);
                    row = new LinearLayout(ctx);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    col = 0;
                }
                row.addView(cell);
                col += size;
                if (col >= CELLS_PER_ROW) {
                    wrapper.addView(row);
                    row = new LinearLayout(ctx);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    col = 0;
                }
            }
            if (row.getChildCount() > 0) wrapper.addView(row);
        }
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 320)));
        bagOverlay.addView(panel);
        root.addView(bagOverlay);
    }

    private void closeBag() {
        if (bagOverlay != null) {
            root.removeView(bagOverlay); bagOverlay = null;
            gameView.resumeMovement();
        }
    }

    private int colorOf(GameState.Item it) {
        if (it.level == 7) return UI.GOLD;
        switch (it.level) {
            case 6: return 0xFFFF3B3B;
            case 5: return 0xFFFF8C2A;
            case 4: return 0xFFA45CFF;
            case 3: return 0xFF3D8BFD;
            case 2: return 0xFF4CAF50;
            default: return UI.BORDER;
        }
    }

    private void showSearchPanel(final GameView.Box box) {
        if (searchOverlay != null) return;
        gameView.pauseMovement();
        searchOverlay = new FrameLayout(ctx);
        searchOverlay.setBackgroundColor(0xCC000000);
        searchOverlay.setClickable(true);
        LinearLayout panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(UI.round(0x1A201A, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        panel.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16), UI.dp(ctx, 16));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 540), ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.CENTER;
        panel.setLayoutParams(plp);
        int slots = backpackSlots();
        int used = usedSlots();
        LinearLayout header = new LinearLayout(ctx);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = UI.tv(ctx, box.tpl.icon + " " + box.tpl.name
                + "  (背包 " + used + "/" + slots + ")", 18, UI.GOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        header.addView(title);
        TextView closeTv = UI.tv(ctx, "✕", 16, UI.ORANGE);
        closeTv.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 6), UI.dp(ctx, 10), UI.dp(ctx, 6));
        closeTv.setOnClickListener(v -> closeSearchPanel());
        header.addView(closeTv);
        panel.addView(header);

        View line = new View(ctx);
        line.setBackgroundColor(UI.ORANGE);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 2));
        llp.topMargin = UI.dp(ctx, 8); llp.bottomMargin = UI.dp(ctx, 8);
        line.setLayoutParams(llp);
        panel.addView(line);

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout itemList = new LinearLayout(ctx);
        itemList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(itemList);

        if (box.lootItems == null || box.lootItems.isEmpty()) {
            TextView empty = UI.tv(ctx, "空空如也...", 14, UI.GRAY);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, UI.dp(ctx, 40), 0, UI.dp(ctx, 40));
            itemList.addView(empty);
        } else {
            for (int i = 0; i < box.lootItems.size(); i++) {
                itemList.addView(buildLootRow(box.lootItems.get(i), box));
            }
        }
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 280)));

        LinearLayout footer = new LinearLayout(ctx);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams flp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        flp2.topMargin = UI.dp(ctx, 10);
        footer.setLayoutParams(flp2);
        Button takeAll = UI.primaryBtn(ctx, "全部拾取");
        takeAll.setOnClickListener(v -> {
            if (box.lootItems != null) {
                for (int i = box.lootItems.size() - 1; i >= 0; i--) {
                    GameState.Item it = box.lootItems.get(i);
                    if (gameView.tryPickup(it)) box.lootItems.remove(i);
                }
                closeSearchPanel();
            }
        });
        footer.addView(takeAll);
        panel.addView(footer);
        searchOverlay.addView(panel);
        root.addView(searchOverlay);
    }

    private LinearLayout buildLootRow(final GameState.Item it, final GameView.Box box) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 10), UI.dp(ctx, 12), UI.dp(ctx, 10));
        row.setBackground(UI.round(0xFF141A10, UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 4)));
        row.addView(UI.tv(ctx, it.icon != null ? it.icon : "❔", 24, UI.TEXT));
        LinearLayout info = new LinearLayout(ctx);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        info.addView(UI.tv(ctx, it.name, 14, UI.GOLD));
        info.addView(UI.tv(ctx, "Lv" + it.level + " · " + GameData.lootSize(it.level)
                + " 格 · " + UI.fmt(it.price) + " 币", 11, UI.GRAY));
        row.addView(info);
        Button take = UI.smallBtn(ctx, "拾取");
        take.setOnClickListener(v -> {
            if (gameView.tryPickup(it)) {
                box.lootItems.remove(it);
                closeSearchPanel();
                showSearchPanel(box);
            }
        });
        row.addView(take);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx, 6);
        row.setLayoutParams(lp);
        return row;
    }

    private void closeSearchPanel() {
        if (searchOverlay != null) {
            root.removeView(searchOverlay); searchOverlay = null;
            gameView.resumeMovement();
        }
    }

    private void openDevPanel() {
        if (s.devMode) { showDropRateDialog(); return; }
        final EditText input = new EditText(ctx);
        input.setHint("输入开发者密码");
        input.setTextSize(14);
        new AlertDialog.Builder(ctx)
                .setTitle("🔧 开发者模式")
                .setView(input)
                .setPositiveButton("解锁", (d, w) -> {
                    if ("130625sca".equals(input.getText().toString().trim())) {
                        s.devMode = true; Save.save(ctx, s);
                        showDropRateDialog();
                    } else {
                        new AlertDialog.Builder(ctx).setMessage("密码错误")
                                .setPositiveButton("好", null).show();
                    }
                })
                .setNegativeButton("取消", null).show();
    }

    private void showDropRateDialog() {
        final String[] labels = {"低 (×0.5)", "正常 (×1.0)", "中 (×1.5)",
                "高 (×2.5)", "极高 (×4.0)", "特别高 (×8.0)"};
        new AlertDialog.Builder(ctx)
                .setTitle("爆率设置（当前：" + labels[s.dropRateLevel] + "）")
                .setItems(labels, (d, which) -> {
                    s.dropRateLevel = which; Save.save(ctx, s);
                    new AlertDialog.Builder(ctx)
                            .setMessage("已设置爆率：" + labels[which])
                            .setPositiveButton("好", null).show();
                })
                .setNegativeButton("取消", null).show();
    }

    private void endRaid(boolean success) {
        if (over) return;
        over = true;
        closeSearchPanel(); closeBag();
        s.raids++;
        s.totalLoot += gameView.lootValue;
        GameState.BattleRecord r = new GameState.BattleRecord();
        r.success = success; r.map = map.name;
        r.kills = gameView.kills; r.loot = gameView.lootValue;
        if (success) {
            s.extracts++; s.rankPoints += 10;
            for (GameState.Item it : gameView.backpack) s.addToWarehouse(it);
            if (gameView.lootValue > s.bestLoot) s.bestLoot = gameView.lootValue;
            if (s.activeContractId != null) {
                GameData.Contract c = GameData.findContract(s.activeContractId);
                boolean done = false;
                if ("extract".equals(c.type)) {
                    s.activeContractProgress++;
                    done = s.activeContractProgress >= c.target;
                } else if ("extract_loot".equals(c.type)) {
                    s.activeContractProgress += gameView.backpack.size();
                    done = s.activeContractProgress >= c.target;
                } else if ("loot5".equals(c.type)) {
                    for (GameState.Item it : gameView.backpack)
                        if (it.level >= 5) { s.activeContractProgress++; break; }
                    done = s.activeContractProgress >= c.target;
                }
                if (done) {
                    s.money += c.reward;
                    s.activeContractId = null;
                    s.activeContractProgress = 0;
                }
            }
            for (GameState.Quest q : s.quests) {
                if (q.done) continue;
                if ("q1".equals(q.id)) q.progress = Math.min(q.target, q.progress + 1);
                if (q.progress >= q.target) {
                    q.done = true; s.money += q.reward;
                }
            }
        } else {
            s.deaths++;
            s.rankPoints = Math.max(0, s.rankPoints - 5);
            s.weapon = null; s.melee = null; s.armor = null; s.helmet = null;
            s.meds.clear(); s.ammo = 0;
        }
        s.questLog.add(r);
        if (s.questLog.size() > 50) s.questLog.remove(0);
        Save.save(ctx, s);
        AlertDialog.Builder b = new AlertDialog.Builder(ctx);
        b.setTitle(success ? "✅ 撤离成功" : "❌ 任务失败");
        b.setMessage(success
                ? "带回 " + gameView.backpack.size() + " 件物资\n总价值：" + UI.fmt(gameView.lootValue)
                        + "\n击杀：" + gameView.kills
                : "你在 " + map.name + " 倒下了\n本次击杀：" + gameView.kills);
        b.setCancelable(false);
        b.setPositiveButton("返回大厅", (d, w) -> act.showLobby());
        b.show();
    }

    public class GameView extends View {

        public interface Listener {
            void onHud(int hp, int maxHp, int loot, int kills, int magAmmo, int magSize,
                       int ammo, int timeLeft, int stamina, String weather);
            void onEnd(boolean success);
            void onMedChanged();
            void onOpenContainer(Box box);
            void onEvent(String text);
        }

        private static final int WORLD = 4000;
        private static final float BOUND_R = 1800f;
        private static final float SCALE = 1.4f;
        private static final float STAM_MAX = 100f;

        public float px = WORLD / 2f, py = WORLD / 2f;
        public int hp = 100, maxHp = 100;
        public int magAmmo, magSize, ammo = s.ammo;
        public int timeLeft = 300;
        public int lootValue = 0, kills = 0;
        public float stamina = 100f;
        public boolean runRequested = false;
        private float staminaRegenDelay = 0f;
        public List<GameState.Item> backpack = new ArrayList<>();
        public boolean success = false;
        private float outTimer = 0f;
        private boolean outOfBounds = false;

        public float altarX = WORLD / 2f;
        public float altarY = WORLD / 2f;
        public boolean bossSummoned = false;

        private String opId, opName, skillType;
        private int skillCd;
        private float skillCdLeft = 0f;
        private float shieldHp = 0f, shieldTimer = 0f;
        private float droneTimer = 0f, regenTimer = 0f;
        public class Drone { public float x, y, life; }
        public List<Drone> drones = new ArrayList<>();

        private GameData.Weather weather;

        private int shotsFired = 0;
        private long lastShotTime = 0;

        private GameData.RandomEvent currentEvent = null;
        private float eventTimer = 0f;
        private float nextEventCheck = 30f;

        public class Smoke { public float x, y, radius, life; }
        public class Flash { public float x, y, life; }
        public class Explosion { public float x, y, life; }
        public class Fire { public float x, y, life; }
        public List<Smoke> smokes = new ArrayList<>();
        public List<Flash> flashes = new ArrayList<>();
        public List<Explosion> explosions = new ArrayList<>();
        public List<Fire> fires = new ArrayList<>();

        public class Enemy {
            public GameData.Enemy tpl;
            public float x, y; public int hp;
            public boolean alive = true;
            public long lastShoot = 0;
            public boolean alert = false;
            public float fx = 1, fy = 0;
            public float hurt = 0;
            public float stunned = 0f;
            public float empLeft = 0f;
            public float reloading = 0f;
            public float healCd = 0f;
            public float retreating = 0f;
        }
        public class Box {
            public GameData.Container tpl;
            public float x, y;
            public List<GameState.Item> lootItems;
            public boolean isDropped = false;
        }
        public class Bullet {
            public float x, y, vx, vy, life;
            public int dmg;
            public boolean enemy;
        }
        public class Wall { public float x, y, w, h; }
        public class Ray { public float x1, y1, x2, y2, life; }
        public class House { public float x, y, w, h; }
        public class Tree { public float x, y, size; }
        public class Rock { public float x, y, size; }
        public class Flower { public float x, y; public int color; }

        public List<Enemy> enemies = new ArrayList<>();
        public List<Box> boxes = new ArrayList<>();
        public List<Bullet> bullets = new ArrayList<>();
        public List<Wall> walls = new ArrayList<>();
        public List<Ray> rays = new ArrayList<>();
        public List<House> houses = new ArrayList<>();
        public List<Tree> trees = new ArrayList<>();
        public List<Rock> rocks = new ArrayList<>();
        public List<Flower> flowers = new ArrayList<>();
        public float ex = WORLD / 2f, ey = 300f;

        private float moveCx = 0, moveCy = 0, moveDx = 0, moveDy = 0;
        private float aimCx = 0, aimCy = 0, aimDx = 0, aimDy = 0;
        private float fireCx = 0, fireCy = 0, fireR = 0;
        private float runCx = 0, runCy = 0, runR = 0;
        private boolean firing = false;
        private float facingX = 0, facingY = -1;
        private float camX = 0, camY = 0;
        private boolean inited = false, paused = false;
        private boolean currentlyRunning = false;

        private Listener listener;
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Handler handler = new Handler(Looper.getMainLooper());

        private long lastTick = 0, lastSecond = 0, lastFire = 0;
        private boolean runningThread = false;
        private Runnable ticker;

        public GameView(Context c) {
            super(c);
            stroke.setStyle(Paint.Style.STROKE);
            textP.setColor(Color.WHITE);
            textP.setTextAlign(Paint.Align.CENTER);
            GameData.Operator op = GameData.findOperator(s.currentOperator);
            opId = op.id; opName = op.name; skillType = op.skillType; skillCd = op.skillCd;
            weather = GameData.randomWeather();
            int healBonus = s.baseLevel("U2") * 10;
            hp = Math.min(maxHp, 100 + healBonus);
            initWorld();
        }

        public void setListener(Listener l) {
            this.listener = l;
            runningThread = true; lastTick = System.nanoTime();
            ticker = new Runnable() {
                @Override public void run() {
                    if (!runningThread) return;
                    long now = System.nanoTime();
                    float dt = (now - lastTick) / 1_000_000_000f;
                    lastTick = now;
                    if (dt > 0.1f) dt = 0.1f;
                    try { if (!paused) update(dt); invalidate(); }
                    catch (Exception e) { e.printStackTrace(); }
                    handler.postDelayed(this, 16);
                }
            };
            handler.post(ticker);
        }

        public void pauseMovement() { paused = true; moveDx = 0; moveDy = 0; firing = false; }
        public void resumeMovement() { paused = false; }
        public void notifyHud() {
            if (listener != null) listener.onHud(hp, maxHp, lootValue, kills,
                    magAmmo, magSize, s.ammo, timeLeft, (int)stamina,
                    weather.icon + " " + weather.name);
        }

        public boolean tryPickup(GameState.Item it) {
            int slots = backpackSlots();
            int used = 0;
            for (GameState.Item x : backpack) used += GameData.lootSize(x.level);
            if (used + GameData.lootSize(it.level) > slots) {
                new AlertDialog.Builder(ctx).setMessage("背包已满！(" + used + "/" + slots + ")")
                        .setPositiveButton("好", null).show();
                return false;
            }
            backpack.add(it);
            lootValue += it.price;
            notifyHud();
            return true;
        }
        public void pickupItem(GameState.Item it) { tryPickup(it); }

        public void dropItemOnGround(GameState.Item it) {
            Box b = new Box();
            b.tpl = new GameData.Container("DROP", "丢弃物资", "mid",
                    it.icon != null ? it.icon : "📦");
            b.x = px + (float)(Math.random() * 60 - 30);
            b.y = py + 40 + (float)(Math.random() * 40);
            b.lootItems = new ArrayList<>();
            b.lootItems.add(it);
            b.isDropped = true;
            boxes.add(b);
            backpack.remove(it);
            lootValue -= it.price;
            notifyHud();
        }

        private void initWorld() {
            try {
                px = WORLD / 2f; py = WORLD / 2f;
                ex = WORLD / 2f; ey = 300f;
                buildHouse(600, 600); buildHouse(3000, 600);
                buildHouse(600, 3100); buildHouse(3000, 3100);
                House h1 = new House(); h1.x = 600; h1.y = 600; h1.w = 400; h1.h = 300; houses.add(h1);
                House h2 = new House(); h2.x = 3000; h2.y = 600; h2.w = 400; h2.h = 300; houses.add(h2);
                House h3 = new House(); h3.x = 600; h3.y = 3100; h3.w = 400; h3.h = 300; houses.add(h3);
                House h4 = new House(); h4.x = 3000; h4.y = 3100; h4.w = 400; h4.h = 300; houses.add(h4);
                for (int i = 0; i < 100; i++) {
                    Tree t = new Tree();
                    t.x = 150 + (float)(Math.random() * (WORLD - 300));
                    t.y = 150 + (float)(Math.random() * (WORLD - 300));
                    if (insideAnyHouse(t.x, t.y)) continue;
                    t.size = 22 + (float)(Math.random() * 10);
                    trees.add(t);
                }
                for (int i = 0; i < 50; i++) {
                    Rock r = new Rock();
                    r.x = 150 + (float)(Math.random() * (WORLD - 300));
                    r.y = 150 + (float)(Math.random() * (WORLD - 300));
                    if (insideAnyHouse(r.x, r.y)) continue;
                    r.size = 12 + (float)(Math.random() * 10);
                    rocks.add(r);
                }
                for (int i = 0; i < 200; i++) {
                    Flower f = new Flower();
                    f.x = 100 + (float)(Math.random() * (WORLD - 200));
                    f.y = 100 + (float)(Math.random() * (WORLD - 200));
                    if (insideAnyHouse(f.x, f.y)) continue;
                    f.color = new int[]{0xFFFF6B9D, 0xFFFFEB3B, 0xFFFFFFFF, 0xFF9C27B0}[(int)(Math.random()*4)];
                    flowers.add(f);
                }
                int cnt = diff.eMin + (int)(Math.random() * (diff.eMax - diff.eMin + 1));
                cnt = (int)(cnt * map.enMul);
                for (int i = 0; i < cnt; i++) {
                    Enemy e = new Enemy();
                    e.tpl = GameData.ENEMIES[(int)(Math.random() * GameData.ENEMIES.length)];
                    boolean placed = false;
                    for (int tries = 0; tries < 100; tries++) {
                        float tx = 300 + (float)(Math.random() * (WORLD - 600));
                        float ty = 300 + (float)(Math.random() * (WORLD - 600));
                        if (hitsWall(tx, ty, 20)) continue;
                        if (Math.hypot(tx - WORLD/2f, ty - WORLD/2f) < 400) continue;
                        boolean close = false;
                        for (Enemy o : enemies) if (Math.hypot(o.x - tx, o.y - ty) < 450) { close = true; break; }
                        if (close) continue;
                        e.x = tx; e.y = ty; placed = true; break;
                    }
                    if (!placed) { e.x = 300 + (float)(Math.random()*(WORLD-600)); e.y = 300 + (float)(Math.random()*(WORLD-600)); }
                    e.hp = e.tpl.hp;
                    enemies.add(e);
                }
                addBoxAt(700,700); addBoxAt(900,700); addBoxAt(700,820); addBoxAt(900,820);
                addBoxAt(3100,700); addBoxAt(3300,700); addBoxAt(3100,820); addBoxAt(3300,820);
                addBoxAt(700,3200); addBoxAt(900,3200); addBoxAt(700,3320); addBoxAt(900,3320);
                addBoxAt(3100,3200); addBoxAt(3300,3200); addBoxAt(3100,3320); addBoxAt(3300,3320);
                addBoxAt(2000,700); addBoxAt(2000,3300);
                addBoxAt(700,2000); addBoxAt(3300,2000);
                addBoxAt(1200,1200); addBoxAt(2800,1200);
                addBoxAt(1200,2800); addBoxAt(2800,2800);
                if (s.weapon != null) { magSize = s.weapon.mag; magAmmo = magSize; }
            } catch (Exception e) { e.printStackTrace(); }
        }

        private void addBoxAt(float x, float y) {
            Box b = new Box();
            b.tpl = GameData.CONTAINERS[(int)(Math.random() * GameData.CONTAINERS.length)];
            b.x = x; b.y = y;
            b.lootItems = new ArrayList<>();
            int n = 2 + (int)(Math.random() * 3);
            for (int j = 0; j < n; j++) {
                GameData.Loot drop = GameData.rollLoot(b.tpl.tier,
                        map.lootMul * s.dropRateMultiplier());
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime() + j;
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    b.lootItems.add(it);
                }
            }
            boxes.add(b);
        }

        private void buildHouse(float hx, float hy) {
            float t = 20f, hw = 400, hh = 300;
            Wall w1 = new Wall(); w1.x = hx; w1.y = hy; w1.w = 150; w1.h = t; walls.add(w1);
            Wall w2 = new Wall(); w2.x = hx + 250; w2.y = hy; w2.w = hw - 250; w2.h = t; walls.add(w2);
            Wall w3 = new Wall(); w3.x = hx; w3.y = hy + hh - t; w3.w = hw; w3.h = t; walls.add(w3);
            Wall w4 = new Wall(); w4.x = hx; w4.y = hy; w4.w = t; w4.h = hh; walls.add(w4);
            Wall w5 = new Wall(); w5.x = hx + hw - t; w5.y = hy; w5.w = t; w5.h = hh; walls.add(w5);
        }

        private boolean insideAnyHouse(float x, float y) {
            for (House h : houses) if (x > h.x && x < h.x + h.w && y > h.y && y < h.y + h.h) return true;
            return false;
        }

        private boolean hitsWall(float x, float y, float r) {
            for (Wall w : walls)
                if (x + r > w.x && x - r < w.x + w.w && y + r > w.y && y - r < w.y + w.h) return true;
            return false;
        }

        private boolean rayHitsWall(float x1, float y1, float x2, float y2) {
            float dx = x2 - x1, dy = y2 - y1;
            float dist = (float) Math.hypot(dx, dy);
            if (dist < 1) return false;
            int steps = (int)(dist / 15) + 1;
            for (int i = 1; i < steps; i++) {
                float t = (float) i / steps;
                if (hitsWall(x1 + dx * t, y1 + dy * t, 4)) return true;
            }
            return false;
        }

        private boolean hitsEntity(float x, float y, float r, Enemy self) {
            for (Enemy e : enemies) {
                if (e == self || !e.alive) continue;
                if (Math.hypot(e.x - x, e.y - y) < r * 2) return true;
            }
            return false;
        }

        public void reload() {
            if (s.weapon == null || s.ammo <= 0) return;
            int need = magSize - magAmmo;
            int take = Math.min(need, s.ammo);
            magAmmo += take; s.ammo -= take;
            notifyHud();
        }

        public void useMed(int idx) {
            if (idx < 0 || idx >= s.meds.size()) return;
            GameState.Item it = s.meds.get(idx);
            hp = Math.min(maxHp, hp + (int)(it.heal * maxHp));
            s.meds.remove(idx);
            Save.save(ctx, s);
            if (listener != null) listener.onMedChanged();
            notifyHud();
        }

        public void tryExtract() {
            if (Math.hypot(ex - px, ey - py) > 150) return;
            success = true; endGame();
        }

        public void castSkill() {
            if (skillCdLeft > 0) return;
            skillCdLeft = skillCd;
            if ("drone".equals(skillType)) {
                droneTimer = 8f;
                Drone d = new Drone();
                d.x = px; d.y = py; d.life = 8f;
                drones.add(d);
                if (listener != null) listener.onEvent("🛰️ 无人机释放");
            } else if ("heal".equals(skillType)) {
                int heal = (int)(maxHp * 0.6);
                hp = Math.min(maxHp, hp + heal);
                regenTimer = 5f;
                notifyHud();
                if (listener != null) listener.onEvent("💉 急救 +" + heal);
            } else if ("shield".equals(skillType)) {
                shieldHp = 200f;
                shieldTimer = 10f;
                if (listener != null) listener.onEvent("🛡️ 护盾展开");
            }
        }

        public void throwTactical(int idx) {
            if (idx < 0 || idx >= s.tacticals.size()) return;
            GameState.Item it = s.tacticals.get(idx);
            float tx = px + facingX * 200;
            float ty = py + facingY * 200;

            if ("T1".equals(it.id)) {
                Smoke sm = new Smoke();
                sm.x = tx; sm.y = ty; sm.radius = 150; sm.life = 12f;
                smokes.add(sm);
            } else if ("T2".equals(it.id)) {
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    if (Math.hypot(e.x - tx, e.y - ty) < 180) e.stunned = 4f;
                }
                Flash fl = new Flash();
                fl.x = tx; fl.y = ty; fl.life = 0.5f;
                flashes.add(fl);
            } else if ("T3".equals(it.id)) {
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float d = (float) Math.hypot(e.x - tx, e.y - ty);
                    if (d < 140) hitEnemy(e, (int)(120 * (1 - d / 140)), false);
                }
                Explosion e2 = new Explosion();
                e2.x = tx; e2.y = ty; e2.life = 0.5f;
                explosions.add(e2);
            }

            s.tacticals.remove(idx);
            Save.save(ctx, s);
            notifyHud();
        }

        private void summonBoss() {
            if (bossSummoned) return;
            bossSummoned = true;
            Enemy e = new Enemy();
            if ("mine".equals(map.id)) {
                e.tpl = new GameData.Enemy("BOSS_MINE", "矿脉巨魔", 600, 45, "boss", "👹", 250);
            } else if ("facility".equals(map.id)) {
                e.tpl = new GameData.Enemy("BOSS_FAC", "钢铁将军", 800, 55, "boss", "🤖", 350);
            } else {
                e.tpl = new GameData.Enemy("BOSS_TOWN", "“棍母”镇长", 500, 40, "boss", "👺", 200);
            }
            e.x = altarX + 100; e.y = altarY + 100; e.hp = e.tpl.hp;
            enemies.add(e);
            if (listener != null) listener.onEvent("⚠ Boss 出现");
        }

        private void update(float dt) {
            long now = System.currentTimeMillis();
            if (now - lastSecond >= 1000) {
                lastSecond = now;
                timeLeft--;
                if (timeLeft <= 0) { success = false; endGame(); return; }
                notifyHud();
            }

            boolean canRun = stamina > 0.5f;
            currentlyRunning = runRequested && canRun;
            if (currentlyRunning) {
                stamina -= 22f * dt;
                if (stamina <= 0) { stamina = 0; currentlyRunning = false; }
                staminaRegenDelay = 1.2f;
            } else {
                if (staminaRegenDelay > 0) staminaRegenDelay -= dt;
                else { stamina += 80f * dt; if (stamina > STAM_MAX) stamina = STAM_MAX; }
            }

            float baseSpeed = (s.weapon == null) ? 100 : 85;
            int usedSlots = 0;
            for (GameState.Item it : backpack) usedSlots += GameData.lootSize(it.level);
            float weightMul = GameData.weightSpeedMul(usedSlots, backpackSlots());
            float speed = (currentlyRunning ? baseSpeed * 2.0f : baseSpeed)
                    * weather.speedMul * weightMul;
            float nx = px + moveDx * speed * dt, ny = py + moveDy * speed * dt;
            if (!hitsWall(nx, py, 18)) px = nx;
            if (!hitsWall(px, ny, 18)) py = ny;
            px = Math.max(30, Math.min(WORLD - 30, px));
            py = Math.max(30, Math.min(WORLD - 30, py));

            if (Math.hypot(px - WORLD/2f, py - WORLD/2f) > BOUND_R) {
                outOfBounds = true; outTimer += dt;
                if (outTimer >= 5f) { success = false; endGame(); return; }
            } else { outOfBounds = false; outTimer = 0f; }

            float vw = getWidth() / SCALE, vh = getHeight() / SCALE;
            camX = px - vw / 2f; camY = py - vh / 2f;

            for (int i = bullets.size() - 1; i >= 0; i--) {
                Bullet b = bullets.get(i);
                float bx2 = b.x + b.vx * dt, by2 = b.y + b.vy * dt;
                if (hitsWall(bx2, by2, 4)) { bullets.remove(i); continue; }
                b.x = bx2; b.y = by2;
                b.life -= dt;
                if (b.life <= 0) { bullets.remove(i); continue; }
                if (b.enemy) {
                    if (Math.hypot(b.x - px, b.y - py) < 20) {
                        int dmg = b.dmg;
                        if (shieldHp > 0) {
                            if (shieldHp >= dmg) { shieldHp -= dmg; dmg = 0; }
                            else { dmg -= shieldHp; shieldHp = 0; }
                        }
                        if (dmg > 0) {
                            hp -= dmg;
                            if (hp < maxHp * 0.3 && s.autoMed && !s.meds.isEmpty()) useMed(0);
                            if (hp <= 0) { hp = 0; success = false; endGame(); return; }
                            notifyHud();
                        }
                        bullets.remove(i);
                    }
                }
            }
            for (int i = rays.size() - 1; i >= 0; i--) {
                rays.get(i).life -= dt;
                if (rays.get(i).life <= 0) rays.remove(i);
            }
            if (skillCdLeft > 0) skillCdLeft -= dt;
            if (shieldTimer > 0) { shieldTimer -= dt; if (shieldTimer <= 0) shieldHp = 0; }
            if (droneTimer > 0) {
                droneTimer -= dt;
                for (int i = drones.size() - 1; i >= 0; i--) {
                    drones.get(i).life -= dt;
                    if (drones.get(i).life <= 0) drones.remove(i);
                }
            }
            if (regenTimer > 0) {
                regenTimer -= dt;
                hp = Math.min(maxHp, hp + (int)(maxHp * 0.06f * dt));
                notifyHud();
            }

            for (int i = smokes.size() - 1; i >= 0; i--) {
                smokes.get(i).life -= dt;
                if (smokes.get(i).life <= 0) smokes.remove(i);
            }
            for (int i = flashes.size() - 1; i >= 0; i--) {
                flashes.get(i).life -= dt;
                if (flashes.get(i).life <= 0) flashes.remove(i);
            }
            for (int i = explosions.size() - 1; i >= 0; i--) {
                explosions.get(i).life -= dt;
                if (explosions.get(i).life <= 0) explosions.remove(i);
            }
            for (int i = fires.size() - 1; i >= 0; i--) {
                Fire f = fires.get(i);
                f.life -= dt;
                if (f.life <= 0) { fires.remove(i); continue; }
                if (Math.hypot(px - f.x, py - f.y) < 60) {
                    hp -= (int)(12 * dt);
                    if (hp <= 0) { hp = 0; success = false; endGame(); return; }
                }
            }

            nextEventCheck -= dt;
            if (nextEventCheck <= 0 && currentEvent == null) {
                nextEventCheck = 45f;
                if (Math.random() < 0.5) {
                    currentEvent = GameData.EVENTS[(int)(Math.random() * GameData.EVENTS.length)];
                    eventTimer = currentEvent.duration > 0 ? currentEvent.duration : 10f;
                    if (listener != null) listener.onEvent(currentEvent.icon + " " + currentEvent.name);
                    if ("RE3".equals(currentEvent.id)) {
                        addBoxAt(WORLD / 2f, WORLD / 2f - 300);
                    }
                }
            }
            if (currentEvent != null) {
                eventTimer -= dt;
                if (eventTimer <= 0) currentEvent = null;
            }

            for (Enemy e : enemies) {
                if (!e.alive) continue;
                if (e.hurt > 0) e.hurt -= dt;
                if (e.stunned > 0) { e.stunned -= dt; continue; }
                if (e.empLeft > 0) e.empLeft -= dt;
                if (e.reloading > 0) { e.reloading -= dt; continue; }
                if (e.healCd > 0) e.healCd -= dt;

                float dx = px - e.x, dy = py - e.y;
                float d = (float) Math.hypot(dx, dy);

                if (e.hp < e.tpl.hp * 0.25f && e.retreating <= 0) e.retreating = 3f;
                if (e.retreating > 0) {
                    e.retreating -= dt;
                    if (d > 1) {
                        float rx = -dx / d * 80 * dt, ry = -dy / d * 80 * dt;
                        if (!hitsWall(e.x + rx, e.y, 18)) e.x += rx;
                        if (!hitsWall(e.x, e.y + ry, 18)) e.y += ry;
                    }
                    continue;
                }

                float detectRange = 800 * weather.visibility;
                if (d < detectRange && d > 0.1f) {
                    e.alert = true;
                    e.fx = dx / d; e.fy = dy / d;
                    if (d > 120) {
                        float nex = e.x + dx / d * 90 * dt;
                        float ney = e.y + dy / d * 90 * dt;
                        if (!hitsWall(nex, e.y, 18) && !hitsEntity(nex, e.y, 18, e)) e.x = nex;
                        if (!hitsWall(e.x, ney, 18) && !hitsEntity(e.x, ney, 18, e)) e.y = ney;
                    }
                    if (d < 350 && now - e.lastShoot > 1500 && e.empLeft <= 0) {
                        if (!rayHitsWall(e.x, e.y, px, py)) {
                            e.lastShoot = now;
                            Ray r = new Ray();
                            r.x1 = e.x; r.y1 = e.y; r.x2 = px; r.y2 = py; r.life = 0.2f;
                            rays.add(r);
                            Bullet eb = new Bullet();
                            eb.x = e.x; eb.y = e.y;
                            float sp = 500f;
                            eb.vx = dx / d * sp; eb.vy = dy / d * sp;
                            eb.life = 0.7f;
                            eb.enemy = true;
                            int dmg0 = (int)Math.round(e.tpl.dmg * 0.4);
                            double red = 0;
                            if (s.armor != null) red += s.armor.red;
                            if (s.helmet != null) red += s.helmet.red * 0.5;
                            dmg0 = (int)(dmg0 * (1 - Math.min(red, 0.85)));
                            if (dmg0 < 1) dmg0 = 1;
                            eb.dmg = dmg0;
                            if (Math.random() < 0.5) bullets.add(eb);
                        }
                    }
                    if (now - e.lastShoot > 5000 && e.reloading <= 0 && Math.random() < 0.01) {
                        e.reloading = 2f;
                    }
                } else e.alert = false;
            }
            if (firing) doFire(now);
            notifyHud();
        }

        private void doFire(long now) {
            if (s.weapon != null) {
                long interval = Math.max(60, 60000 / s.weapon.rate);
                if (now - lastFire < interval) return;
                lastFire = now;
                if (magAmmo <= 0) { reload(); return; }
                if (s.ammo <= 0 && magAmmo <= 0) return;
                magAmmo--;
                shotsFired++;
                if (now - lastShotTime > 1000) shotsFired = 1;
                lastShotTime = now;

                float spread = GameData.crosshairSpread(shotsFired, moveDx != 0 || moveDy != 0);
                float angleJitter = (float)(Math.random() - 0.5) * spread * 0.02f;
                double baseAng = Math.atan2(facingY, facingX);
                double shootAng = baseAng + angleJitter;
                float sx = (float)Math.cos(shootAng);
                float sy = (float)Math.sin(shootAng);

                float bx = px + sx * 30, by = py + sy * 30;
                Bullet b = new Bullet();
                b.x = bx; b.y = by;
                b.vx = sx * 900; b.vy = sy * 900;
                b.life = s.weapon.range / 900f;
                b.dmg = s.weapon.dmg;
                bullets.add(b);

                Enemy target = null; float best = Float.MAX_VALUE;
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float edx = e.x - bx, edy = e.y - by;
                    float ed = (float) Math.hypot(edx, edy);
                    if (ed > s.weapon.range) continue;
                    float dot = edx * sx + edy * sy; if (dot < 0) continue;
                    float perp = Math.abs(edx * sy - edy * sx);
                    if (perp < 40 && ed < best && !rayHitsWall(bx, by, e.x, e.y)) { best = ed; target = e; }
                }
                if (target != null) {
                    boolean head = Math.random() < 0.2;
                    int dmg = b.dmg;
                    if (head) dmg = (int)(dmg * GameData.HEADSHOT_MUL);
                    hitEnemy(target, dmg, head);
                }
                notifyHud();
            } else {
                if (now - lastFire < 400) return;
                lastFire = now;
                float bx = px + facingX * 30, by = py + facingY * 30;
                int dmg = (s.melee != null) ? s.melee.dmg : 15;
                float range = (s.melee != null) ? s.melee.range : 60;
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    if (Math.hypot(e.x - bx, e.y - by) < range + 30) { hitEnemy(e, dmg, false); break; }
                }
                notifyHud();
            }
        }

        private void hitEnemy(Enemy e, int dmg, boolean head) {
            e.hp -= dmg;
            e.hurt = 0.15f;
            if (head && listener != null) listener.onEvent("🎯 爆头！-" + dmg);
            if (e.hp <= 0) {
                e.alive = false;
                kills++; s.kills++; s.totalKills++;
                GameData.Loot drop = GameData.rollLoot(e.tpl.dropTier,
                        map.lootMul * s.dropRateMultiplier());
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    tryPickup(it);
                }
                if (e.tpl.id != null && e.tpl.id.startsWith("BOSS") && Math.random() < 0.7) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = "L-SP1"; it.type = "loot"; it.name = "首领印章";
                    it.level = 6; it.price = 520000; it.icon = "🔱";
                    tryPickup(it);
                }
                if (s.activeContractId != null) {
                    GameData.Contract c = GameData.findContract(s.activeContractId);
                    if ("kill".equals(c.type) || "melee".equals(c.type)
                            || "boss".equals(c.type)) {
                        s.activeContractProgress++;
                        if (s.activeContractProgress >= c.target) {
                            s.money += c.reward;
                            if (listener != null) listener.onEvent("📋 合同完成 +" + UI.fmt(c.reward));
                            s.activeContractId = null;
                            s.activeContractProgress = 0;
                        }
                    }
                }
            }
        }

        private void endGame() {
            runningThread = false;
            handler.removeCallbacks(ticker);
            if (listener != null) listener.onEnd(success);
        }

        @Override
        protected void onDraw(Canvas c) {
            super.onDraw(c);
            try {
                int W = getWidth(), H = getHeight();
                if (W <= 0 || H <= 0) return;
                c.save();
                c.scale(SCALE, SCALE);
                c.translate(-camX, -camY);

                int grass = 0xFF3D5A2A;
                if ("mine".equals(map.id)) grass = 0xFF6B5A3A;
                else if ("facility".equals(map.id)) grass = 0xFF3A4A5A;
                if ("W5".equals(weather.id)) grass = 0xFF1A2010;
                else if ("W3".equals(weather.id)) grass = 0xFF4A5A3A;

                c.drawColor(grass);
                drawGrassTexture(c, grass);
                drawBoundary(c);
                drawRoads(c);

                for (House h : houses) if (inView(h.x, h.y, h.w, h.h)) drawHouseFloor(c, h);
                for (Flower f : flowers) {
                    if (!inView2(f.x, f.y, 6)) continue;
                    p.setColor(f.color); c.drawCircle(f.x, f.y, 1.6f, p);
                }

                p.setColor(0x334CAF50); c.drawCircle(ex, ey, 80, p);
                stroke.setColor(0xFF4CAF50); stroke.setStrokeWidth(4);
                c.drawCircle(ex, ey, 80, stroke);
                textP.setColor(0xFF4CAF50); textP.setTextSize(24);
                c.drawText("撤 离", ex, ey + 8, textP);

                drawAltar(c);

                for (Rock r : rocks) if (inView2(r.x, r.y, r.size * 1.5f)) drawRock(c, r);
                for (Box b : boxes) if (inView2(b.x, b.y, 30)) drawBox(c, b);

                for (Fire f : fires) {
                    p.setColor(0xAAFF5722);
                    c.drawCircle(f.x, f.y, 40, p);
                    p.setColor(0xAAFFEB3B);
                    c.drawCircle(f.x + (float)Math.random() * 10 - 5,
                            f.y + (float)Math.random() * 10 - 5, 20, p);
                }

                for (Drone d : drones) {
                    p.setColor(0xFFFFD700);
                    c.drawCircle(d.x, d.y, 12, p);
                    p.setColor(0x44FFD700);
                    c.drawCircle(d.x, d.y, 50, p);
                }

                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    boolean visible = inView2(e.x, e.y, 60) || droneTimer > 0
                            || Math.hypot(e.x - px, e.y - py) < 800 * weather.visibility;
                    if (!visible) continue;
                    drawEnemy(c, e);
                }

                if (shieldHp > 0) {
                    p.setColor(0x4464B5F6);
                    c.drawCircle(px, py, 42, p);
                    stroke.setColor(0xFF64B5F6);
                    stroke.setStrokeWidth(3);
                    c.drawCircle(px, py, 42, stroke);
                }

                drawPlayer(c);

                for (Tree t : trees) if (inView2(t.x, t.y, t.size * 2)) drawTree(c, t);
                for (Wall w : walls) if (inView(w.x, w.y, w.w, w.h)) drawWall(c, w);
                for (House h : houses) if (inView(h.x, h.y, h.w, h.h)) drawRoof(c, h);

                for (Smoke sm : smokes) {
                    p.setColor(0x55FFFFFF);
                    c.drawCircle(sm.x, sm.y, sm.radius, p);
                    c.drawCircle(sm.x - 30, sm.y - 20, sm.radius * 0.8f, p);
                    c.drawCircle(sm.x + 30, sm.y + 20, sm.radius * 0.8f, p);
                }
                for (Flash f : flashes) {
                    p.setColor(0xFFFFFF00);
                    c.drawCircle(f.x, f.y, 200 * (f.life * 2), p);
                }
                for (Explosion e2 : explosions) {
                    p.setColor(0xAAFF5722);
                    c.drawCircle(e2.x, e2.y, (1 - e2.life * 2) * 160, p);
                }

                for (Bullet b : bullets) {
                    if (!inView2(b.x, b.y, 40)) continue;
                    if (b.enemy) {
                        p.setColor(0xAAFF0000); p.setStrokeWidth(2);
                        c.drawLine(b.x - b.vx * 0.03f, b.y - b.vy * 0.03f, b.x, b.y, p);
                        p.setColor(0xFFFF8888); c.drawCircle(b.x, b.y, 3, p);
                    } else {
                        p.setColor(0xAAFFD700); p.setStrokeWidth(2);
                        c.drawLine(b.x - b.vx * 0.03f, b.y - b.vy * 0.03f, b.x, b.y, p);
                        p.setColor(0xFFFFF7C0); c.drawCircle(b.x, b.y, 2.5f, p);
                    }
                }
                for (Ray r : rays) {
                    p.setColor(0xAA8B0000); p.setStrokeWidth(2.5f);
                    c.drawLine(r.x1, r.y1, r.x2, r.y2, p);
                    p.setColor(0xFFFF0000); p.setStrokeWidth(1);
                    c.drawLine(r.x1, r.y1, r.x2, r.y2, p);
                }

                if ("W3".equals(weather.id)) {
                    p.setColor(0x44CCCCCC);
                    c.drawRect(camX, camY, camX + getWidth()/SCALE, camY + getHeight()/SCALE, p);
                } else if ("W4".equals(weather.id)) {
                    p.setColor(0x33000033);
                    c.drawRect(camX, camY, camX + getWidth()/SCALE, camY + getHeight()/SCALE, p);
                } else if ("W5".equals(weather.id)) {
                    p.setColor(0x88000022);
                    c.drawRect(camX, camY, camX + getWidth()/SCALE, camY + getHeight()/SCALE, p);
                }

                c.restore();

                if (outOfBounds) {
                    p.setColor(0x66FF0000);
                    c.drawRect(0, 0, W, H, p);
                    textP.setColor(0xFFFFFFFF);
                    textP.setTextSize(UI.dp(ctx, 36));
                    textP.setShadowLayer(6, 2, 2, Color.BLACK);
                    c.drawText("⚠ 越界 " + String.format("%.1f", 5f - outTimer) + " 秒后死亡",
                            W / 2f, H / 2f, textP);
                    textP.setShadowLayer(0, 0, 0, 0);
                }

                if (moveCx > 0) {
                    float mr = UI.dp(ctx, 60);
                    p.setColor(0x30000000); c.drawCircle(moveCx, moveCy, mr, p);
                    stroke.setColor(0xFFC8742A); stroke.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawCircle(moveCx, moveCy, mr, stroke);
                    p.setColor(0xFFC8742A);
                    c.drawCircle(moveCx + moveDx * mr, moveCy + moveDy * mr, UI.dp(ctx, 25), p);
                    p.setColor(0x30000000); c.drawCircle(aimCx, aimCy, mr, p);
                    stroke.setColor(0xFFFF5252); c.drawCircle(aimCx, aimCy, mr, stroke);
                    p.setColor(0xFFFF5252);
                    c.drawCircle(aimCx + aimDx * mr, aimCy + aimDy * mr, UI.dp(ctx, 25), p);
                    float spread = GameData.crosshairSpread(shotsFired, moveDx != 0 || moveDy != 0);
                    stroke.setColor(0xFFFFEB3B);
                    stroke.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawCircle(fireCx, fireCy, fireR + spread, stroke);
                    p.setColor(firing ? 0xFFFF3B3B : 0xCC8A1A1A);
                    c.drawCircle(fireCx, fireCy, fireR, p);
                    stroke.setColor(0xFFFF3B3B);
                    c.drawCircle(fireCx, fireCy, fireR, stroke);
                    textP.setColor(0xFFFFEB3B);
                    textP.setTextSize(UI.dp(ctx, 28));
                    c.drawText("🔥", fireCx, fireCy + 10, textP);
                    p.setColor(currentlyRunning ? 0xFF4CAF50 :
                            (runRequested ? 0xCC2A6A2A : 0xCC0D0F0C));
                    c.drawCircle(runCx, runCy, runR, p);
                    stroke.setColor(stamina > 20 ? 0xFF3399FF : 0xFFFF5252);
                    stroke.setStrokeWidth(UI.dp(ctx, 2));
                    c.drawCircle(runCx, runCy, runR, stroke);
                    textP.setColor(0xFF3399FF);
                    textP.setTextSize(UI.dp(ctx, 22));
                    c.drawText("🏃", runCx, runCy + 8, textP);
                }
            } catch (Exception e) { e.printStackTrace(); }
        }

        private boolean inView(float x, float y, float w, float h) {
            float vw = getWidth() / SCALE, vh = getHeight() / SCALE;
            return x + w > camX - 100 && x < camX + vw + 100 && y + h > camY - 100 && y < camY + vh + 100;
        }
        private boolean inView2(float x, float y, float r) {
            float vw = getWidth() / SCALE, vh = getHeight() / SCALE;
            return x + r > camX - 50 && x - r < camX + vw + 50 && y + r > camY - 50 && y - r < camY + vh + 50;
        }

        private void drawGrassTexture(Canvas c, int base) {
            float vw = getWidth() / SCALE, vh = getHeight() / SCALE;
            int sx = (int)(camX / 40) * 40, sy = (int)(camY / 40) * 40;
            int dark = (base & 0xFF000000) | ((((base >> 16) & 0xFF) - 10) << 16)
                    | ((((base >> 8) & 0xFF) - 10) << 8) | ((base & 0xFF) - 10);
            p.setColor(dark);
            for (int x = sx; x < camX + vw + 40; x += 40) {
                for (int y = sy; y < camY + vh + 40; y += 40) {
                    int h = (x * 31 + y * 17) & 7;
                    if (h < 3) c.drawCircle(x + h * 5, y + ((h * 3) % 20), 3, p);
                }
            }
        }

        private void drawBoundary(Canvas c) {
            stroke.setColor(0x66FF0000); stroke.setStrokeWidth(8);
            c.drawCircle(WORLD / 2f, WORLD / 2f, BOUND_R, stroke);
            stroke.setColor(0x33FF0000); stroke.setStrokeWidth(16);
            c.drawCircle(WORLD / 2f, WORLD / 2f, BOUND_R, stroke);
        }

        private void drawRoads(Canvas c) {
            float vw = getWidth() / SCALE, vh = getHeight() / SCALE;
            p.setColor(0xFF3A3A3A);
            c.drawRect(0, WORLD / 2f - 60, WORLD, WORLD / 2f + 60, p);
            c.drawRect(WORLD / 2f - 50, 0, WORLD / 2f + 50, WORLD, p);
            c.drawRect(WORLD / 4f, 0, WORLD / 4f + 40, WORLD, p);
            c.drawRect(WORLD * 3 / 4f, 0, WORLD * 3 / 4f + 40, WORLD, p);
            p.setColor(0xFF555555);
            c.drawRect(0, WORLD / 2f - 66, WORLD, WORLD / 2f - 60, p);
            c.drawRect(0, WORLD / 2f + 60, WORLD, WORLD / 2f + 66, p);
            p.setColor(0xFFFFEB3B);
            int sx = (int)(camX / 100) * 100;
            for (int x = sx; x < camX + vw + 100; x += 100)
                c.drawRect(x, WORLD / 2f - 3, x + 50, WORLD / 2f + 3, p);
            int sy = (int)(camY / 100) * 100;
            for (int y = sy; y < camY + vh + 100; y += 100)
                c.drawRect(WORLD / 2f - 3, y, WORLD / 2f + 3, y + 50, p);
        }

        private void drawHouseFloor(Canvas c, House h) {
            p.setColor(0xFF6A5040);
            c.drawRect(h.x + 20, h.y + 20, h.x + h.w - 20, h.y + h.h - 20, p);
            p.setColor(0xFF5A4030);
            for (int y = (int)(h.y + 20); y < h.y + h.h - 20; y += 30)
                c.drawRect(h.x + 20, y, h.x + h.w - 20, y + 2, p);
        }

        private void drawWall(Canvas c, Wall w) {
            p.setColor(0xFF8B6F47);
            c.drawRect(w.x, w.y, w.x + w.w, w.y + w.h, p);
            p.setColor(0xFFA6855A);
            c.drawRect(w.x, w.y, w.x + w.w, w.y + 4, p);
            p.setColor(0xFF5A4025);
            c.drawRect(w.x, w.y + w.h - 4, w.x + w.w, w.y + w.h, p);
        }

        private void drawRoof(Canvas c, House h) {
            p.setColor(0xBB3A2A1A);
            c.drawRect(h.x + 20, h.y + 20, h.x + h.w - 20, h.y + h.h - 20, p);
            p.setColor(0xCC1A0F08);
            c.drawLine(h.x + h.w / 2f, h.y + 20, h.x + h.w / 2f, h.y + h.h - 20, p);
        }

        private void drawTree(Canvas c, Tree t) {
            p.setColor(0xFF5A3A1A);
            c.drawRect(t.x - 4, t.y - 2, t.x + 4, t.y + t.size * 0.6f, p);
            float r = t.size;
            p.setColor(0xFF1F3A1A); c.drawCircle(t.x, t.y - r * 0.5f, r, p);
            p.setColor(0xFF2E5A2E); c.drawCircle(t.x - r * 0.3f, t.y - r * 0.7f, r * 0.75f, p);
            p.setColor(0xFF4A7A3A); c.drawCircle(t.x - r * 0.4f, t.y - r * 0.9f, r * 0.45f, p);
        }

        private void drawRock(Canvas c, Rock r) {
            Path path = new Path();
            path.moveTo(r.x - r.size, r.y + r.size * 0.5f);
            path.lineTo(r.x - r.size * 0.8f, r.y - r.size * 0.5f);
            path.lineTo(r.x - r.size * 0.2f, r.y - r.size);
            path.lineTo(r.x + r.size * 0.5f, r.y - r.size * 0.7f);
            path.lineTo(r.x + r.size, r.y + r.size * 0.3f);
            path.lineTo(r.x + r.size * 0.5f, r.y + r.size * 0.7f);
            path.lineTo(r.x - r.size * 0.5f, r.y + r.size * 0.8f);
            path.close();
            p.setColor(0xFF6A6A6A); c.drawPath(path, p);
        }

        private void drawAltar(Canvas c) {
            if (bossSummoned) {
                p.setColor(0x44550000);
                c.drawCircle(altarX, altarY, 60, p);
                stroke.setColor(0x44880000); stroke.setStrokeWidth(3);
                c.drawCircle(altarX, altarY, 60, stroke);
                return;
            }
            long t = System.currentTimeMillis();
            float pulse = (float)Math.sin(t / 300.0) * 0.5f + 0.5f;
            p.setColor(0x33FF0000);
            c.drawCircle(altarX, altarY, 70 + pulse * 10, p);
            p.setColor(0x66FF0000);
            c.drawCircle(altarX, altarY, 55, p);
            stroke.setColor(0xFFFF0000); stroke.setStrokeWidth(4);
            c.drawCircle(altarX, altarY, 55, stroke);
            textP.setColor(0xFFFFD700); textP.setTextSize(14);
            c.drawText("BOSS", altarX, altarY - 70, textP);
            textP.setColor(0xFFFFFFFF); textP.setTextSize(12);
            c.drawText("点击召唤", altarX, altarY + 80, textP);
        }

        private void drawBox(Canvas c, Box b) {
            p.setColor(0x44000000);
            c.drawOval(new RectF(b.x - 22, b.y + 14, b.x + 22, b.y + 22), p);
            if (b.isDropped) {
                p.setColor(0xFF4A3A2A);
                c.drawRect(b.x - 14, b.y - 14, b.x + 14, b.y + 14, p);
                stroke.setColor(0xFFFF5252); stroke.setStrokeWidth(2);
                c.drawRect(b.x - 14, b.y - 14, b.x + 14, b.y + 14, stroke);
                return;
            }
            p.setColor(0xFF4A3A2A);
            c.drawRect(b.x - 18, b.y - 18, b.x + 18, b.y + 18, p);
            p.setColor(0xFF6A5A3A);
            c.drawRect(b.x - 18, b.y - 22, b.x + 18, b.y - 12, p);
            stroke.setColor(UI.ORANGE); stroke.setStrokeWidth(2);
            c.drawRect(b.x - 18, b.y - 18, b.x + 18, b.y + 18, stroke);
            p.setColor(0xFFFFD700);
            c.drawRect(b.x - 3, b.y - 3, b.x + 3, b.y + 3, p);
        }

        private void drawPlayer(Canvas c) {
            drawCharacter(c, px, py, facingX, facingY, 0xFF3D5A88, 0xFF6B9BD1, 24,
                    s.weapon != null, false);
        }

        private void drawEnemy(Canvas c, Enemy e) {
            int body, head;
            float size = 22;
            boolean isBoss = e.tpl.id != null && e.tpl.id.startsWith("BOSS");
            if (isBoss) { body = 0xFF6B3A1A; head = 0xFF8B5A2A; size = 30; }
            else if (e.tpl.hp >= 200) { body = 0xFF3A3A3A; head = 0xFF5A5A5A; size = 26; }
            else if (e.tpl.hp >= 130) { body = 0xFF5A1A5A; head = 0xFF8A2A8A; size = 24; }
            else if (e.tpl.hp >= 90) { body = 0xFF6B2A2A; head = 0xFF8B3A3A; size = 22; }
            else { body = 0xFF4A2A2A; head = 0xFF6A3A3A; size = 20; }
            if (e.hurt > 0) { body = 0xFFFFFFFF; head = 0xFFFFFFFF; }
            if (e.stunned > 0 || e.empLeft > 0) { body = 0xFFAA66FF; head = 0xFFCC88FF; }
            drawCharacter(c, e.x, e.y, e.fx, e.fy, body, head, size, true, true);
            p.setColor(0xFF300000);
            c.drawRect(e.x - 22, e.y - size - 20, e.x + 22, e.y - size - 14, p);
            p.setColor(0xFFFF3B3B);
            c.drawRect(e.x - 22, e.y - size - 20,
                    e.x - 22 + 44f * e.hp / e.tpl.hp, e.y - size - 14, p);
            if (e.alert) {
                textP.setColor(0xFFFF3B3B); textP.setTextSize(20);
                c.drawText("!", e.x, e.y - size - 26, textP);
            }
        }

        private void drawCharacter(Canvas c, float x, float y, float fx, float fy,
                                   int bodyColor, int headColor, float size,
                                   boolean hasGun, boolean isEnemy) {
            p.setColor(0x66000000);
            c.drawOval(new RectF(x - size * 0.7f, y + size * 0.75f,
                    x + size * 0.7f, y + size * 1.0f), p);
            double ang = Math.atan2(fy, fx);
            p.setColor(bodyColor);
            RectF bodyR = new RectF(x - size * 0.45f, y - size * 0.3f,
                    x + size * 0.45f, y + size * 0.7f);
            c.drawRoundRect(bodyR, size * 0.15f, size * 0.15f, p);
            p.setColor(headColor);
            float headR = size * 0.35f;
            c.drawCircle(x, y - size * 0.55f, headR, p);
            if (isEnemy) {
                p.setColor(adjust(headColor, 0.6f));
                RectF helmet = new RectF(x - headR, y - size * 0.55f - headR,
                        x + headR, y - size * 0.55f - headR * 0.3f);
                c.drawArc(helmet, 180, 180, true, p);
            }
            if (!isEnemy) {
                p.setColor(0xFFFFFFFF);
                float eyeX = x + (float)Math.cos(ang) * headR * 0.4f;
                float eyeY = y - size * 0.55f + (float)Math.sin(ang) * headR * 0.4f;
                c.drawCircle(eyeX, eyeY, size * 0.08f, p);
            }
            if (hasGun) {
                p.setColor(0xFF2A2A2A);
                float gunX = x + (float)Math.cos(ang) * size * 0.8f;
                float gunY = y + (float)Math.sin(ang) * size * 0.8f;
                float gunLen = size * 0.9f;
                float gx2 = gunX + (float)Math.cos(ang) * gunLen;
                float gy2 = gunY + (float)Math.sin(ang) * gunLen;
                p.setStrokeWidth(size * 0.12f);
                c.drawLine(gunX, gunY, gx2, gy2, p);
            }
            if (!hasGun && !isEnemy) {
                p.setColor(0xFFCCCCCC);
                float knifeX = x + (float)Math.cos(ang) * size * 0.7f;
                float knifeY = y + (float)Math.sin(ang) * size * 0.7f;
                float kx2 = knifeX + (float)Math.cos(ang) * size * 0.5f;
                float ky2 = knifeY + (float)Math.sin(ang) * size * 0.5f;
                p.setStrokeWidth(size * 0.08f);
                c.drawLine(knifeX, knifeY, kx2, ky2, p);
            }
        }

        private int adjust(int color, float mul) {
            int r = (int)Math.min(255, ((color >> 16) & 0xFF) * mul);
            int g = (int)Math.min(255, ((color >> 8) & 0xFF) * mul);
            int b = (int)Math.min(255, (color & 0xFF) * mul);
            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            try {
                if (paused) return true;
                if (!inited) {
                    int W = getWidth(), H = getHeight();
                    if (W > 0 && H > 0) {
                        moveCx = UI.dp(ctx, 100);
                        moveCy = H - UI.dp(ctx, 100);
                        aimCx = W - UI.dp(ctx, 100);
                        aimCy = H - UI.dp(ctx, 100);
                        fireCx = W - UI.dp(ctx, 100);
                        fireCy = H - UI.dp(ctx, 240);
                        fireR = UI.dp(ctx, 46);
                        runCx = UI.dp(ctx, 100);
                        runCy = H - UI.dp(ctx, 240);
                        runR = UI.dp(ctx, 38);
                        inited = true;
                    }
                }
                int action = event.getActionMasked();
                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE
                        || action == MotionEvent.ACTION_POINTER_DOWN) {
                    for (int i = 0; i < event.getPointerCount(); i++) {
                        float x = event.getX(i), y = event.getY(i);
                        float mr = UI.dp(ctx, 60);
                        if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 20)) firing = true;
                        else if (Math.hypot(x - runCx, y - runCy) < runR + UI.dp(ctx, 20)) runRequested = true;
                        else if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 90)) {
                            float dx = x - moveCx, dy = y - moveCy;
                            float len = (float)Math.hypot(dx, dy);
                            if (len > mr) { dx = dx / len * mr; dy = dy / len * mr; }
                            moveDx = dx / mr; moveDy = dy / mr;
                        } else if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 90)) {
                            float dx = x - aimCx, dy = y - aimCy;
                            float len = (float)Math.hypot(dx, dy);
                            if (len > mr) { dx = dx / len * mr; dy = dy / len * mr; }
                            aimDx = dx / mr; aimDy = dy / mr;
                            float nlen = (float)Math.hypot(dx, dy);
                            if (nlen > 12) { facingX = dx / nlen; facingY = dy / nlen; }
                        }
                    }
                } else if (action == MotionEvent.ACTION_UP
                        || action == MotionEvent.ACTION_POINTER_UP
                        || action == MotionEvent.ACTION_CANCEL) {
                    int idx = event.getActionIndex();
                    float x = event.getX(idx), y = event.getY(idx);
                    if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 120)) { moveDx = 0; moveDy = 0; }
                    if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 120)) { aimDx = 0; aimDy = 0; }
                    if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 40)) firing = false;
                    if (Math.hypot(x - runCx, y - runCy) < runR + UI.dp(ctx, 40)) runRequested = false;

                    float wx = x / SCALE + camX;
                    float wy = y / SCALE + camY;
                    if (!bossSummoned && Math.hypot(altarX - wx, altarY - wy) < 80
                            && Math.hypot(altarX - px, altarY - py) < 200) {
                        summonBoss();
                        return true;
                    }
                    for (Box b : boxes) {
                        if (Math.hypot(b.x - wx, b.y - wy) < 60
                                && Math.hypot(b.x - px, b.y - py) < 150) {
                            if (listener != null) listener.onOpenContainer(b);
                            break;
                        }
                    }
                }
                return true;
            } catch (Exception e) { e.printStackTrace(); return true; }
        }
    }
}