package com.gunmu.town.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

import java.util.ArrayList;
import java.util.List;

/** 局内游戏（Canvas 绘制 + 双摇杆） */
public class RaidScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private final GameData.MapDef map;
    private final GameData.Difficulty diff;

    // 世界
    private GameView gameView;
    private FrameLayout root;

    // HUD
    private TextView timerView, lootView, killView, ammoView, hpText;
    private View hpFill;
    private LinearLayout medRow;
    private Button extractBtn, reloadBtn;

    // 状态
    private boolean paused = false;
    private boolean over = false;

    public RaidScreen(MainActivity a, GameData.MapDef map, GameData.Difficulty diff) {
        this.act = a; this.ctx = a; this.s = a.state;
        this.map = map; this.diff = diff;
    }

    public View getView() {
        // 跑刀：没枪没刀自动给刀
        if (s.weapon == null && s.melee == null) {
            GameData.Melee k = GameData.MELEES[0];
            GameState.Item it = new GameState.Item();
            it.uid = "U" + System.nanoTime();
            it.id = k.id; it.type = "melee"; it.name = k.name;
            it.price = k.price; it.icon = "🔪"; it.dmg = k.dmg;
            it.rate = k.rate; it.range = k.range;
            s.melee = it;
        }

        root = new FrameLayout(ctx);
        root.setBackgroundColor(UI.BG);

        // 游戏画面
        gameView = new GameView(ctx);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ===== 顶部 HUD =====
        LinearLayout topBar = new LinearLayout(ctx);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 8), UI.dp(ctx, 12), UI.dp(ctx, 8));
        topBar.setBackgroundColor(0x80000000);

        timerView = UI.tv(ctx, "05:00", 14, UI.ORANGE);
        topBar.addView(timerView);
        lootView = UI.tv(ctx, "  🪙 0", 14, UI.GOLD);
        topBar.addView(lootView);
        killView = UI.tv(ctx, "  🎯 0", 14, UI.RED);
        topBar.addView(killView);
        ammoView = UI.tv(ctx, "  🔫 0/0", 14, UI.ORANGE);
        topBar.addView(ammoView);

        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.gravity = android.view.Gravity.CENTER_HORIZONTAL | android.view.Gravity.TOP;
        tlp.topMargin = UI.dp(ctx, 8);
        root.addView(topBar, tlp);

        // ===== 血量条（中下） =====
        LinearLayout bottomCenter = new LinearLayout(ctx);
        bottomCenter.setOrientation(LinearLayout.VERTICAL);
        bottomCenter.setGravity(android.view.Gravity.CENTER_HORIZONTAL);

        FrameLayout hpBar = new FrameLayout(ctx);
        hpBar.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE, UI.dp(ctx, 2), UI.dp(ctx, 12)));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 240), UI.dp(ctx, 22));
        hpBar.setLayoutParams(hlp);

        hpFill = new View(ctx);
        hpFill.setBackground(UI.round(UI.GREEN, 0, 0, UI.dp(ctx, 10)));
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 240), UI.dp(ctx, 22));
        hpFill.setLayoutParams(flp);
        hpBar.addView(hpFill);

        hpText = UI.tv(ctx, "100 / 100", 12, Color.WHITE);
        hpText.setGravity(android.view.Gravity.CENTER);
        hpBar.addView(hpText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        bottomCenter.addView(hpBar);

        medRow = new LinearLayout(ctx);
        medRow.setOrientation(LinearLayout.HORIZONTAL);
        medRow.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = UI.dp(ctx, 6);
        medRow.setLayoutParams(mlp);
        bottomCenter.addView(medRow);
        refreshMeds();

        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        blp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.CENTER_HORIZONTAL;
        blp.bottomMargin = UI.dp(ctx, 24);
        root.addView(bottomCenter, blp);

        // ===== 撤离按钮（右侧中部） =====
        extractBtn = UI.primaryBtn(ctx, "🚁 撤离");
        extractBtn.setBackground(UI.round(0xE64CAF50, 0, 0, UI.dp(ctx, 8)));
        extractBtn.setPadding(UI.dp(ctx, 16), UI.dp(ctx, 12),
                UI.dp(ctx, 16), UI.dp(ctx, 12));
        extractBtn.setOnClickListener(v -> tryExtract());
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        elp.gravity = android.view.Gravity.RIGHT | android.view.Gravity.CENTER_VERTICAL;
        elp.rightMargin = UI.dp(ctx, 16);
        root.addView(extractBtn, elp);

        // ===== 换弹按钮 =====
        reloadBtn = UI.smallBtn(ctx, "R 换弹");
        reloadBtn.setBackground(UI.round(0xCC0D0F0C, UI.ORANGE,
                UI.dp(ctx, 2), UI.dp(ctx, 8)));
        reloadBtn.setTextColor(UI.ORANGE);
        reloadBtn.setOnClickListener(v -> gameView.reload());
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.gravity = android.view.Gravity.RIGHT | android.view.Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 240);
        rlp.bottomMargin = UI.dp(ctx, 40);
        root.addView(reloadBtn, rlp);

        // 启动
        gameView.setOnStatsListener(new GameView.OnStatsListener() {
            @Override
            public void onStats(int hp, int maxHp, int lootValue, int kills,
                                int magAmmo, int magSize, int ammo, int timeLeft) {
                updateHud(hp, maxHp, lootValue, kills, magAmmo, magSize, ammo, timeLeft);
            }
            @Override
            public void onEnd(boolean success) {
                endRaid(success);
            }
            @Override
            public void onMedCount(int count) {
                refreshMeds();
            }
        });

        return root;
    }

    private void refreshMeds() {
        if (medRow == null) return;
        medRow.removeAllViews();
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView tv = UI.tv(ctx, i < s.meds.size() ? s.meds.get(i).icon : "➕",
                    22, UI.GOLD);
            tv.setGravity(android.view.Gravity.CENTER);
            tv.setBackground(UI.round(0xCC0D0F0C,
                    i < s.meds.size() ? UI.ORANGE : UI.BORDER,
                    UI.dp(ctx, 2), UI.dp(ctx, 8)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    UI.dp(ctx, 44), UI.dp(ctx, 44));
            lp.leftMargin = UI.dp(ctx, 4);
            lp.rightMargin = UI.dp(ctx, 4);
            tv.setLayoutParams(lp);
            tv.setOnClickListener(v -> gameView.useMed(idx));
            medRow.addView(tv);
        }
    }

    private void updateHud(int hp, int maxHp, int lootValue, int kills,
                           int magAmmo, int magSize, int ammo, int timeLeft) {
        int m = timeLeft / 60, sec = timeLeft % 60;
        timerView.setText(String.format("%02d:%02d", m, sec));
        lootView.setText("  🪙 " + UI.fmt(lootValue));
        killView.setText("  🎯 " + kills);
        if (s.weapon != null) {
            ammoView.setText("  🔫 " + magAmmo + "/" + magSize + " (" + ammo + ")");
        } else {
            ammoView.setText("  🔪 " + (s.melee != null ? s.melee.name : "刀"));
        }
        int hpPct = maxHp > 0 ? (int)(hp * 100.0 / maxHp) : 0;
        if (hpPct < 0) hpPct = 0;
        FrameLayout.LayoutParams flp = (FrameLayout.LayoutParams) hpFill.getLayoutParams();
        flp.width = UI.dp(ctx, 240) * hpPct / 100;
        hpFill.setLayoutParams(flp);
        hpFill.setBackground(UI.round(hpPct < 30 ? UI.RED : UI.GREEN,
                0, 0, UI.dp(ctx, 10)));
        hpText.setText(hp + " / " + maxHp);
    }

    private void tryExtract() {
        gameView.tryExtract();
    }

    private void endRaid(boolean success) {
        if (over) return;
        over = true;
        s.raids++;
        s.totalLoot += gameView.lootValue;

        GameState.BattleRecord r = new GameState.BattleRecord();
        r.success = success; r.map = map.name;
        r.kills = gameView.kills; r.loot = gameView.lootValue;

        if (success) {
            s.extracts++;
            s.rankPoints += 10;
            for (GameState.Item it : gameView.backpack) s.addToWarehouse(it);
            if (gameView.lootValue > s.bestLoot) s.bestLoot = gameView.lootValue;
            // 任务
            for (GameState.Quest q : s.quests) {
                if (q.done) continue;
                if ("q1".equals(q.id)) { q.progress = Math.min(q.target, q.progress + 1); }
                if (q.progress >= q.target) {
                    q.done = true; s.money += q.reward;
                    if ("q1".equals(q.id) && !s.unlockedMaps.contains("mine"))
                        s.unlockedMaps.add("mine");
                }
            }
        } else {
            s.deaths++;
            s.rankPoints = Math.max(0, s.rankPoints - 5);
            // 装备全丢
            s.weapon = null; s.melee = null; s.armor = null; s.helmet = null;
            s.meds.clear(); s.ammo = 0;
        }
        s.questLog.add(r);
        if (s.questLog.size() > 50) s.questLog.remove(0);
        Save.save(ctx, s);

        // 弹窗
        android.app.AlertDialog.Builder b = new android.app.AlertDialog.Builder(ctx);
        b.setTitle(success ? "✅ 撤离成功" : "❌ 任务失败");
        String msg = success
                ? "带回 " + gameView.backpack.size() + " 件物资\n"
                + "总价值：" + UI.fmt(gameView.lootValue) + " 柯恩币\n"
                + "击杀：" + gameView.kills + "\n段位积分 +10"
                : "你在 " + map.name + " 倒下了\n装备全部丢失，仓库物资安全\n"
                + "本次击杀：" + gameView.kills + "\n段位积分 -5";
        b.setMessage(msg);
        b.setCancelable(false);
        b.setPositiveButton("返回大厅", (d, w) -> act.showLobby());
        b.show();
    }

    // =========================================================
    // ============ Canvas 游戏视图 ============
    // =========================================================
    public class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

        // 世界尺寸
        private static final int WORLD = 4000;
        // 玩家
        public float px = 2000, py = 2000;
        public int hp = 100, maxHp = 100;
        public int magAmmo, magSize, ammo = s.ammo;
        // 时间
        public int timeLeft = 300;
        // 状态
        public int lootValue = 0, kills = 0;
        public List<GameState.Item> backpack = new ArrayList<>();
        public boolean success = false;

        // 敌人
        public static class Enemy {
            public GameData.Enemy tpl;
            public float x, y;
            public int hp;
            public boolean alive = true;
            public long lastShoot = 0;
            public boolean alert = false;
        }
        public List<Enemy> enemies = new ArrayList<>();

        // 容器
        public static class Box {
            public GameData.Container tpl;
            public float x, y;
            public boolean searched = false;
        }
        public List<Box> boxes = new ArrayList<>();

        // 撤离点
        public float ex = 0, ey = 0;

        // 摇杆
        private float moveCx, moveCy, moveDx, moveDy;
        private boolean moveActive = false;
        private float aimCx, aimCy, aimDx, aimDy;
        private boolean aimActive = false;
        private float fireCx, fireCy, fireR;
        private boolean firing = false;
        private float facingX = 1, facingY = 0;

        // 相机
        private float camX, camY;

        // 时间
        private long lastFrame = 0;
        private boolean running = false;
        private Thread thread;

        // 监听
        public interface OnStatsListener {
            void onStats(int hp, int maxHp, int lootValue, int kills,
                         int magAmmo, int magSize, int ammo, int timeLeft);
            void onEnd(boolean success);
            void onMedCount(int count);
        }
        private OnStatsListener listener;

        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

        public GameView(Context c) {
            super(c);
            getHolder().addCallback(this);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(UI.dp(ctx, 3));
            text.setColor(Color.WHITE);
            text.setTextSize(UI.dp(ctx, 12));
            text.setTextAlign(Paint.Align.CENTER);
            initWorld();
        }

        public void setOnStatsListener(OnStatsListener l) { this.listener = l; }

        private void initWorld() {
            // 敌人
            int cnt = randInt(diff.eMin, diff.eMax);
            cnt = (int)(cnt * map.enMul);
            for (int i = 0; i < cnt; i++) {
                Enemy e = new Enemy();
                e.tpl = GameData.ENEMIES[randInt(0, GameData.ENEMIES.length - 1)];
                e.x = randInt(300, WORLD - 300);
                e.y = randInt(300, WORLD - 300);
                e.hp = e.tpl.hp;
                enemies.add(e);
            }
            if (diff.boss) {
                Enemy e = new Enemy();
                e.tpl = GameData.BOSS;
                e.x = randInt(500, WORLD - 500);
                e.y = randInt(500, WORLD - 500);
                e.hp = e.tpl.hp;
                enemies.add(e);
            }
            // 容器
            int bc = (int)(20 * map.lootMul);
            for (int i = 0; i < bc; i++) {
                Box b = new Box();
                b.tpl = GameData.CONTAINERS[randInt(0, GameData.CONTAINERS.length - 1)];
                b.x = randInt(200, WORLD - 200);
                b.y = randInt(200, WORLD - 200);
                boxes.add(b);
            }
            // 撤离点
            ex = randInt(400, WORLD - 400);
            ey = randInt(400, WORLD - 400);

            // 弹药
            if (s.weapon != null) {
                magSize = s.weapon.mag;
                magAmmo = magSize;
            } else {
                magSize = 0; magAmmo = 0;
            }
        }

        public void reload() {
            if (s.weapon == null) return;
            if (s.ammo <= 0) return;
            int need = magSize - magAmmo;
            int take = Math.min(need, s.ammo);
            magAmmo += take;
            s.ammo -= take;
            if (listener != null) listener.onStats(hp, maxHp, lootValue, kills,
                    magAmmo, magSize, s.ammo, timeLeft);
        }

        public void useMed(int idx) {
            if (idx < 0 || idx >= s.meds.size()) return;
            GameState.Item it = s.meds.get(idx);
            int heal = (int)(it.heal * maxHp);
            hp = Math.min(maxHp, hp + heal);
            s.meds.remove(idx);
            Save.save(ctx, s);
            if (listener != null) {
                listener.onMedCount(s.meds.size());
                listener.onStats(hp, maxHp, lootValue, kills, magAmmo, magSize, s.ammo, timeLeft);
            }
        }

        public void tryExtract() {
            float d = (float)Math.hypot(ex - px, ey - py);
            if (d > 150) return;
            success = true;
            stopGame();
        }

        // ===== 绘制 =====
        @Override
        public void run() {
            while (running) {
                long now = System.nanoTime();
                if (lastFrame == 0) lastFrame = now;
                float dt = (now - lastFrame) / 1_000_000_000f;
                lastFrame = now;

                if (!paused) update(dt);
                draw();

                try { Thread.sleep(16); } catch (Exception e) {}
            }
        }

        private long lastSecond = 0;
        private void update(float dt) {
            long now = System.currentTimeMillis();
            if (now - lastSecond >= 1000) {
                lastSecond = now;
                timeLeft--;
                if (timeLeft <= 0) { success = false; stopGame(); return; }
                if (listener != null) listener.onStats(hp, maxHp, lootValue, kills,
                        magAmmo, magSize, s.ammo, timeLeft);
            }

            // 玩家移动
            float speed = (s.weapon == null) ? 420 : 330;
            px += moveDx * speed * dt;
            py += moveDy * speed * dt;
            px = Math.max(30, Math.min(WORLD - 30, px));
            py = Math.max(30, Math.min(WORLD - 30, py));

            // 相机跟随
            camX = px - getWidth() / 2f;
            camY = py - getHeight() / 2f;

            // 敌人 AI
            for (Enemy e : enemies) {
                if (!e.alive) continue;
                float dx = px - e.x, dy = py - e.y;
                float d = (float)Math.hypot(dx, dy);
                if (d < 700) {
                    e.alert = true;
                    if (d > 90) {
                        e.x += dx / d * 90 * dt * 3;
                        e.y += dy / d * 90 * dt * 3;
                    }
                    if (d < 500 && now - e.lastShoot > 1400) {
                        e.lastShoot = now;
                        // 敌人开火
                        int dmg = e.tpl.dmg;
                        double red = 0;
                        if (s.armor != null) red += s.armor.red;
                        if (s.helmet != null) red += s.helmet.red * 0.5;
                        dmg = (int)(dmg * (1 - Math.min(red, 0.85)));
                        hp -= dmg;
                        if (hp < maxHp * 0.3 && s.autoMed && !s.meds.isEmpty()) {
                            useMed(0);
                        }
                        if (hp <= 0) { hp = 0; success = false; stopGame(); return; }
                        if (listener != null) listener.onStats(hp, maxHp, lootValue, kills,
                                magAmmo, magSize, s.ammo, timeLeft);
                    }
                } else {
                    e.alert = false;
                }
            }
        }

        private void draw() {
            Canvas c = getHolder().lockCanvas();
            if (c == null) return;
            try {
                c.drawColor(0xFF0F1408);

                // 地面网格
                p.setColor(0xFF1A201A);
                p.setStrokeWidth(2);
                int gs = 60;
                int startX = (int)(camX / gs) * gs;
                int startY = (int)(camY / gs) * gs;
                for (int x = startX; x < camX + getWidth(); x += gs) {
                    c.drawLine(x - camX, 0, x - camX, getHeight(), p);
                }
                for (int y = startY; y < camY + getHeight(); y += gs) {
                    c.drawLine(0, y - camY, getWidth(), y - camY, p);
                }

                // 撤离点
                float sx = ex - camX, sy = ey - camY;
                stroke.setColor(0xFF4CAF50);
                c.drawCircle(sx, sy, 80, stroke);
                p.setColor(0x304CAF50);
                c.drawCircle(sx, sy, 80, p);
                p.setColor(0xFF4CAF50);
                c.drawText("撤离", sx, sy + 6, text);

                // 容器
                for (Box b : boxes) {
                    if (b.searched) continue;
                    float bx = b.x - camX, by = b.y - camY;
                    if (bx < -50 || bx > getWidth() + 50 || by < -50 || by > getHeight() + 50) continue;
                    p.setColor(0xFF2A2A1A);
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, p);
                    stroke.setColor(UI.ORANGE);
                    c.drawRect(bx - 20, by - 20, bx + 20, by + 20, stroke);
                    text.setTextSize(UI.dp(ctx, 18));
                    c.drawText(b.tpl.icon, bx, by + 8, text);
                    text.setTextSize(UI.dp(ctx, 12));
                }

                // 敌人
                for (Enemy e : enemies) {
                    if (!e.alive) continue;
                    float ex2 = e.x - camX, ey2 = e.y - camY;
                    if (ex2 < -60 || ex2 > getWidth() + 60 || ey2 < -60 || ey2 > getHeight() + 60) continue;
                    p.setColor(e.tpl.id.equals("BOSS") ? 0xFFFFD700 : 0xFFFF3B3B);
                    c.drawCircle(ex2, ey2, 22, p);
                    // 血条
                    p.setColor(0xFF300000);
                    c.drawRect(ex2 - 22, ey2 - 32, ex2 + 22, ey2 - 28, p);
                    p.setColor(0xFFFF3B3B);
                    c.drawRect(ex2 - 22, ey2 - 32, ex2 - 22 + 44 * e.hp / e.tpl.hp, ey2 - 28, p);
                    // 图标
                    text.setTextSize(UI.dp(ctx, 20));
                    text.setColor(Color.WHITE);
                    c.drawText(e.tpl.icon, ex2, ey2 + 8, text);
                    text.setTextSize(UI.dp(ctx, 12));
                    // 警戒
                    if (e.alert) {
                        p.setColor(0xFFFF3B3B);
                        c.drawText("!", ex2, ey2 - 40, text);
                    }
                }

                // 玩家
                float px2 = px - camX, py2 = py - camY;
                p.setColor(0xFFFFD700);
                c.drawCircle(px2, py2, 22, p);
                text.setTextSize(UI.dp(ctx, 24));
                text.setColor(Color.WHITE);
                c.drawText("🧍", px2, py2 + 8, text);
                // 枪口方向
                stroke.setColor(0xFFFFD700);
                c.drawLine(px2, py2, px2 + facingX * 40, py2 + facingY * 40, stroke);
                text.setTextSize(UI.dp(ctx, 12));

                // ===== 摇杆 左 =====
                drawJoystick(c, moveCx, moveCy, moveDx, moveDy, moveActive, 0xFFC8742A);
                // ===== 摇杆 右 =====
                drawJoystick(c, aimCx, aimCy, aimDx, aimDy, aimActive, 0xFFFF5252);
                // ===== 开火按钮 =====
                p.setColor(firing ? 0xFFFF3B3B : 0xCC8A1A1A);
                c.drawCircle(fireCx, fireCy, fireR, p);
                stroke.setColor(0xFFFF3B3B);
                c.drawCircle(fireCx, fireCy, fireR, stroke);
                text.setColor(0xFFFFEB3B);
                text.setTextSize(UI.dp(ctx, 28));
                c.drawText("🔥", fireCx, fireCy + 10, text);
                text.setTextSize(UI.dp(ctx, 12));

                // 开火逻辑在 update 里做，这里只画
                if (firing && s.weapon != null) doFire();

            } finally {
                getHolder().unlockCanvasAndPost(c);
            }
        }

        private void drawJoystick(Canvas c, float cx, float cy, float dx, float dy, boolean active, int color) {
            p.setColor(0x30000000);
            c.drawCircle(cx, cy, UI.dp(ctx, 60), p);
            stroke.setColor(color);
            c.drawCircle(cx, cy, UI.dp(ctx, 60), stroke);
            p.setColor(color);
            c.drawCircle(cx + dx, cy + dy, UI.dp(ctx, 25), p);
        }

        private long lastFire = 0;
        private void doFire() {
            long now = System.currentTimeMillis();
            long interval = s.weapon != null ? Math.max(60, 60000 / s.weapon.rate) : 0;
            if (now - lastFire < interval) return;
            lastFire = now;
            if (magAmmo <= 0) { reload(); return; }
            if (s.ammo <= 0 && magAmmo <= 0) return;
            magAmmo--;
            // 命中判定
            float bx = px + facingX * 40;
            float by = py + facingY * 40;
            GameData.Enemy target = null;
            float best = 1e9f;
            for (Enemy e : enemies) {
                if (!e.alive) continue;
                float dx = e.x - bx, dy = e.y - by;
                float d = (float)Math.hypot(dx, dy);
                if (d > s.weapon.range) continue;
                float dot = dx * facingX + dy * facingY;
                if (dot < 0) continue;
                float perp = Math.abs(dx * facingY - dy * facingX);
                if (perp < 30 && d < best) { best = d; target = e; }
            }
            if (target != null) hitEnemy(target, s.weapon.dmg);
            if (listener != null) listener.onStats(hp, maxHp, lootValue, kills,
                    magAmmo, magSize, s.ammo, timeLeft);
        }

        private void hitEnemy(Enemy e, int dmg) {
            e.hp -= dmg;
            if (e.hp <= 0) {
                e.alive = false;
                kills++;
                s.kills++;
                s.totalKills++;
                GameData.Loot drop = GameData.rollLoot(e.tpl.dropTier, map.lootMul);
                if (drop != null) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = drop.id; it.type = "loot"; it.name = drop.name;
                    it.level = drop.level; it.price = drop.price;
                    it.icon = drop.icon; it.cls = drop.cls;
                    backpack.add(it);
                    lootValue += drop.price;
                }
                if (e.tpl.id.equals("BOSS") && Math.random() < 0.7) {
                    GameState.Item it = new GameState.Item();
                    it.uid = "U" + System.nanoTime();
                    it.id = "L-SP1"; it.type = "loot"; it.name = "镇长的金印章";
                    it.level = 6; it.price = 520000; it.icon = "🔱";
                    backpack.add(it);
                    lootValue += 520000;
                }
            }
        }

        // ===== 触控 =====
        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int action = event.getActionMasked();
            int idx = event.getActionIndex();

            // 初始化摇杆位置（第一次触控）
            if (moveCx == 0) {
                moveCx = UI.dp(ctx, 100);
                moveCy = getHeight() - UI.dp(ctx, 100);
                aimCx = getWidth() - UI.dp(ctx, 100);
                aimCy = getHeight() - UI.dp(ctx, 100);
                fireCx = getWidth() - UI.dp(ctx, 190);
                fireCy = getHeight() - UI.dp(ctx, 190);
                fireR = UI.dp(ctx, 46);
            }

            for (int i = 0; i < event.getPointerCount(); i++) {
                int pid = event.getPointerId(i);
                float x = event.getX(i);
                float y = event.getY(i);

                if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN
                        || action == MotionEvent.ACTION_MOVE) {
                    // 距离左摇杆
                    if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 90)) {
                        moveActive = true;
                        float dx = x - moveCx, dy = y - moveCy;
                        float len = (float)Math.hypot(dx, dy);
                        float max = UI.dp(ctx, 60);
                        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
                        moveDx = dx / max;
                        moveDy = dy / max;
                    }
                    // 距离右摇杆
                    else if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 90)) {
                        aimActive = true;
                        float dx = x - aimCx, dy = y - aimCy;
                        float len = (float)Math.hypot(dx, dy);
                        float max = UI.dp(ctx, 60);
                        if (len > max) { dx = dx / len * max; dy = dy / len * max; }
                        aimDx = dx / max;
                        aimDy = dy / max;
                        float nlen = (float)Math.hypot(dx, dy);
                        if (nlen > 8) {
                            facingX = dx / nlen;
                            facingY = dy / nlen;
                        }
                    }
                    // 开火按钮
                    else if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 20)) {
                        firing = true;
                    }
                }
            }

            if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP
                    || action == MotionEvent.ACTION_CANCEL) {
                float x = event.getX(idx);
                float y = event.getY(idx);
                if (Math.hypot(x - moveCx, y - moveCy) < UI.dp(ctx, 120)) {
                    moveActive = false; moveDx = 0; moveDy = 0;
                }
                if (Math.hypot(x - aimCx, y - aimCy) < UI.dp(ctx, 120)) {
                    aimActive = false; aimDx = 0; aimDy = 0;
                }
                if (Math.hypot(x - fireCx, y - fireCy) < fireR + UI.dp(ctx, 40)) {
                    firing = false;
                }
                // 点击容器搜索
                float wx = x + camX, wy = y + camY;
                for (Box b : boxes) {
                    if (b.searched) continue;
                    if (Math.hypot(b.x - wx, b.y - wy) < 40) {
                        float d = (float)Math.hypot(b.x - px, b.y - py);
                        if (d < 100) {
                            b.searched = true;
                            GameData.Loot drop = GameData.rollLoot(b.tpl.tier, map.lootMul);
                            if (drop != null) {
                                GameState.Item it = new GameState.Item();
                                it.uid = "U" + System.nanoTime();
                                it.id = drop.id; it.type = "loot"; it.name = drop.name;
                                it.level = drop.level; it.price = drop.price;
                                it.icon = drop.icon; it.cls = drop.cls;
                                backpack.add(it);
                                lootValue += drop.price;
                                if (listener != null) listener.onStats(hp, maxHp, lootValue, kills,
                                        magAmmo, magSize, s.ammo, timeLeft);
                            }
                        }
                    }
                }
            }

            return true;
        }

        @Override
        public void surfaceCreated(SurfaceHolder holder) {
            running = true;
            thread = new Thread(this);
            thread.start();
        }

        @Override
        public void surfaceDestroyed(SurfaceHolder holder) {
            stopGame();
        }

        @Override
        public void surfaceChanged(SurfaceHolder holder, int f, int w, int h) {}

        public void stopGame() {
            running = false;
            try { if (thread != null) thread.join(500); } catch (Exception e) {}
            if (listener != null) listener.onEnd(success);
        }

        private int randInt(int min, int max) {
            return min + (int)(Math.random() * (max - min + 1));
        }
    }
}