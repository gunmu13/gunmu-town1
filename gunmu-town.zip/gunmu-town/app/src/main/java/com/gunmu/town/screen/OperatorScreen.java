package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

public class OperatorScreen {
    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    public OperatorScreen(MainActivity a){ act=a; ctx=a; s=a.state; }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), "干员",
                "💰 " + UI.fmt(s.money)));
        ScrollView sc = new ScrollView(ctx);
        LinearLayout list = new LinearLayout(ctx);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12));
        for (GameData.Operator op : GameData.OPERATORS) list.addView(build(op));
        sc.addView(list);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private View build(final GameData.Operator op) {
        boolean owned = s.ownsOperator(op.id);
        boolean current = s.currentOperator.equals(op.id);
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14), UI.dp(ctx,14));
        int border = current ? 0xFFFFD700 : (owned ? UI.GREEN : UI.BORDER);
        card.setBackground(UI.round(UI.PANEL, border, UI.dp(ctx,2), UI.dp(ctx,6)));
        card.addView(UI.tv(ctx, op.icon + " " + op.name, 18, UI.GOLD));
        card.addView(UI.tv(ctx, op.desc, 11, UI.GRAY));
        card.addView(UI.tv(ctx, "⚡ " + op.skillName, 13, 0xFF64B5F6));
        card.addView(UI.tv(ctx, op.skillDesc, 11, UI.GRAY));
        card.addView(UI.tv(ctx, "冷却：" + op.skillCd + " 秒", 10, UI.GRAY));
        Button b;
        if (current) {
            b = UI.smallBtn(ctx, "使用中");
            b.setEnabled(false);
        } else if (owned) {
            b = UI.primaryBtn(ctx, "选择");
            b.setOnClickListener(v -> {
                s.currentOperator = op.id;
                Save.save(ctx, s);
                act.showScreen(getView());
            });
        } else {
            b = UI.primaryBtn(ctx, "解锁 " + UI.fmt(op.price));
            b.setOnClickListener(v -> {
                if (s.money < op.price) {
                    new AlertDialog.Builder(ctx).setMessage("柯恩币不足")
                            .setPositiveButton("好", null).show();
                    return;
                }
                s.money -= op.price;
                s.ownedOperators.add(op.id);
                Save.save(ctx, s);
                act.showScreen(getView());
            });
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = UI.dp(ctx,8);
        b.setLayoutParams(lp);
        card.addView(b);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.bottomMargin = UI.dp(ctx,10);
        card.setLayoutParams(clp);
        return card;
    }
}