package com.gunmu.town.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameState {

    public int money = 500000;
    public List<Item> warehouse = new ArrayList<>();

    public Item weapon, melee, armor, helmet, backpack;
    public List<Item> meds = new ArrayList<>();
    public int ammo = 0;
    public String ammoType = "AM1";

    public Map<String, Map<String, String>> gunParts = new HashMap<>();

    public int raids, extracts, deaths, kills, bestLoot, totalKills, totalLoot;
    public int meleeKills, gunKills, grenadeKills, bossKills, mods;

    public int level = 1, exp = 0, rankPoints = 0;

    public List<Quest> quests = new ArrayList<>();
    public Map<String, Boolean> achievements = new HashMap<>();
    public List<Mail> mails = new ArrayList<>();
    public String lastCheckin = "";
    public int checkinStreak = 0;
    public List<Integer> checkinDays = new ArrayList<>();
    public List<BattleRecord> questLog = new ArrayList<>();
    public List<String> unlockedMaps = new ArrayList<>();
    public boolean sfx = true, autoMed = true, aimAssist = true;

    public int dropRateLevel = 1;
    public boolean devMode = false;

    public String currentOperator = "OP1";
    public List<String> ownedOperators = new ArrayList<>();

    public String safeBoxId = "S1";
    public List<Item> safeBox = new ArrayList<>();

    public List<Item> tacticals = new ArrayList<>();

    public String activeContractId = null;
    public int activeContractProgress = 0;

    public List<Auction> auctions = new ArrayList<>();

    public Map<String, Integer> baseLevels = new HashMap<>();

    public String currentTitle = "TI1";
    public List<String> ownedTitles = new ArrayList<>();
    public List<String> ownedVehicles = new ArrayList<>();

    public int thirst = 100, hunger = 100, fatigue = 0;
    public int radiation = 0, poison = 0, temperature = 37;
    public boolean brokenLeg = false;

    public List<String> lockedWeapons = new ArrayList<>();
    public List<String> dexEntries = new ArrayList<>();
    public List<String> autoSellList = new ArrayList<>();

    public int auctionFee = 0;
    public int insuranceCount = 0;

    public Map<String, Integer> proficiency = new HashMap<>();
    public Map<String, Integer> dailyProgress = new HashMap<>();
    public String lastDailyReset = "";

    public static class Item {
        public String uid, type;
        public String id, name, icon, cls;
        public int level, price, count = 1;
        public int dmg, rate, mag, range, bs;
        public int dur;
        public double red;
        public double heal;
        public String ammoId;
        public double dmgMul;
        public String slot, eff;
        public int combo;
    }

    public static class Quest {
        public String id, name, desc;
        public int target, progress, reward;
        public boolean done;
    }

    public static class Mail {
        public String title, time;
        public int money;
        public String itemType;
        public boolean read;
        public Mail(String title, int money, String itemType) {
            this.title = title;
            this.money = money;
            this.itemType = itemType;
            this.time = new java.text.SimpleDateFormat("MM-dd HH:mm",
                    java.util.Locale.getDefault()).format(new java.util.Date());
        }
    }

    public static class BattleRecord {
        public boolean success;
        public String map;
        public int kills, loot;
    }

    public static class Auction {
        public String itemUid;
        public String itemName, itemIcon, itemCls;
        public int itemLevel, itemPrice, askPrice;
        public long listedAt;
        public boolean sold;
    }

    public static GameState createNew() {
        GameState s = new GameState();
        s.quests.add(quest("q1","首次撤离","完成1次成功撤离",1,20000));
        s.quests.add(quest("q2","消灭5个敌人","累计击杀5名敌人",5,30000));
        s.quests.add(quest("q3","带走3级物品","带出任意3级变卖物",1,15000));
        s.quests.add(quest("q4","击杀镇长","在封锁难度击杀Boss",1,100000));
        s.unlockedMaps.add("town");
        s.unlockedMaps.add("mine");
        s.unlockedMaps.add("facility");
        s.ownedOperators.add("OP1");
        s.ownedTitles.add("TI1");
        s.safeBoxId = "S1";
        s.baseLevels.put("U1", 0);
        s.baseLevels.put("U2", 0);
        s.baseLevels.put("U3", 0);
        s.baseLevels.put("U4", 0);
        s.baseLevels.put("U5", 0);
        s.baseLevels.put("U6", 0);
        s.baseLevels.put("U7", 0);
        s.baseLevels.put("U8", 0);
        s.baseLevels.put("U9", 0);
        s.baseLevels.put("U10", 0);
        s.thirst = 100;
        s.hunger = 100;
        s.fatigue = 0;
        s.radiation = 0;
        s.poison = 0;
        s.temperature = 37;
        Item bk = new Item();
        bk.uid = "BkDefault";
        bk.id = "B0";
        bk.type = "backpack";
        bk.name = "帆布小包";
        bk.icon = "🎒";
        bk.slot = "4";
        bk.count = 1;
        s.backpack = bk;
        return s;
    }

    private static Quest quest(String id, String name, String desc, int target, int reward) {
        Quest q = new Quest();
        q.id = id; q.name = name; q.desc = desc;
        q.target = target; q.reward = reward;
        return q;
    }

    public int equipValue() {
        int v = 0;
        if (weapon != null) v += weapon.price;
        if (melee != null) v += melee.price;
        if (armor != null) v += armor.price;
        if (helmet != null) v += helmet.price;
        if (backpack != null) v += backpack.price;
        for (Item m : meds) v += m.price;
        v += ammo * 3;
        return v;
    }

    public static int expToNext(int lv) { return 100 + (lv - 1) * 80; }

    public String rankName() {
        GameData.Rank r = GameData.RANKS[0];
        for (GameData.Rank x : GameData.RANKS) if (rankPoints >= x.min) r = x;
        return r.icon + " " + r.name;
    }

    public void addToWarehouse(Item it) {
        if (it == null) return;
        if (it.uid == null) it.uid = "U" + System.nanoTime();
        if (it.type == null) it.type = "loot";
        if ("ammo".equals(it.type)) {
            for (Item x : warehouse) {
                if ("ammo".equals(x.type) && x.ammoId != null && x.ammoId.equals(it.ammoId)) {
                    x.count += it.count;
                    return;
                }
            }
        }
        warehouse.add(it);
    }

    public void removeFromWarehouse(String uid) {
        for (int i = 0; i < warehouse.size(); i++) {
            if (warehouse.get(i).uid.equals(uid)) { warehouse.remove(i); return; }
        }
    }

    public float dropRateMultiplier() {
        switch (dropRateLevel) {
            case 0: return 0.5f;
            case 2: return 1.5f;
            case 3: return 2.5f;
            case 4: return 4.0f;
            case 5: return 8.0f;
            default: return 1.0f;
        }
    }

    public boolean ownsOperator(String id) { return ownedOperators.contains(id); }
    public boolean ownsTitle(String id) { return ownedTitles.contains(id); }
    public boolean ownsVehicle(String id) { return ownedVehicles.contains(id); }

    public int safeBoxSize() {
        GameData.SafeBox b = GameData.findSafeBox(safeBoxId);
        int base = b != null ? b.size : 1;
        int extra = baseLevels.containsKey("U4") ? baseLevels.get("U4") : 0;
        return base + extra;
    }

    public int safeBoxUsed() {
        int n = 0;
        for (Item it : safeBox) n += GameData.lootSize(it.level);
        return n;
    }

    public int warehouseCapacity() {
        int base = 200;
        int extra = baseLevels.containsKey("U1") ? baseLevels.get("U1") * 50 : 0;
        return base + extra;
    }

    public int baseLevel(String id) {
        return baseLevels.containsKey(id) ? baseLevels.get(id) : 0;
    }

    public int upgradeCost(String id) {
        GameData.BaseUpgrade u = GameData.findUpgrade(id);
        int lv = baseLevel(id);
        return (int)(u.priceBase * Math.pow(u.priceMul, lv));
    }

    public int getProficiency(String weaponId) {
        return proficiency.containsKey(weaponId) ? proficiency.get(weaponId) : 0;
    }

    public void addProficiency(String weaponId, int n) {
        int cur = getProficiency(weaponId);
        proficiency.put(weaponId, cur + n);
    }

    public int getDailyProgress(String questId) {
        return dailyProgress.containsKey(questId) ? dailyProgress.get(questId) : 0;
    }

    public void addDailyProgress(String questId, int n) {
        int cur = getDailyProgress(questId);
        dailyProgress.put(questId, cur + n);
    }

    public boolean isDexCollected(String id) { return dexEntries.contains(id); }

    public float expMultiplier() {
        int lv = baseLevel("U7");
        return 1.0f + lv * 0.20f;
    }

    public float armorDurMul() {
        int lv = baseLevel("U6");
        return 1.0f + lv * 0.10f;
    }

    public float auctionFeeMul() {
        int lv = baseLevel("U8");
        return 1.0f - lv * 0.10f;
    }

    public float insuranceReturnRate() {
        int lv = baseLevel("U9");
        return 0.50f + lv * 0.05f;
    }

    public boolean isMapUnlocked(String id) {
        if ("town".equals(id)) return true;
        return unlockedMaps.contains(id);
    }
}