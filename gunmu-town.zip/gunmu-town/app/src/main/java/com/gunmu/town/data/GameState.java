package com.gunmu.town.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameState {

    public int money = 500000;
    public List<Item> warehouse = new ArrayList<>();

    public Item weapon, melee, armor, helmet, backpack;
    public List<Item> meds = new ArrayList<>();
    public int ammo = 0;
    public String ammoType = "AM1";

    public Map<String, Map<String, String>> gunParts = new HashMap<>();

    public int raids, extracts, deaths, kills, bestLoot, totalKills, totalLoot;
    public int meleeKills, gunKills, grenadeKills, bossKills, mods;

    public int level = 1;
    public int exp = 0;
    public int rankPoints = 0;

    public List<Quest> quests = new ArrayList<>();
    public Map<String, Boolean> achievements = new HashMap<>();
    public List<Mail> mails = new ArrayList<>();
    public String lastCheckin = "";
    public int checkinStreak = 0;
    public List<Integer> checkinDays = new ArrayList<>();
    public List<BattleRecord> questLog = new ArrayList<>();
    public List<String> unlockedMaps = new ArrayList<>();
    public boolean sfx = true, autoMed = true, aimAssist = true;

    public static class Item {
        public String uid, type;
        public String id, name, icon, cls;
        public int level, price, count = 1;
        public int dmg, rate, mag, range, bs;
        public int dur;
        public double red;
        public double heal;
        public String ammoId;
        public double dmgMul;
        public String slot, eff;
    }

    public static class Quest {
        public String id, name, desc;
        public int target, progress, reward;
        public boolean done;
    }

    public static class Mail {
        public String title, time;
        public int money;
        public String itemType;
        public boolean read;
        public Mail(String title, int money, String itemType) {
            this.title = title;
            this.money = money;
            this.itemType = itemType;
            this.time = new java.text.SimpleDateFormat("MM-dd HH:mm",
                    java.util.Locale.getDefault()).format(new java.util.Date());
        }
    }

    public static class BattleRecord {
        public boolean success;
        public String map;
        public int kills, loot;
    }

    public static GameState createNew() {
        GameState s = new GameState();
        s.quests.add(quest("q1","首次撤离","完成1次成功撤离",1,20000));
        s.quests.add(quest("q2","消灭5个敌人","累计击杀5名敌人",5,30000));
        s.quests.add(quest("q3","带走3级物品","带出任意3级变卖物",1,15000));
        s.quests.add(quest("q4","击杀镇长","在封锁难度击杀Boss",1,100000));
        s.unlockedMaps.add("town");
        Item bk = new Item();
        bk.uid = "BkDefault";
        bk.id = "B0";
        bk.type = "backpack";
        bk.name = "帆布小包";
        bk.icon = "🎒";
        bk.slot = "4";
        bk.count = 1;
        s.backpack = bk;
        return s;
    }

    private static Quest quest(String id, String name, String desc, int target, int reward) {
        Quest q = new Quest();
        q.id = id; q.name = name; q.desc = desc;
        q.target = target; q.reward = reward;
        return q;
    }

    public int equipValue() {
        int v = 0;
        if (weapon != null) v += weapon.price;
        if (melee != null) v += melee.price;
        if (armor != null) v += armor.price;
        if (helmet != null) v += helmet.price;
        if (backpack != null) v += backpack.price;
        for (Item m : meds) v += m.price;
        v += ammo * 3;
        return v;
    }

    public static int expToNext(int lv) { return 100 + (lv - 1) * 80; }

    public String rankName() {
        GameData.Rank r = GameData.RANKS[0];
        for (GameData.Rank x : GameData.RANKS) if (rankPoints >= x.min) r = x;
        return r.icon + " " + r.name;
    }

    public void addToWarehouse(Item it) {
        if (it == null) return;
        if (it.uid == null) it.uid = "U" + System.nanoTime();
        if (it.type == null) it.type = "loot";
        if ("ammo".equals(it.type)) {
            for (Item x : warehouse) {
                if ("ammo".equals(x.type) && x.ammoId != null && x.ammoId.equals(it.ammoId)) {
                    x.count += it.count;
                    return;
                }
            }
        }
        warehouse.add(it);
    }

    public void removeFromWarehouse(String uid) {
        for (int i = 0; i < warehouse.size(); i++) {
            if (warehouse.get(i).uid.equals(uid)) { warehouse.remove(i); return; }
        }
    }
}