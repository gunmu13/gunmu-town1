package com.gunmu.town.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 玩家存档状态 */
public class GameState {

    public int money = 500000;
    public List<Item> warehouse = new ArrayList<>();

    // 装备槽
    public Item weapon, melee, armor, helmet;
    public List<Item> meds = new ArrayList<>();
    public int ammo = 0;
    public String ammoType = "AM1";

    // 配件：gunUid -> (slot -> partId)
    public Map<String, Map<String, String>> gunParts = new HashMap<>();

    // 统计
    public int raids, extracts, deaths, kills, bestLoot, totalKills, totalLoot;
    public int meleeKills, gunKills, grenadeKills, bossKills, mods;

    // 玩家等级
    public int level = 1;
    public int exp = 0;
    public int rankPoints = 0;

    // 任务（4个）
    public List<Quest> quests = new ArrayList<>();
    // 成就解锁
    public Map<String, Boolean> achievements = new HashMap<>();
    // 邮件
    public List<Mail> mails = new ArrayList<>();
    // 签到
    public String lastCheckin = "";
    public int checkinStreak = 0;
    public List<Integer> checkinDays = new ArrayList<>();
    // 战报
    public List<BattleRecord> questLog = new ArrayList<>();
    // 解锁地图
    public List<String> unlockedMaps = new ArrayList<>();
    // 设置
    public boolean sfx = true, autoMed = true, aimAssist = true;

    // ============ 内部数据类 ============
    public static class Item {
        public String uid, type;   // type: weapon/melee/armor/helmet/med/ammo/part/loot
        public String id, name, icon, cls;
        public int level, price, count = 1;
        // 武器/近战
        public int dmg, rate, mag, range, bs;
        // 护甲
        public int dur;
        public double red;
        // 药品
        public double heal;
        // 弹药
        public String ammoId;
        public double dmgMul;
        // 配件
        public String slot, eff;

        public Item clone() {
            Item c = new Item();
            c.uid = uid; c.type = type; c.id = id; c.name = name;
            c.icon = icon; c.cls = cls; c.level = level; c.price = price;
            c.count = count; c.dmg = dmg; c.rate = rate; c.mag = mag;
            c.range = range; c.bs = bs; c.dur = dur; c.red = red;
            c.heal = heal; c.ammoId = ammoId; c.dmgMul = dmgMul;
            c.slot = slot; c.eff = eff;
            return c;
        }
    }

    public static class Quest {
        public String id, name, desc;
        public int target, progress, reward;
        public boolean done;
    }

    public static class Mail {
        public String title, time;
        public int money;
        public String itemType;   // "starter" 或有物品
        public boolean read;
        public Mail(String title, int money, String itemType) {
            this.title = title;
            this.money = money;
            this.itemType = itemType;
            this.time = new java.text.SimpleDateFormat("MM-dd HH:mm",
                    java.util.Locale.getDefault()).format(new java.util.Date());
        }
    }

    public static class BattleRecord {
        public boolean success;
        public String map;
        public int kills, loot;
    }

    // ============ 初始化 ============
    public static GameState createNew() {
        GameState s = new GameState();
        s.quests.add(quest("q1","首次撤离","完成1次成功撤离",1,20000));
        s.quests.add(quest("q2","消灭5个敌人","累计击杀5名敌人",5,30000));
        s.quests.add(quest("q3","带走3级物品","带出任意3级变卖物",1,15000));
        s.quests.add(quest("q4","击杀镇长","在封锁难度击杀Boss",1,100000));
        s.unlockedMaps.add("town");
        return s;
    }

    private static Quest quest(String id, String name, String desc, int target, int reward) {
        Quest q = new Quest();
        q.id = id; q.name = name; q.desc = desc;
        q.target = target; q.reward = reward;
        return q;
    }

    /** 装备价值 */
    public int equipValue() {
        int v = 0;
        if (weapon != null) v += weapon.price;
        if (melee != null) v += melee.price;
        if (armor != null) v += armor.price;
        if (helmet != null) v += helmet.price;
        for (Item m : meds) v += m.price;
        v += ammo * 3;
        return v;
    }

    /** 经验升级需求 */
    public static int expToNext(int lv) { return 100 + (lv - 1) * 80; }

    /** 段位名 */
    public String rankName() {
        GameData.Rank r = GameData.RANKS[0];
        for (GameData.Rank x : GameData.RANKS) if (rankPoints >= x.min) r = x;
        return r.icon + " " + r.name;
    }

    /** 加入仓库 */
    public void addToWarehouse(Item it) {
        if (it == null) return;
        if (it.uid == null) it.uid = "U" + System.nanoTime();
        if (it.type == null) it.type = inferType(it);
        if ("ammo".equals(it.type)) {
            for (Item x : warehouse) {
                if ("ammo".equals(x.type) && x.ammoId != null && x.ammoId.equals(it.ammoId)) {
                    x.count += it.count;
                    return;
                }
            }
        }
        warehouse.add(it);
    }

    public void removeFromWarehouse(String uid) {
        for (int i = 0; i < warehouse.size(); i++) {
            if (warehouse.get(i).uid.equals(uid)) { warehouse.remove(i); return; }
        }
    }

    public static String inferType(Item it) {
        if (it.type != null) return it.type;
        return "loot";
    }
}