package com.gunmu.town.screen;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

/** 装备界面 */
public class LoadoutScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;

    public LoadoutScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);

        root.addView(UI.topbar(ctx, () -> act.showLobby(), "装备", null));

        ScrollView scroll = new ScrollView(ctx);
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12));

        // ===== 5 个装备槽 =====
        LinearLayout slotRow = new LinearLayout(ctx);
        slotRow.setOrientation(LinearLayout.HORIZONTAL);

        addSlot(slotRow, "主武器", s.weapon, "weapon");
        addSlot(slotRow, "近战", s.melee, "melee");
        addSlot(slotRow, "护甲", s.armor, "armor");
        addSlot(slotRow, "头盔", s.helmet, "helmet");
        addSlot(slotRow, "药品", s.meds.isEmpty() ? null : s.meds.get(0), "med");

        content.addView(slotRow);

        // 统计
        LinearLayout stats = new LinearLayout(ctx);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, UI.dp(ctx, 10), 0, UI.dp(ctx, 10));
        stats.addView(UI.tv(ctx, "携带价值：" + UI.fmt(s.equipValue()) + " 币", 12, UI.GRAY));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.leftMargin = UI.dp(ctx, 20);
        TextView ammoText = UI.tv(ctx, "枪械弹药：" + s.ammo + " 发", 12, UI.GRAY);
        ammoText.setLayoutParams(sp);
        stats.addView(ammoText);
        content.addView(stats);

        // ===== 仓库可装备 =====
        content.addView(UI.tv(ctx, "仓库可装备（点击穿戴）", 14, UI.ORANGE));

        GridLayout grid = new GridLayout(ctx);
        grid.setColumnCount(6);
        grid.setPadding(0, UI.dp(ctx, 8), 0, 0);

        boolean any = false;
        for (GameState.Item it : s.warehouse) {
            String t = it.type;
            if (!("weapon".equals(t) || "melee".equals(t) || "armor".equals(t)
                    || "helmet".equals(t) || "med".equals(t) || "ammo".equals(t))) continue;
            any = true;
            grid.addView(buildCell(it), cellParams());
        }

        if (!any) {
            TextView e = UI.tv(ctx, "仓库没有可装备物品", 13, UI.GRAY);
            e.setPadding(0, UI.dp(ctx, 20), 0, 0);
            content.addView(e);
        } else {
            content.addView(grid);
        }

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));

        return root;
    }

    private GridLayout.LayoutParams cellParams() {
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = UI.dp(ctx, 78);
        lp.height = UI.dp(ctx, 78);
        lp.setMargins(UI.dp(ctx, 4), UI.dp(ctx, 4), UI.dp(ctx, 4), UI.dp(ctx, 4));
        return lp;
    }

    private void addSlot(LinearLayout parent, String label, GameState.Item it, String key) {
        LinearLayout slot = new LinearLayout(ctx);
        slot.setOrientation(LinearLayout.VERTICAL);
        slot.setGravity(Gravity.CENTER);
        slot.setPadding(UI.dp(ctx, 6), UI.dp(ctx, 8), UI.dp(ctx, 6), UI.dp(ctx, 8));
        boolean filled = it != null;
        slot.setBackground(UI.round(UI.PANEL,
                filled ? UI.ORANGE : UI.BORDER, UI.dp(ctx, 2), UI.dp(ctx, 6)));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                UI.dp(ctx, 80), 1);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        slot.setLayoutParams(lp);

        TextView l = UI.tv(ctx, label, 10, UI.GRAY);
        l.setGravity(Gravity.CENTER);
        slot.addView(l);

        TextView v = UI.tv(ctx, filled ? it.name : "空", 11, filled ? UI.GOLD : UI.GRAY);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        slot.addView(v);

        final GameState.Item item = it;
        final String k = key;
        slot.setOnClickListener(v1 -> {
            if (item != null) unequip(k);
        });

        parent.addView(slot);
    }

    private LinearLayout buildCell(GameState.Item it) {
        LinearLayout cell = new LinearLayout(ctx);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER);
        cell.setBackground(UI.round(UI.PANEL, UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 4)));

        TextView icon = UI.tv(ctx, it.icon != null ? it.icon : "❔", 24, UI.TEXT);
        icon.setGravity(Gravity.CENTER);
        cell.addView(icon);

        TextView name = UI.tv(ctx, it.name, 9, UI.TEXT);
        name.setGravity(Gravity.CENTER);
        name.setSingleLine(true);
        cell.addView(name);

        if (it.count > 1) {
            TextView c = UI.tv(ctx, "×" + it.count, 9, UI.GOLD);
            c.setGravity(Gravity.CENTER);
            cell.addView(c);
        }

        cell.setOnClickListener(v -> equip(it));
        return cell;
    }

    private void equip(GameState.Item it) {
        if ("med".equals(it.type)) {
            if (s.meds.size() >= 3) return;
            s.removeFromWarehouse(it.uid);
            s.meds.add(it);
        } else if ("ammo".equals(it.type)) {
            s.ammo += it.count;
            s.ammoType = it.ammoId;
            s.removeFromWarehouse(it.uid);
        } else {
            GameState.Item old = null;
            if ("weapon".equals(it.type)) old = s.weapon;
            else if ("melee".equals(it.type)) old = s.melee;
            else if ("armor".equals(it.type)) old = s.armor;
            else if ("helmet".equals(it.type)) old = s.helmet;

            if (old != null) s.addToWarehouse(old);
            s.removeFromWarehouse(it.uid);
            if ("weapon".equals(it.type)) s.weapon = it;
            else if ("melee".equals(it.type)) s.melee = it;
            else if ("armor".equals(it.type)) s.armor = it;
            else if ("helmet".equals(it.type)) s.helmet = it;
        }
        Save.save(ctx, s);
        act.showScreen(getView());
    }

    private void unequip(String key) {
        if ("med".equals(key)) {
            for (GameState.Item m : s.meds) s.addToWarehouse(m);
            s.meds.clear();
        } else if ("weapon".equals(key)) {
            if (s.weapon != null) s.addToWarehouse(s.weapon);
            s.weapon = null;
        } else if ("melee".equals(key)) {
            if (s.melee != null) s.addToWarehouse(s.melee);
            s.melee = null;
        } else if ("armor".equals(key)) {
            if (s.armor != null) s.addToWarehouse(s.armor);
            s.armor = null;
        } else if ("helmet".equals(key)) {
            if (s.helmet != null) s.addToWarehouse(s.helmet);
            s.helmet = null;
        }
        Save.save(ctx, s);
        act.showScreen(getView());
    }
}