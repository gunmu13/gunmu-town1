package com.gunmu.town.screen;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.util.UI;

/** 大厅：左侧菜单 + 中间地图名 + 右下出击 */
public class LobbyScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private FrameLayout root;

    public LobbyScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        root = new FrameLayout(ctx);
        root.setBackgroundColor(UI.BG);

        // ===== 左侧菜单 =====
        ScrollView menuScroll = new ScrollView(ctx);
        LinearLayout menu = new LinearLayout(ctx);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8));

        addMenuBtn(menu, "🎒 仓库",   () -> act.showScreen(new WarehouseScreen(act).getView()));
        addMenuBtn(menu, "🛒 市场",   () -> act.showScreen(new MarketScreen(act).getView()));
        addMenuBtn(menu, "🔫 装备",   () -> act.showScreen(new LoadoutScreen(act).getView()));
        addMenuBtn(menu, "🗺 出击",   () -> act.showScreen(new MapScreen(act).getView()));
        addMenuBtn(menu, "📋 任务",   () -> act.showScreen(new SimpleScreen(act, "任务").buildTasks()));
        addMenuBtn(menu, "🏅 成就",   () -> act.showScreen(new SimpleScreen(act, "成就").buildAchievements()));
        addMenuBtn(menu, "📧 邮件",   () -> act.showScreen(new SimpleScreen(act, "邮件").buildMails()));
        addMenuBtn(menu, "📅 签到",   () -> act.showScreen(new SimpleScreen(act, "签到").buildCheckin()));
        addMenuBtn(menu, "🏆 段位",   () -> act.showScreen(new SimpleScreen(act, "段位").buildRank()));
        addMenuBtn(menu, "📜 战报",   () -> act.showScreen(new SimpleScreen(act, "战报").buildLogs()));
        addMenuBtn(menu, "⚙️ 设置",   () -> act.showScreen(new SimpleScreen(act, "设置").buildSettings()));

        menuScroll.addView(menu);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 160), ViewGroup.LayoutParams.MATCH_PARENT);
        mlp.gravity = Gravity.LEFT;
        root.addView(menuScroll, mlp);

        // ===== 中间地图名 =====
        LinearLayout center = new LinearLayout(ctx);
        center.setOrientation(LinearLayout.VERTICAL);
        center.setGravity(Gravity.CENTER);

        String lastMap = s.unlockedMaps.isEmpty() ? "town" : s.unlockedMaps.get(s.unlockedMaps.size()-1);
        GameData.MapDef mapDef = GameData.MAPS[0];
        for (GameData.MapDef m : GameData.MAPS) if (m.id.equals(lastMap)) mapDef = m;

        TextView bigName = UI.tv(ctx, mapDef.name, 48, UI.ORANGE);
        bigName.setGravity(Gravity.CENTER);
        center.addView(bigName);

        TextView desc = UI.tv(ctx, mapDef.desc, 14, UI.GRAY);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dp2.topMargin = UI.dp(ctx, 8);
        desc.setLayoutParams(dp2);
        center.addView(desc);

        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.gravity = Gravity.CENTER;
        root.addView(center, clp);

        // ===== 右下出击按钮 =====
        LinearLayout rightBottom = new LinearLayout(ctx);
        rightBottom.setOrientation(LinearLayout.VERTICAL);
        rightBottom.setGravity(Gravity.RIGHT | Gravity.BOTTOM);

        // 装备预览
        LinearLayout preview = new LinearLayout(ctx);
        preview.setOrientation(LinearLayout.HORIZONTAL);
        preview.setBackground(UI.round(0xCC0D0F0C, UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 6)));
        preview.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 6), UI.dp(ctx, 8), UI.dp(ctx, 6));
        addPreview(preview, "主武器", s.weapon);
        addPreview(preview, "护甲", s.armor);
        addPreview(preview, "头盔", s.helmet);
        rightBottom.addView(preview);

        // 出击按钮
        android.widget.Button goBtn = new android.widget.Button(ctx);
        goBtn.setText("▶ 开 始 行 动");
        goBtn.setTextSize(20);
        goBtn.setTextColor(UI.BG);
        goBtn.setAllCaps(false);
        goBtn.setBackground(UI.round(UI.ORANGE, UI.GOLD, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 220), UI.dp(ctx, 64));
        bp.topMargin = UI.dp(ctx, 10);
        goBtn.setLayoutParams(bp);
        goBtn.setOnClickListener(v -> act.showScreen(new MapScreen(act).getView()));
        rightBottom.addView(goBtn);

        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 24);
        rlp.bottomMargin = UI.dp(ctx, 24);
        root.addView(rightBottom, rlp);

        // ===== 左下系统日志 =====
        LinearLayout logBox = new LinearLayout(ctx);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logBox.addView(UI.tv(ctx, "▸ 携带价值：" + UI.fmt(s.equipValue()) + " 币", 11, UI.GRAY));
        logBox.addView(UI.tv(ctx, "▸ 累计撤离：" + s.extracts + " 次", 11, UI.GRAY));
        logBox.addView(UI.tv(ctx, "▸ 最佳战利：" + UI.fmt(s.bestLoot) + " 币", 11, UI.GRAY));
        int unread = 0;
        for (GameState.Mail m : s.mails) if (!m.read) unread++;
        logBox.addView(UI.tv(ctx, "▸ 未读邮件：" + unread + " 封", 11, UI.GRAY));

        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.gravity = Gravity.LEFT | Gravity.BOTTOM;
        llp.leftMargin = UI.dp(ctx, 24);
        llp.bottomMargin = UI.dp(ctx, 24);
        root.addView(logBox, llp);

        return root;
    }

    private void addMenuBtn(LinearLayout parent, String text, Runnable action) {
        android.widget.Button b = new android.widget.Button(ctx);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(UI.TEXT);
        b.setBackground(UI.round(0xCC0D0F0C, UI.BORDER, UI.dp(ctx, 1), 0));
        b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 42));
        lp.topMargin = UI.dp(ctx, 4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        parent.addView(b);
    }

    private void addPreview(LinearLayout parent, String label, GameState.Item it) {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 80), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        col.setLayoutParams(lp);

        TextView l = UI.tv(ctx, label, 9, UI.GRAY);
        l.setGravity(Gravity.CENTER);
        col.addView(l);

        TextView v = UI.tv(ctx, it != null ? it.name : "—", 11, UI.ORANGE);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        col.addView(v);

        parent.addView(col);
    }
}