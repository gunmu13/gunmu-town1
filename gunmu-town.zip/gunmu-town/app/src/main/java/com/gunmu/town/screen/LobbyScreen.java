package com.gunmu.town.screen;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.util.UI;

/** 大厅 */
public class LobbyScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private FrameLayout root;

    public LobbyScreen(MainActivity a) {
        this.act = a;
        this.ctx = a;
        this.s = a.state;
    }

    public View getView() {
        root = new FrameLayout(ctx);
        root.setBackgroundColor(UI.BG);

        // 背景：根据当前地图决定主题
        String curMap = s.unlockedMaps.isEmpty() ? "town" : s.unlockedMaps.get(s.unlockedMaps.size()-1);
        MapTheme theme = getTheme(curMap);
        MapBackdropView backdrop = new MapBackdropView(ctx, theme);
        root.addView(backdrop, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 左侧菜单
        ScrollView menuScroll = new ScrollView(ctx);
        LinearLayout menu = new LinearLayout(ctx);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8), UI.dp(ctx, 8));

        addMenuBtn(menu, "🎒 仓库",   () -> act.showScreen(new WarehouseScreen(act).getView()));
        addMenuBtn(menu, "🛒 市场",   () -> act.showScreen(new MarketScreen(act).getView()));
        addMenuBtn(menu, "🔫 装备",   () -> act.showScreen(new LoadoutScreen(act).getView()));
        addMenuBtn(menu, "🗺 出击",   () -> act.showScreen(new MapScreen(act).getView()));
        addMenuBtn(menu, "📋 任务",   () -> act.showScreen(new SimpleScreen(act, "任务").buildTasks()));
        addMenuBtn(menu, "🏅 成就",   () -> act.showScreen(new SimpleScreen(act, "成就").buildAchievements()));
        addMenuBtn(menu, "📧 邮件",   () -> act.showScreen(new SimpleScreen(act, "邮件").buildMails()));
        addMenuBtn(menu, "📅 签到",   () -> act.showScreen(new SimpleScreen(act, "签到").buildCheckin()));
        addMenuBtn(menu, "🏆 段位",   () -> act.showScreen(new SimpleScreen(act, "段位").buildRank()));
        addMenuBtn(menu, "📜 战报",   () -> act.showScreen(new SimpleScreen(act, "战报").buildLogs()));
        addMenuBtn(menu, "⚙️ 设置",   () -> act.showScreen(new SimpleScreen(act, "设置").buildSettings()));
        addMenuBtn(menu, "🎖️ 干员",   () -> act.showScreen(new OperatorScreen(act).getView()));
addMenuBtn(menu, "📋 合同",   () -> act.showScreen(new ContractScreen(act).getView()));
addMenuBtn(menu, "🏠 据点",   () -> act.showScreen(new BaseScreen(act).getView()));
addMenuBtn(menu, "🏪 交易行", () -> act.showScreen(new AuctionScreen(act).getView()));
addMenuBtn(menu, "📅 每日",   () -> act.showScreen(new DailyScreen(act).getView()));

        menuScroll.addView(menu);
        FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 160), ViewGroup.LayoutParams.MATCH_PARENT);
        mlp.gravity = Gravity.LEFT;
        root.addView(menuScroll, mlp);

        // 中间地图名（用自定义 View 绘制，带风格）
        MapTitleView titleView = new MapTitleView(ctx, theme);
        FrameLayout.LayoutParams tlp = new FrameLayout.LayoutParams(
                UI.dp(ctx, 400), UI.dp(ctx, 200));
        tlp.gravity = Gravity.CENTER;
        root.addView(titleView, tlp);

        // 右下出击按钮 + 装备预览
        LinearLayout rightBottom = new LinearLayout(ctx);
        rightBottom.setOrientation(LinearLayout.VERTICAL);
        rightBottom.setGravity(Gravity.RIGHT | Gravity.BOTTOM);

        LinearLayout preview = new LinearLayout(ctx);
        preview.setOrientation(LinearLayout.HORIZONTAL);
        preview.setBackground(UI.round(0xCC0D0F0C, UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 6)));
        preview.setPadding(UI.dp(ctx, 8), UI.dp(ctx, 6), UI.dp(ctx, 8), UI.dp(ctx, 6));
        addPreview(preview, "主武器", s.weapon);
        addPreview(preview, "护甲", s.armor);
        addPreview(preview, "头盔", s.helmet);
        rightBottom.addView(preview);

        android.widget.Button goBtn = new android.widget.Button(ctx);
        goBtn.setText("▶ 开 始 行 动");
        goBtn.setTextSize(20);
        goBtn.setTextColor(UI.BG);
        goBtn.setAllCaps(false);
        goBtn.setBackground(UI.round(theme.accent, theme.bright, UI.dp(ctx, 2), UI.dp(ctx, 8)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 220), UI.dp(ctx, 64));
        bp.topMargin = UI.dp(ctx, 10);
        goBtn.setLayoutParams(bp);
        goBtn.setOnClickListener(v -> act.showScreen(new MapScreen(act).getView()));
        rightBottom.addView(goBtn);

        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
        rlp.rightMargin = UI.dp(ctx, 24);
        rlp.bottomMargin = UI.dp(ctx, 24);
        root.addView(rightBottom, rlp);

        // 左下系统日志
        LinearLayout logBox = new LinearLayout(ctx);
        logBox.setOrientation(LinearLayout.VERTICAL);
        logBox.addView(UI.tv(ctx, "▸ 携带价值：" + UI.fmt(s.equipValue()) + " 币", 11, UI.GRAY));
        logBox.addView(UI.tv(ctx, "▸ 累计撤离：" + s.extracts + " 次", 11, UI.GRAY));
        logBox.addView(UI.tv(ctx, "▸ 最佳战利：" + UI.fmt(s.bestLoot) + " 币", 11, UI.GRAY));
        int unread = 0;
        for (GameState.Mail m : s.mails) if (!m.read) unread++;
        logBox.addView(UI.tv(ctx, "▸ 未读邮件：" + unread + " 封", 11, UI.GRAY));

        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        llp.gravity = Gravity.LEFT | Gravity.BOTTOM;
        llp.leftMargin = UI.dp(ctx, 24);
        llp.bottomMargin = UI.dp(ctx, 24);
        root.addView(logBox, llp);

        return root;
    }

    private void addMenuBtn(LinearLayout parent, String text, Runnable action) {
        android.widget.Button b = new android.widget.Button(ctx);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setTextColor(UI.TEXT);
        b.setBackground(UI.round(0xCC0D0F0C, UI.BORDER, UI.dp(ctx, 1), 0));
        b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(ctx, 42));
        lp.topMargin = UI.dp(ctx, 4);
        b.setLayoutParams(lp);
        b.setOnClickListener(v -> action.run());
        parent.addView(b);
    }

    private void addPreview(LinearLayout parent, String label, GameState.Item it) {
        LinearLayout col = new LinearLayout(ctx);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                UI.dp(ctx, 80), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = UI.dp(ctx, 4);
        lp.rightMargin = UI.dp(ctx, 4);
        col.setLayoutParams(lp);
        TextView l = UI.tv(ctx, label, 9, UI.GRAY);
        l.setGravity(Gravity.CENTER);
        col.addView(l);
        TextView v = UI.tv(ctx, it != null ? it.name : "—", 11, UI.ORANGE);
        v.setGravity(Gravity.CENTER);
        v.setSingleLine(true);
        col.addView(v);
        parent.addView(col);
    }

    // ============ 主题 ============
    public static class MapTheme {
        public int bg, accent, bright, subtitle;
        public String title, sub;
        public int style;  // 0=小镇 1=矿洞 2=军事
    }

    public static MapTheme getTheme(String id) {
        MapTheme t = new MapTheme();
        if ("mine".equals(id)) {
            t.bg = 0xFF2A1F0F;         // 暗棕
            t.accent = 0xFFB8860B;     // 琥珀
            t.bright = 0xFFFFD700;     // 金色
            t.subtitle = 0xFFA88A5A;
            t.title = "废 弃 矿 洞";
            t.sub = "· 塌方频发 · 矿脉藏宝 ·";
            t.style = 1;
        } else if ("facility".equals(id)) {
            t.bg = 0xFF0A1A2A;         // 暗蓝
            t.accent = 0xFF4A7A9A;     // 冷钢蓝
            t.bright = 0xFF64B5F6;     // 亮蓝
            t.subtitle = 0xFF7AA0B8;
            t.title = "旧军事设施";
            t.sub = "// 危险等级：最高 // 机密出没 //";
            t.style = 2;
        } else {
            t.bg = 0xFF0A0D08;
            t.accent = 0xFFC8742A;     // 铜锈橙
            t.bright = 0xFFFFD700;     // 金色
            t.subtitle = 0xFF8A8578;
            t.title = "棍母小镇";
            t.sub = "废弃矿区旁的居民点";
            t.style = 0;
        }
        return t;
    }

    /** 背景装饰（不同地图不同图案） */
    public static class MapBackdropView extends View {
        private final MapTheme theme;
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        public MapBackdropView(Context c, MapTheme t) { super(c); this.theme = t; }
        @Override protected void onDraw(Canvas c) {
            c.drawColor(theme.bg);
            int W = getWidth(), H = getHeight();
            p.setColor((theme.accent & 0x00FFFFFF) | 0x18000000);
            // 对角线网格
            for (int i = -H; i < W + H; i += 80) {
                c.drawLine(i, 0, i + H, H, p);
            }
            // 中心光晕
            p.setColor((theme.accent & 0x00FFFFFF) | 0x22000000);
            c.drawCircle(W * 0.5f, H * 0.5f, Math.min(W, H) * 0.5f, p);
        }
    }

    /** 地图标题（大字 + 副标题，各风格不同） */
    public static class MapTitleView extends View {
        private final MapTheme theme;
        private Paint titleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        private Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
        public MapTitleView(Context c, MapTheme t) {
            super(c);
            this.theme = t;
            titleP.setTextAlign(Paint.Align.CENTER);
            titleP.setFakeBoldText(true);
            subP.setTextAlign(Paint.Align.CENTER);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            int W = getWidth(), H = getHeight();
            float cy = H * 0.5f;

            titleP.setColor(theme.bright);
            titleP.setTextSize(W / 10f);
            titleP.setShadowLayer(20, 0, 0, theme.accent);
            c.drawText(theme.title, W / 2f, cy, titleP);
            titleP.setShadowLayer(0, 0, 0, 0);

            subP.setColor(theme.subtitle);
            subP.setTextSize(W / 28f);
            c.drawText(theme.sub, W / 2f, cy + W / 14f, subP);

            // 上下装饰线
            p.setColor(theme.accent);
            p.setStrokeWidth(2);
            float lineW = W * 0.35f;
            c.drawLine(W / 2f - lineW, cy - W / 13f, W / 2f + lineW, cy - W / 13f, p);
            c.drawLine(W / 2f - lineW, cy + W / 12f, W / 2f + lineW, cy + W / 12f, p);
        }
        private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    }
}