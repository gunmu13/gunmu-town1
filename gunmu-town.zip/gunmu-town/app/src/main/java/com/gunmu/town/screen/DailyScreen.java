package com.gunmu.town.screen;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

public class DailyScreen {
    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    public DailyScreen(MainActivity a){ act=a; ctx=a; s=a.state; }

    public View getView() {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), "每日 & 赛季", null));

        ScrollView sc = new ScrollView(ctx);
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12), UI.dp(ctx,12));

        // 每日任务
        content.addView(UI.tv(ctx, "📋 每日任务（每天刷新）", 14, UI.ORANGE));
        for (GameData.DailyQuest q : GameData.DAILY_QUESTS) {
            content.addView(dailyRow(q));
        }

        // 赛季
        content.addView(UI.tv(ctx, "🏆 赛季通行证", 14, UI.ORANGE));
        int tier = s.level;
        content.addView(UI.tv(ctx, "当前赛季等级：Lv." + tier, 12, UI.GOLD));
        for (GameData.SeasonReward r : GameData.SEASON_REWARDS) {
            boolean unlocked = tier >= r.tier;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(UI.dp(ctx,10), UI.dp(ctx,8), UI.dp(ctx,10), UI.dp(ctx,8));
            row.setBackground(UI.round(unlocked ? 0xFF162A16 : UI.PANEL,
                    unlocked ? UI.GREEN : UI.BORDER, UI.dp(ctx,1), UI.dp(ctx,4)));
            row.addView(UI.tv(ctx, "T" + r.tier, 13, UI.GOLD));
            String txt = (r.itemName != null ? r.itemIcon + " " + r.itemName : "现金礼包")
                    + "  +" + UI.fmt(r.money);
            row.addView(UI.tv(ctx, "  " + txt, 11, unlocked ? UI.GREEN : UI.GRAY));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx,4);
            row.setLayoutParams(lp);
            content.addView(row);
        }

        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    private View dailyRow(GameData.DailyQuest q) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(UI.dp(ctx,10), UI.dp(ctx,8), UI.dp(ctx,10), UI.dp(ctx,8));
        row.setBackground(UI.round(UI.PANEL, UI.BORDER, UI.dp(ctx,1), UI.dp(ctx,4)));
        row.addView(UI.tv(ctx, q.name, 13, UI.GOLD));
        row.addView(UI.tv(ctx, q.desc, 11, UI.GRAY));
        row.addView(UI.tv(ctx, "奖励：" + UI.fmt(q.reward) + " 币", 11, UI.ORANGE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = UI.dp(ctx,6);
        row.setLayoutParams(lp);
        return row;
    }
}