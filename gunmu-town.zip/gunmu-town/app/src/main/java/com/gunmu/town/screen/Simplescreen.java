package com.gunmu.town.screen;

import android.app.AlertDialog;
import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.gunmu.town.MainActivity;
import com.gunmu.town.data.GameData;
import com.gunmu.town.data.GameState;
import com.gunmu.town.data.Save;
import com.gunmu.town.util.UI;

/** 通用：任务/成就/邮件/签到/段位/战报/设置 */
public class SimpleScreen {

    private final MainActivity act;
    private final Context ctx;
    private final GameState s;
    private final String title;

    public SimpleScreen(MainActivity a, String title) {
        this.act = a; this.ctx = a; this.s = a.state;
        this.title = title;
    }

    private View wrap(LinearLayout content) {
        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        root.addView(UI.topbar(ctx, () -> act.showLobby(), title, null));

        ScrollView scroll = new ScrollView(ctx);
        content.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        return root;
    }

    // ===== 任务 =====
    public View buildTasks() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        for (GameState.Quest q : s.quests) {
            LinearLayout card = UI.card(ctx);
            TextView name = UI.tv(ctx, q.name, 16, UI.ORANGE);
            card.addView(name);
            card.addView(UI.tv(ctx, q.desc, 12, UI.GRAY));
            card.addView(UI.tv(ctx, "进度 " + q.progress + "/" + q.target, 12, UI.ORANGE));
            card.addView(UI.tv(ctx, "奖励 " + UI.fmt(q.reward) + " 币", 12, UI.GREEN));
            if (q.done) card.addView(UI.tv(ctx, "✅ 已完成", 12, UI.GREEN));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 8);
            card.setLayoutParams(lp);
            content.addView(card);
        }
        return wrap(content);
    }

    // ===== 成就 =====
    public View buildAchievements() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        int done = 0;
        for (GameData.Achievement a : GameData.ACHIEVEMENTS) {
            boolean ok = s.achievements.containsKey(a.id) && s.achievements.get(a.id);
            if (ok) done++;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 10), UI.dp(ctx, 10), UI.dp(ctx, 10));
            row.setBackground(UI.round(ok ? 0xFF162A16 : UI.PANEL,
                    ok ? UI.GREEN : UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 6)));

            TextView ico = UI.tv(ctx, ok ? "✅" : "⭕", 22, UI.TEXT);
            row.addView(ico);

            LinearLayout info = new LinearLayout(ctx);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            info.addView(UI.tv(ctx, a.name, 13, UI.GOLD));
            info.addView(UI.tv(ctx, a.desc, 11, UI.GRAY));
            row.addView(info);
            row.addView(UI.tv(ctx, UI.fmt(a.reward), 12, UI.ORANGE));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 6);
            row.setLayoutParams(lp);
            content.addView(row);
        }
        TextView head = UI.tv(ctx, "已解锁 " + done + "/" + GameData.ACHIEVEMENTS.length,
                12, UI.GRAY);
        head.setPadding(0, 0, 0, UI.dp(ctx, 8));
        content.addView(head, 0);
        return wrap(content);
    }

    // ===== 邮件 =====
    public View buildMails() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        if (s.mails.isEmpty()) {
            TextView e = UI.tv(ctx, "暂无邮件", 14, UI.GRAY);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, UI.dp(ctx, 60), 0, 0);
            content.addView(e);
            return wrap(content);
        }
        for (int i = 0; i < s.mails.size(); i++) {
            final int idx = i;
            final GameState.Mail m = s.mails.get(i);
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12), UI.dp(ctx, 12));
            row.setBackground(UI.round(m.read ? 0xFF162A16 : UI.PANEL,
                    m.read ? UI.GREEN : UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 6)));

            row.addView(UI.tv(ctx, "📧", 22, UI.TEXT));

            LinearLayout info = new LinearLayout(ctx);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            info.addView(UI.tv(ctx, m.title, 13, UI.GOLD));
            info.addView(UI.tv(ctx, m.time, 11, UI.GRAY));
            row.addView(info);

            if (!m.read) {
                TextView btn = UI.tv(ctx, "领取", 13, UI.ORANGE);
                btn.setPadding(UI.dp(ctx, 10), 0, 0, 0);
                row.addView(btn);
                row.setOnClickListener(v -> readMail(idx));
            }

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 6);
            row.setLayoutParams(lp);
            content.addView(row);
        }
        return wrap(content);
    }

    private void readMail(int idx) {
        GameState.Mail m = s.mails.get(idx);
        if (m.read) return;
        if (m.money > 0) s.money += m.money;
        if ("starter".equals(m.itemType)) {
            s.addToWarehouse(makeItem(GameData.MEDS[1]));
            s.addToWarehouse(makeMelee(GameData.MELEES[1]));
        }
        m.read = true;
        Save.save(ctx, s);
        act.showScreen(buildMails());
    }

    private GameState.Item makeItem(GameData.Med m) {
        GameState.Item it = new GameState.Item();
        it.uid = "U" + System.nanoTime();
        it.id = m.id; it.type = "med"; it.name = m.name;
        it.price = m.price; it.icon = m.icon; it.heal = m.heal;
        return it;
    }
    private GameState.Item makeMelee(GameData.Melee m) {
        GameState.Item it = new GameState.Item();
        it.uid = "U" + System.nanoTime();
        it.id = m.id; it.type = "melee"; it.name = m.name;
        it.price = m.price; it.icon = "🔪";
        it.dmg = m.dmg; it.rate = m.rate; it.range = m.range;
        return it;
    }

    // ===== 签到 =====
    public View buildCheckin() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        String today = new java.text.SimpleDateFormat("yyyyMMdd",
                java.util.Locale.getDefault()).format(new java.util.Date());
        boolean checkedToday = today.equals(s.lastCheckin);

        for (GameData.DailyReward r : GameData.DAILY_REWARDS) {
            boolean done = s.checkinDays.contains(r.day);
            boolean todayCell = !done && !checkedToday
                    && (s.checkinStreak == r.day - 1 || (s.checkinStreak >= 7 && r.day == 1));

            LinearLayout cell = new LinearLayout(ctx);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 10), UI.dp(ctx, 10), UI.dp(ctx, 10));
            int bg = done ? 0xFF162A16 : todayCell ? 0xFF2A2A1A : UI.PANEL;
            int border = done ? UI.GREEN : todayCell ? UI.GOLD : UI.BORDER;
            cell.setBackground(UI.round(bg, border, UI.dp(ctx, 2), UI.dp(ctx, 6)));

            cell.addView(UI.tv(ctx, "第 " + r.day + " 天", 10, UI.GRAY));
            cell.addView(UI.tv(ctx, r.itemId != null ? "🎁" : "💰", 22, UI.TEXT));
            cell.addView(UI.tv(ctx, UI.fmt(r.money), 11, UI.ORANGE));
            if (done) cell.addView(UI.tv(ctx, "已领", 10, UI.GREEN));

            final int d = r.day;
            if (todayCell) cell.setOnClickListener(v -> doCheckin(d));

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 8);
            cell.setLayoutParams(lp);
            content.addView(cell);
        }
        return wrap(content);
    }

    private void doCheckin(int day) {
        String today = new java.text.SimpleDateFormat("yyyyMMdd",
                java.util.Locale.getDefault()).format(new java.util.Date());
        if (today.equals(s.lastCheckin)) { alert("今天已签到"); return; }
        GameData.DailyReward r = null;
        for (GameData.DailyReward x : GameData.DAILY_REWARDS) if (x.day == day) r = x;
        if (r == null) return;
        int expect = (s.checkinStreak % 7) + 1;
        if (day != expect) { alert("请按顺序签到，下一个第 " + expect + " 天"); return; }
        s.money += r.money;
        if (r.itemId != null) {
            GameData.Med m = GameData.findMed(r.itemId);
            if (m != null) s.addToWarehouse(makeItem(m));
            GameData.Melee ml = GameData.findMelee(r.itemId);
            if (ml != null) s.addToWarehouse(makeMelee(ml));
            GameData.Armor ar = GameData.findArmor(r.itemId);
            if (ar != null) {
                GameState.Item it = new GameState.Item();
                it.uid = "U" + System.nanoTime();
                it.id = ar.id; it.type = "armor"; it.name = ar.name;
                it.price = ar.price; it.icon = "🛡️";
                it.dur = ar.dur; it.red = ar.red; it.level = ar.tier;
                s.addToWarehouse(it);
            }
        }
        s.checkinDays.add(day);
        s.checkinStreak++;
        s.lastCheckin = today;
        Save.save(ctx, s);
        act.showScreen(buildCheckin());
    }

    // ===== 段位 =====
    public View buildRank() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout hero = UI.card(ctx);
        TextView big = UI.tv(ctx, s.rankName(), 28, UI.GOLD);
        big.setGravity(Gravity.CENTER);
        hero.addView(big);
        TextView pts = UI.tv(ctx, "段位积分：" + UI.fmt(s.rankPoints), 12, UI.GRAY);
        pts.setGravity(Gravity.CENTER);
        hero.addView(pts);
        TextView rule = UI.tv(ctx, "撤离+10 · 击杀+2 · 死亡-5", 12, UI.ORANGE);
        rule.setGravity(Gravity.CENTER);
        hero.addView(rule);
        content.addView(hero);

        content.addView(UI.tv(ctx, "段位阶梯", 14, UI.ORANGE));

        for (GameData.Rank r : GameData.RANKS) {
            boolean ok = s.rankPoints >= r.min;
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(UI.dp(ctx, 10), UI.dp(ctx, 8), UI.dp(ctx, 10), UI.dp(ctx, 8));
            row.setBackground(UI.round(ok ? 0xFF162A16 : UI.PANEL,
                    ok ? UI.GREEN : UI.BORDER, UI.dp(ctx, 1), UI.dp(ctx, 6)));
            row.addView(UI.tv(ctx, r.icon, 22, UI.TEXT));
            row.addView(UI.tv(ctx, "  " + r.name, 13, UI.GOLD));
            row.addView(UI.tv(ctx, "  " + UI.fmt(r.min) + " 分", 11, UI.GRAY));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 6);
            row.setLayoutParams(lp);
            content.addView(row);
        }
        return wrap(content);
    }

    // ===== 战报 =====
    public View buildLogs() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        if (s.questLog.isEmpty()) {
            TextView e = UI.tv(ctx, "暂无战报", 14, UI.GRAY);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, UI.dp(ctx, 60), 0, 0);
            content.addView(e);
            return wrap(content);
        }
        for (int i = s.questLog.size() - 1; i >= 0; i--) {
            GameState.BattleRecord r = s.questLog.get(i);
            LinearLayout card = UI.card(ctx);
            card.addView(UI.tv(ctx, r.success ? "✅ 撤离成功" : "❌ 任务失败",
                    13, r.success ? UI.GREEN : UI.RED));
            card.addView(UI.tv(ctx, r.map + " · 击杀 " + r.kills
                    + " · 战利 " + UI.fmt(r.loot), 12, UI.GRAY));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = UI.dp(ctx, 8);
            card.setLayoutParams(lp);
            content.addView(card);
        }
        return wrap(content);
    }

    // ===== 设置 =====
    public View buildSettings() {
        LinearLayout content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);

        LinearLayout box1 = UI.card(ctx);
        box1.addView(UI.tv(ctx, "游戏设置", 14, UI.ORANGE));
        addToggle(box1, "音效", s.sfx, () -> { s.sfx = !s.sfx; Save.save(ctx, s); });
        addToggle(box1, "自动用药", s.autoMed, () -> { s.autoMed = !s.autoMed; Save.save(ctx, s); });
        addToggle(box1, "辅助瞄准", s.aimAssist, () -> { s.aimAssist = !s.aimAssist; Save.save(ctx, s); });
        content.addView(box1);

        LinearLayout box2 = UI.card(ctx);
        box2.addView(UI.tv(ctx, "存档", 14, UI.ORANGE));
        Button reset = UI.dangerBtn(ctx, "重置存档");
        reset.setOnClickListener(v -> {
            new AlertDialog.Builder(ctx)
                    .setMessage("确定重置所有进度？此操作不可恢复！")
                    .setPositiveButton("确定", (d, w) -> {
                        ctx.getSharedPreferences("gunmu", Context.MODE_PRIVATE)
                                .edit().clear().apply();
                        s = GameState.createNew();
                        act.state = s;
                        Save.save(ctx, s);
                        act.showLobby();
                    })
                    .setNegativeButton("取消", null)
                    .show();
        });
        box2.addView(reset);
        content.addView(box2);

        LinearLayout box3 = UI.card(ctx);
        box3.addView(UI.tv(ctx, "棍母小镇 v6.0 原生版", 12, UI.GRAY));
        box3.addView(UI.tv(ctx, "撤离 " + s.extracts + " · 击杀 " + s.totalKills
                + " · 阵亡 " + s.deaths, 11, UI.GRAY));
        content.addView(box3);

        return wrap(content);
    }

    private void addToggle(LinearLayout parent, String label, boolean val, Runnable action) {
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, UI.dp(ctx, 8), 0, UI.dp(ctx, 8));
        row.addView(UI.tv(ctx, label, 13, UI.TEXT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        TextView v = UI.tv(ctx, val ? "开" : "关", 13, val ? UI.GREEN : UI.GRAY);
        v.setLayoutParams(lp);
        row.addView(v);
        row.setOnClickListener(x -> { action.run(); act.showScreen(buildSettings()); });
        parent.addView(row);
    }

    private void alert(String msg) {
        new AlertDialog.Builder(ctx).setMessage(msg).setPositiveButton("好", null).show();
    }
}